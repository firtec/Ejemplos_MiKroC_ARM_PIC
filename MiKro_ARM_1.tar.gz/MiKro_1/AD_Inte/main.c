/*****************************************************************************
*  Descripci�n  : Lectura de ADC1 pin PA5 por interrupcion
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

 // ----- LCD Configuraci�n de pines -----------------------------------------
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
  
 volatile unsigned int conversion = 0;

#define led   GPIOD_ODR.B15

void LcdFloat(unsigned char,unsigned char, float, unsigned char);

 void ADC_ISR() iv IVT_INT_ADC ics ICS_AUTO {
 if(ADC1_SRbits.EOC){
  ADC1_SRbits.EOC =0;
  led = ~ led;
  conversion = ADC1_Get_Sample(5);
 }
}
  
void main() {

    GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);
    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
 
  //------- Config general del modulo ADC ------------------------------------
    ADC_Set_Input_Channel(_ADC_CHANNEL_5);//|_ADC_CHANNEL_6);
    ADC1_Init();
    //ADC1_CR2bits.ADON = 1;
    ADC_CCRbits. ADCPRE = 2;// ADC prescaler APB2 84Mhz/6 = 14hz clock max
    ADC_CCRbits. MULT = 0;  // Independent mode
    ADC_CCRbits. DELAY = 1; // Delay between 2 sampling phases 0000: 5 * TADCCL
    NVIC_IntEnable(IVT_INT_ADC);
  //------ Config particular del ADC1 -  -------------------------------------
    //ADC1_CR1bits. SCAN = 0;
    //ADC1_CR1bits. RES = 0;   // Resolucion en 12 bits
    ADC1_SMPR1bits. SMPx_x = 0; // sampling time selection 3 ciclos
    ADC1_SMPR2bits. SMPx_x = 0;
    //ADC1_CR2bits. ALIGN = 0; // Right alignment
    //ADC1_CR2bits. EXTEN = 0; // Extern Trigger detection disabled
    //ADC1_CR2bits. CONT = 0;   // Conv Continua
    //ADC1_SQR1bits.L = 0;      // Una conv.
    //ADC1_CR2bits.JEXTEN = 0;
    ADC1_CR1bits. EOCIE = 1; // Interrupt enable for EOC

    Lcd_Out(1, 1, "Interrupcion Conv.AD" );
    Lcd_Out(2, 1, "PA5_V:" );
    led = 0;

  while(1) {
  ADC1_CR2bits. SWSTART = 1;
  LcdFloat(2,7,((conversion *3.3)/4096),2);
  //Delay_ms(10);

  }
}

/******************************************************************************
*  Funci�n para convertir dato float en ASCII y mostrarlo en una coordenada
*  X - y determinada del LCD.
******************************************************************************/
void LcdFloat(unsigned char x,unsigned char y, float num, unsigned char dec){
unsigned char fila = 0;
unsigned char a = 0;
unsigned char nent = 0;
unsigned long ent = num;
float decimales = num;
float resultado = 0;
unsigned long rdec = 0;
unsigned char texto[10];
 
 fila = x;
 for(a=0;ent>0;a++){
   ent /= 10;
   nent++;
 }
 if(nent==0) nent=1;
 ent=num;
 resultado = decimales-ent;
 
 for(a=1;a<=dec;a++)
   resultado*=10;
 for(a=0;a<nent;a++){
   texto[a]=ent%10;
   ent/=10;
 }
 for(a=nent;a>0;a--)
   Lcd_Chr(fila,y++,texto[a-1]+48);
 Lcd_Chr_cp('.');
 y++;
 rdec=resultado;
 for(a=0;a<dec;a++){
   texto[a]=rdec%10;
   rdec/=10;
 }
 for(a=dec;a>0;a--)
 Lcd_Chr(fila,y++,texto[a-1]+48);
 
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************