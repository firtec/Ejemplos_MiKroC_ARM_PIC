// DAC Test for STM32F407VG STM32F4-Discovery Board

// default options of HSE osc 168MHz

// DAC1 outputs on PA4   - you will need an oscilloscope to see the output waveform
// DAC2 outputs on PA5   - not used here
// DAC1 requires access to DMA1 Stream 5, Channel 7
// DAC_DHR8R1bits absolute 0x40007410;
// DAC_DHR8R2bits absolute 0x4000741C;
// DAC_DHR12R1bits absolute 0x40007408;                   // PA4
// DAC_DHR12R2bits absolute 0x40007414;                   // PA5
// DAC_DHR12L1bits absolute 0x4000740C;
// DAC_DHR12L2bits absolute 0x40007418;

unsigned int *pointer;
unsigned short int x;

// sine wave look up table
const Sine12bit[64] = {
  2048, 2228, 2407, 2583, 2753, 2917, 3072, 3217,
  3351, 3473, 3580, 3673, 3751, 3812, 3855, 3882,
  3891, 3882, 3855, 3812, 3751, 3673, 3580, 3473,
  3351, 3217, 3072, 2917, 2753, 2583, 2407, 2228,
  2048, 1867, 1688, 1513, 1342, 1179, 1024, 878,
  744, 623, 515, 422, 345, 284, 240, 213,
  205, 213, 240, 284, 345, 422, 515, 623,
  744, 878, 1024, 1179, 1342, 1513, 1688, 1867};

// *****************************************************************************
//    Timer 6 Configure Subroutine
// *****************************************************************************
void Timer6_Configure(void) {

  CEN_TIM6_CR1_bit = 0;                                   // Disable timer before configuring it

/* Time base configuration */
// Bits 15:8 Reserved, must be kept at reset value
// Bits 6:4 Reserved, must be kept at reset value
// Bit 2 URS: Update request source 1: Only counter overflow/underflow generates an update interrupt or DMA request if enabled.
  ARPE_TIM6_CR1_bit = 1;                                  // Bit 7 ARPE: Auto-reload preload enable = 1
  OPM_TIM6_CR1_bit = 0;                                   // One-pulse mode -0: Counter is not stopped at update event
  URS_TIM6_CR1_bit = 0;
  UDIS_TIM6_CR1_bit = 0;                                  // Bit 1 UDIS: Update disable
  
// TIM6_CR2bits
// Bits 15:7 Reserved, must be kept at reset value
// Bits 6:4 MMS: Master mode selection
  MMS2_TIM6_CR2_bit = 0;                                  // Bits 6:4MMS: Master mode selection
  MMS1_TIM6_CR2_bit = 1;                                  // Update - The update event is selected as a trigger output (TRGO).
  MMS0_TIM6_CR2_bit = 0;                                  // For instance a master timer can then be used as a prescaler for a slave timer
// Bits 3:0 Reserved, must be kept at reset value

//TIM6 DIER bits
// Bit 15:9 Reserved, must be kept at reset value
// Bit 7:1 Reserved, must be kept at reset value
// Bits 3:0 Reserved, must be kept at reset value
  TIM6_DIER.UDE = 0;                                      // Bit 8 UDE: Update DMA request enable
  TIM6_DIER.UIE = 0;                                      // Bit 0 UIE: Update interrupt enable

// Auto-Reload Register (TIMx_ARR)
// Auto load register  65522 (32 bit register) count down to zero
//  TIM6_ARR = 631;                                       // 631 = 2200 Hz @64 steps
  TIM6_ARR = 1157;                                        // 1157 = 1200 Hz @64 steps
  TIM6_PSC = 0;                                           // Set timer prescaler
}

// *****************************************************************************
//    DAC Channel 1 Configure Subroutine
// *****************************************************************************

void DAC_Ch1_Config(void) {
  EN2_bit = 0;
  EN1_bit = 0;
//                                                        // Bits 31:30 Reserved must be kept at default value
  DMAUDRIE2_bit = 0;                                      // Bits 29 DMAUDRIE2  DAC channel2 DMA underrun interrupt enable
  DMAEN2_bit = 1;                                         // Bit 28 DMAEN2  DAC channel2 DMA enable
  MAMP23_bit = 0;                                         // Bit 27 MAMP2 3 DAC channel2 mask/amplitude selector
  MAMP22_bit = 0;                                         // Bit 26 MAMP2 2 DAC channel2 mask/amplitude selector
  MAMP21_bit = 0;                                         // Bit 25 MAMP2 1 DAC channel2 mask/amplitude selector
  MAMP20_bit = 0;                                         // Bit 24 MAMP2 0 DAC channel2 mask/amplitude selector
  WAVE21_bit = 0;                                         // Bit 23 WAVE2 1 DAC channel2 noise/triangle wave generation enable
  WAVE20_bit = 0;                                         // Bit 22 WAVE2 0 DAC channel2 noise/triangle wave generation enable
  TSEL22_bit = 0;                                         // Bit 21 TSEL2 2 DAC channel1 trigger selection
  TSEL21_bit = 0;                                         // Bit 20 TSEL2 1 DAC channel1 trigger selection
  TSEL20_bit = 0;                                         // Bit 19 TSEL2 0 DAC channel1 trigger selection
  TEN2_bit = 1;                                           // Bit 18 TEN2: DAC channel 2 trigger enable
  BOFF2_bit = 0;                                          // Bit 17 BOFF2: DAC channel 2 output buffer disable
//                                                        // Bits 15:14 Reserved must be kept at default value
  DMAUDRIE1_bit = 0;                                      // Bit 13 DMAUDRIE1 DAC channel 1 DMA Underrun Interrupt enable
  DMAEN1_bit = 1;                                         // Bit 12 DMAEN1  DAC channel 1 DMA enable  - DMA Mode Enabled
  MAMP13_bit = 0;                                         // Bit 11 MAMP1 3 - DAC channel 1 mask/amplitude selector
  MAMP12_bit = 0;                                         // Bit 10 MAMP1 2 - DAC channel 1 mask/amplitude selector
  MAMP11_bit = 0;                                         // Bit 9 MAMP1 1 - DAC channel 1 mask/amplitude selector
  MAMP10_bit = 0;                                         // Bit 8 MAMP1 0 - DAC channel 1 mask/amplitude selector
  WAVE11_bit = 0;                                         // Bit 7 WAVE1 1 DAC channel 1 noise/triangle wave generation enable
  WAVE10_bit = 0;                                         // Bit 6 WAVE1 0 DAC channel 1 noise/triangle wave generation enable
  TSEL12_bit = 0;                                         // Bit 5 TSEL bit 2 - DAC channel 1 trigger selection -  TIMR6 Output Event
  TSEL11_bit = 0;                                         // Bit 4 TSEL bit 1 - Note: Only used if bit TEN1 = 1 (DAC channel1 trigger enabled)
  TSEL10_bit = 0;                                         // Bit 3 TSEL bit 0
  TEN1_bit = 1;                                           // Bit 2 TEN 1: DAC channel 1 trigger enable
  BOFF1_bit = 0;                                          // Bit 1 BOFF 1: DAC channel 1 output buffer disable - 0 = Enabled
}

/* ************************************************************************* */
/* DMA1_Stream 5 channel 7 configuration                                     */
/* ************************************************************************* */
void DMA1_Stream5_Ch7_Config(void) {

//  DMA_Cmd(DMA1_Stream5, DISABLE);
  EN_DMA1_S5CR_bit = 0;                                   // disable audio stream
  while (EN_DMA1_S5CR_bit==1) {                           // wait for audio stream to be disabled
  }                                                       // before changing DMA settings
// All Stream5 Status dedicated registers to be cleared
  CTCIF5_DMA1_HIFCR_bit = 1;                              // Channel 5 transfer complete clear
  CHTIF5_DMA1_HIFCR_bit = 1;                              // Channel 5 half transfer clear
  CTEIF5_DMA1_HIFCR_bit = 1;                              // Channel 5 transfer error clear
  CDMEIF5_DMA1_HIFCR_bit = 1;
  CFEIF5_DMA1_HIFCR_bit = 1;
//  DMA1_LIFCR = 0x00000F40;                              // clear DMA IRQ flags

//  DMA_InitStructure.DMA_PeripheralBaseAddr              (uint32_t)DAC_DHR12R2_ADDRESS;
//  DMA1_S5PAR = &DAC_DHR12R2;                            //DAC_DHR12R2_ADDRESS = 0x40007414  - PA5
  DMA1_S5PAR = &DAC_DHR12R1;                              //DAC_DHR12R2_ADDRESS = 0x40007408  - PA4
    
//  DMA_InitStructure.DMA_Memory0BaseAddr                 (uint32_t)&Sine12bit;
//  M0AR is the address register used for circular mode
  DMA1_S5M0AR = &Sine12bit;                               // Bit 31: Memory 0 address

//  DMA_InitStructure.DMA_BufferSize = 64;
  DMA1_S5NDTR = 64;

//  DMA_InitStructure.DMA_Channel = DMA_Channel_7;
//  #define DMA_Channel_7                                 ((uint32_t)0x0E000000)
  CHSEL2_DMA1_S5CR_bit=1;                                 // Bit 27 Channel selection
  CHSEL1_DMA1_S5CR_bit=1;                                 // Bit 26 Channel selection
  CHSEL0_DMA1_S5CR_bit=1;                                 // Bit 27 Channel selection

//  DMA_MemoryBurst Single                                ((uint32_t)0x00000000)0
  MBURST1_DMA1_S5CR_bit=0;                                // Bit 24 Memory burst transfer configuration
  MBURST0_DMA1_S5CR_bit=0;                                // Bit 23 Memory burst transfer configuration

//  DMA_PeripheralBurst Single                            ((uint32_t)0x00000000)
  PBURST1_DMA1_S5CR_bit=0;                                // Bit 22 Peripheral burst transfer configuration
  PBURST0_DMA1_S5CR_bit=0;                                // Bit 21 Peripheral burst transfer configuration
  
// ACK
  ACK_DMA1_S5CR_bit = 0;                                  // DMA1_S5CR.B20;
    
// CT
  CT_DMA1_S5CR_bit = 0;                                   // Bit 19  DMA1_S5CR.B19;
    
// DBM
  DBM_DMA1_S5CR_bit = 0;                                  // Bit 18  DMA1_S5CR.B18;
    
//  #define DMA_Priority_High                             ((uint32_t)0x00020000)
  PL1_DMA1_S5CR_bit=1;                                    // Bit 17  Priority level (HIGH)
  PL0_DMA1_S5CR_bit=0;                                    // Bit 16  Priority level (HIGH)
    
//  PINCOS
  PINCOS_DMA1_S5CR_bit = 0;                               //
    
//  #define DMA_MemoryDataSize_HalfWord                   ((uint32_t)0x00002000)
  MSIZE1_DMA1_S5CR_bit=0;                                 // Bits 14 = 0 Memory data size
  MSIZE0_DMA1_S5CR_bit=1;                                 // Bits 13 = 1 Memory data size

//  #define DMA_PeripheralDataSize_HalfWord               ((uint32_t)0x00000800)
  PSIZE1_DMA1_S5CR_bit=1;                                 // Bit 12 Peripheral data size
  PSIZE0_DMA1_S5CR_bit=0;                                 // Bit 11 Peripheral data size

//  DMA_MemoryInc Enabled                                 ((uint32_t)0x00000400)
  MINC_DMA1_S5CR_bit = 1;                                 // Bit 10 MINC: Memory increment mode

//  DMA_PeripheralInc Disabled                            ((uint32_t)0x00000000)
  PINC_DMA1_S5CR_bit = 0;                                 // Bit 9 PINC: Peripheral increment mode

//  DMA_Mode_Circular enabled                             ((uint32_t)0x00000100)
  CIRC_DMA1_S5CR_bit = 1;                                 // Bit 8 CIRC: Circular mode

//  DMA_DIR MemoryToPeripheral                            ((uint32_t)0x00000040)
  DIR1_DMA1_S5CR_bit=0;                                   // Bits 7 DIR[1:0]: Data transfer direction
  DIR0_DMA1_S5CR_bit=1;                                   // Bits 6 DIR[1:0]: Data transfer direction

  PFCTRL_DMA1_S5CR_bit = 0;                               // Peripheral Control: Bit 5
  TCIE_DMA1_S5CR_bit = 0;                                 // Transfer complete interrupt enable
  HTIE_DMA1_S5CR_bit = 0;                                 // Half transfer interrupt enbale
  TEIE_DMA1_S5CR_bit = 0;                                 // Transfer error interrupt enable
  DMEIE_DMA1_S5CR_bit = 0;                                // direct error interrupt enable
    
//  #define DMA_FIFOMode_Disable                          ((uint32_t)0x00000000)
  DMDIS_DMA1_S5FCR_bit = 0;                               // Bit 2 DMDIS: Direct mode disable

//  #define DMA_FIFOThreshold_HalfFull                    ((uint32_t)0x00000001)
  FTH1_DMA1_S5FCR_bit = 0;                                // Bit 1 FIFO threshold selection
  FTH0_DMA1_S5FCR_bit = 1;                                // Bit 0 FIFO threshold selection
}

void main() {
// Turn on the DAC and GPIO clocks before configuring the peripherals
  RCC_AHB1ENR.DMA1EN = 1;                                 // Enable DMA1 clock
  RCC_AHB1ENR.GPIOAEN = 1;                                // Enable GPIO A clock
  RCC_AHB1ENR.GPIODEN = 1;                                // Enable GPIO D clock
  RCC_APB1ENR.DACEN = 1;                                  // Enable DAC clock
  RCC_APB1ENR.TIM6EN = 1;                                 // Enable TIM6 clock
  RCC_APB1ENR.PWREN = 1;                                  //
  SYSCFGEN_bit = 1;                                       //
  
  // Set GPIO_PORTD pins 12 through 15 as digital output
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_0 | _GPIO_PINMASK_12);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_0 | _GPIO_PINMASK_13);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_0 | _GPIO_PINMASK_14);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_0 | _GPIO_PINMASK_15);

  Timer6_Configure();                                     // Configure Timer 6
  DAC_Ch1_Config(void);                                   // Configure the DAC
  DMA1_Stream5_Ch7_Config(void);                          // Configure the DMA
  EN_DMA1_S5CR_bit = 1;                                   // Enable DMA  Stream 5
  EN1_bit = 1;                                            // Bit 0 EN1: DAC channel 1 enable
  EN2_bit = 1;                                            // Bit 16 EN2: DAC channel 2 enable
  TIM6_CR1.CEN = 1;                                       // Enable timer
  
  GPIOD_ODR.F15 = 1;                                      // Blue
  GPIOD_ODR.F13 = 1;                                      // Yellow
  GPIOD_ODR.F14 = 1;                                      // Red
  GPIOD_ODR.F12=1;                                        // Toggle Green on Port D13
  Delay_ms(1000);
  
// START MAIN PROGRAM LOOP
  while(1){                                               // endless loop {
    GPIOD_ODR.F13=!GPIOD_ODR.F13;                         // Toggle LED2 (Yellow)on Port D13
    if(GPIOD_ODR.F13==0) {                                // alternate tones
      TIM6_ARR = 1157;                                    // transmit 1200 Hz tone
    }
    else {
      TIM6_ARR = 631;                                     // Transmit 2200 Hz Tone
    }
    Delay_ms(500);                                        // Blink LED 12 at 1 Hz rate
  }
}