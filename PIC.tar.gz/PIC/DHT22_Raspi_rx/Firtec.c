/****************************************************************************
**  Descripci�n  : Lectura de temperatura y humedad con un sensor DHT22.
**                 La informaci�n se env�a mediante la red WiFi en un
**                 Socket UDP. La capa de enlace la provee un ESP8266
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 40MHZ - (XTAL 10Mhz con PLLx4)
**  NOTA         : los pines 25 se conecta a RX del ESP8266 y el
**                 pin 26 al TX .
****************************************************************************/
// Pines asignados al LCD
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

// Conexiones del sensor
sbit DHT22_Bus_In at RE0_bit;
sbit DHT22_Bus_Out at RE0_bit;
sbit DHT22_Bus_Dir at TRISE0_bit;

// Variables del programa
char DHT22_Data[5] = {0, 0, 0, 0, 0};
unsigned humedad = 0, temperatura = 0;
volatile unsigned int milisegundos = 0;
volatile unsigned int segundos =0;
volatile unsigned int minutos =0;
volatile char Dato_RX, Kbhit=0;

void ISR_UART() iv 0x0008 ics ICS_AUTO {
  if (PIR1.RCIF) {         // test the interrupt for uart rx
     Dato_RX = Uart1_Read();   // Lee dato recibido
         if(Dato_RX == '1')
            Kbhit=1;               // Indica que se ha recibido un dato
    PIR1.RCIF=0;           // Borra bandera de interrupci�n
    }
  }


/******************************************************************************
* Funci�n para el env�o de cadenas por el puerto UART.
******************************************************************************/
void Enviar_String(const char *s)
{
  while(*s)
  {
    UART1_Write(*s++);
  }
}
/****************************************************************
* Configuraci�n b�sica para crear un cliente UDP sobre una IP y
* puerto determinado.
* IMPORTANTE_1: los pines 25 se conecta a RX del ESP8266 y el
* pin 26 al TX .
*
* IMPORTANTE_2:
* Se supone que los datos de conexi�nes WiFi (SSI y PASS) ya
* fueron cargados antes ya que estos datos no se pierden si el
* modulo se apaga o resetea, pero si la configuraci�n del socket.
* Esta configuraci�n dispone el modo wifi para que todo lo enviado
* por la USART pase directamente al socket.
* (Transparent Transmission Mode)
*
*****************************************************************/
void Configurar_ESP8266(void){
        Enviar_String("AT+RST\r\n");  // Reset general del m�dulo.
        Delay_ms(2000);
        Enviar_String("AT\r\n");        // Comando de control
        Delay_ms(500);
        Enviar_String("AT+CIPSTART=");  // Configura el Socket UDP
        Enviar_String("\"");
        Enviar_String("UDP");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("\"");
        Enviar_String("192.168.1.10");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("30000\r\n");
        Delay_ms(500);
        Enviar_String("AT+CIPMODE=1\r\n"); // Activa el modo " TX transparente"
        Delay_ms(500);
        Enviar_String("AT+CIPSEND\r\n");  // Confirmo el modo
}



/*******************************************************
*   Esta funci�n lee los dato desde el sensor DHT22    *
*******************************************************/
char Leer_DHT22(unsigned *humedad, unsigned *temperature) {
  char i = 0, j = 1;
  char tiempo_espera = 0;
  char sensor_byte;
  DHT22_Bus_Out = 0;
  delay_ms(100);

  DHT22_Bus_Dir = 1;     // Establece Bus como entrada
  DHT22_Bus_Dir = 0;     // Establece Bus como salida
  DHT22_Bus_Out = 1;     // Bus en alto por 100 milisegundos
  Delay_ms(100);         // Esoera 100ms
  DHT22_Bus_Out = 0;     // Inicia se�al baja min: 0.8ms, tip: 1ms, max: 20ms
  Delay_ms(2);           // Espera 2ms
  DHT22_Bus_Out = 1;     // Bus en alto
  DHT22_Bus_Dir = 1;     // Bus como entrada

  // Libera el bus por un tiempo min: 20us, tip: 30us, max: 200us
  tiempo_espera = 200;
  while (DHT22_Bus_In == 1) {
    Delay_us(1);
    if (!tiempo_espera--) {
      return 1;
    } //ERROR: El sensor no responde
  }

  // Se�al de respuesta del sensor min: 75us, tip: 80us, max: 85us
  while (!DHT22_Bus_In) { // Responde en un tiempo bajo
    Delay_us(85);
  }
  while (DHT22_Bus_In) {  // Responde en un tiempo alto
    Delay_us(55);
  }

  /*
   * tiempos en us:          min  tip  max
   * se�al 0 alto tiempo:    22   26   30 (bit=0)
   * se�al 1 alto tiempo:    68   70   75 (bit=1)
   * se�al 0,1 bajo tiempo:  48   50   55
   */

  i = 0; // Obtener 5 bytes
  for (i = 0; i < 5; i++) {
    j = 1;
    for (j = 1; j <= 8; j++) { // Se leen 8 bits desde el sensor
      while (!DHT22_Bus_In) {
        Delay_us(1);
      }
      Delay_us(30);
      sensor_byte <<= 1;       // Agregar el byte bajo
      if (DHT22_Bus_In) {
        sensor_byte |= 1;
        delay_us(45);
        while (DHT22_Bus_In) {
          Delay_us(1);
        }
      }
    }
    DHT22_Data[i] = sensor_byte;
  }

  *humedad = (DHT22_Data[0] << 8) + DHT22_Data[1];
  *temperature = (DHT22_Data[2] << 8) + DHT22_Data[3];

  return 0;
}
/**********************************************************
*   Esta funci�n ajusta los valores l�dos desde el sensor
*   y los muestra en la pantalla LCD
**********************************************************/
void Mostrar_Datos(unsigned humedad, unsigned temperatura) {
  char txt[15];
  char temp_humedad[12];
  float temp1;
  float temp2;

  temp1 = humedad / 10.0;
  Lcd_Out(1,1,"Humed.:");
  sprintf(txt, "%2.1f ", temp1); // Formato para la humedad
  Lcd_Out(1,9,txt);
  Lcd_Chr(1,14,0x25);

  temp2 = temperatura / 10.0;
  Lcd_Out(2,1,"Temp. :");
  sprintf(txt, "%2.1f ", temp2); // Formato para la temperatura
  //sprintf(txt, "%X ", minutos);
  Lcd_Out(2,9,txt);
  Lcd_Chr(2,13,223);   // S�mbolo de grados
  Lcd_Chr(2,14,0x43);
  
  if(Kbhit == 1){  // Enviar datos cada 30 minutos
  sprintf(temp_humedad,"%2.1f,%2.1f ", temp2,temp1);
  UART1_Write_Text(temp_humedad);
  Kbhit = 0;
  }
}
/**********************************************************
*   Esta funci�n ajusta los valores por defecto de la
*   pantalla LCD y coloca los carteles iniciales.
**********************************************************/
void Display_Init(){
  LCD_Init();
  LCD_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1,1,"Socket & MiKroC");
  Lcd_Out(2,1,"Conectando.....");
  delay_ms(2000);
 // LCD_Cmd(_LCD_CLEAR);
}
/**********************************************************
*  Esta es la funci�n principal del programa.
*  Configura pines, comparadores, canales anal�gicos y se
*  llama al resto de las funciones.
**********************************************************/
void main() {
  char k = 0, t;
  CMCON |=7;
  ADCON1 = 0x0f;
  
  INTCON.GIE = 1;
  INTCON.PEIE = 1;
  PIE1.RCIE = 1;
  
  Display_Init();
  UART1_Init(9600);
  Delay_ms(200);
  Configurar_ESP8266();
  LCD_Cmd(_LCD_CLEAR);
  TRISC2_bit  = 0;           // Set bit2 de PTC
  PORTC.B2 = 0;

  while (1) {
    if (Leer_DHT22(&humedad, &temperatura) == 0)
      Mostrar_Datos(humedad, temperatura);

    else {
      LCD_Cmd(_LCD_CLEAR);
      Lcd_Cmd(_LCD_CURSOR_OFF);
      Lcd_Out(1,1,"ERROR en el");
      Lcd_Out(2,1,"Sensor!!!");
    }
    Delay_ms(1000); // Espera 1 segundo
  }
}