/****************************************************************************
**  Descripci�n  :
**  Target       : 8 PIN PIC12F683
**  Compiler     : MikroC para PIC v 7.1
**  OSCILADOR    : 8MHZ (Interno)
**  www.firtec.com.ar
*****************************************************************************/
sbit sirena at GP2_bit;
sbit sensor at GP5_bit;
sbit ok at GP4_bit;

void main() {
    TRISIO.B2 = 0; // Set pin 5 como salida
    TRISIO.B4 = 0;         // Set Pin 3 como salida
    TRISIO.B5 = 1;         // Set Pin 2 como entrada
    OSCCON = 0b01110101; // Oscilador interno en 8MHz
    ADCON0 = 0;          // Canales anal�gicos OFF
    ANSEL = 0;           // Todos los pines son digitales
    CMCON0 = 7;          // Comparadores OFF
    sirena = 0;
    ok = 0;
    Delay_ms(20000);
    ok = 1;
    while (1){
       if(sensor!=1){
        sirena = 0;

       }
       else {
           sirena = 1;
           Delay_ms(1000);
           }
    }
}