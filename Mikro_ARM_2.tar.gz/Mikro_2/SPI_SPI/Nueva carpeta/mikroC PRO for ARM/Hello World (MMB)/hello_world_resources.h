const code char HandelGothic_BT19x22_Regular[];
const code char Impact26x39_Regular[];
const code char Tahoma11x13_Regular[];
const code char mikroe_logo_bmp[13073];
