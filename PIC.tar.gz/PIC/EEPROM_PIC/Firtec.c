
// LCD module connections
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

void Lcd_View(unsigned char,unsigned char, float, unsigned char,
                unsigned char);

unsigned short direccion =0; // 1024 Vectores disponibles
unsigned char dato =0;

void main() {
  Lcd_Init();
  Delay_ms(100);
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

    Lcd_Out(1,1,"EEPROM PIC");
    Lcd_Out(2,1,"Memoria:");

    direccion = 1;    // Direcci�n de memoria
    dato = 254;         // El dato a guardar
    EEPROM_Write(direccion, dato);  // Escribe la memoria
    delay_ms(20);            // Espera a que termine
    dato = 0;                // Limpia vector dato
    dato = EEPROM_Read(direccion);  // Lee la memoria
    Lcd_View(2,9,dato,0,0);         // Muestra el dato le�do

  while(1);

}

/******************************************************************************
*  Funci�n para mostrar datos en ASCII en una pantalla LCD
*  x ->        L�nea en la pantalla.
*  y ->        Vector en la l�nea.
*  dec ->      N�mero de decimales
*  tipo ->    (1) mostrar un Float (0) Mostrar un entero sin signo
*
*  NOTA: La funci�n solo convierte datos enteros.
******************************************************************************/
void LCD_View(unsigned char x,unsigned char y, float num, 
              unsigned char dec, unsigned char tipo)
{
unsigned char fila = 0;
unsigned char a = 0;
unsigned char nent = 0;
unsigned long ent = num;
float decimales = num;
float resultado = 0;
unsigned long rdec = 0;
unsigned char texto[10];

 fila = x;
 for(a=0;ent>0;a++){
   ent /= 10;
   nent++;
 }
 if(nent==0) nent=1;
 ent=num;
 resultado = decimales-ent;

 for(a=1;a<=dec;a++)
   resultado*=10;
 for(a=0;a<nent;a++){
   texto[a]=ent%10;
   ent/=10;
 }

 for(a=nent;a>0;a--)
   Lcd_Chr(fila,y++,texto[a-1]+48);
 if(tipo == 1){
   Lcd_Chr_cp('.');
 y++;
 rdec=resultado;
 for(a=0;a<dec;a++){
   texto[a]=rdec%10;
   rdec/=10;
 }
 for(a=dec;a>0;a--)
 Lcd_Chr(fila,y++,texto[a-1]+48);
  }
}