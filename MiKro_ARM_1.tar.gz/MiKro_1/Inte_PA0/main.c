 /*************************************************************
*  Descripci�n  : Uso de una interruci�n externa por PA0.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
***************************************************************/
// Consultar el manual de referencia de STM RM0090 para consulta de los
// registros usados en el ejemplo.

 #define led    GPIOD_ODR.B15  // Pin salida para el led

 
  void ISR_D10() iv IVT_INT_EXTI15_10 ics ICS_AUTO {
  // if((EXTI_PR & 0x00000800) != 0)   //Check if PD11 has trigger the interrupt
   if( EXTI_PR.B11 != 0)    // Verifico que el pin 11 activ� la irq
      {
          led = ~ led;
         // EXTI_PR |= 0x00000800;        //Clear PR11
          EXTI_PR.B11 = 1;   // Clear PR11
      }
}
 
void PA1_ISR() iv IVT_INT_EXTI1 ics ICS_AUTO {
       EXTI_PR.B1 = 1;    // Borra la bandera de interrupci�n
    led = ~ led;      // Cambia estado del led.
}

  void ExtInt() iv IVT_INT_EXTI0 ics ICS_AUTO {
   EXTI_PR.B0 = 1;    // Borra la bandera de interrupci�n
    led = ~ led;      // Cambia estado del led.
}

void main() {
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15); // PD15 como salida
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);   // PA0 como entrada
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_1);   // PA1 como entrada
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_4);
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_5);
  GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_10);   // PD10 como entrada
  GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_11);   // PD11 como entrada
  SYSCFGEN_bit = 1; // RCC APB2 reloj de perif�ricos activo
  //SYSCFG_EXTICR3 = 0x00000300;         // Map external interrupt on PD10
  SYSCFG_EXTICR3 = 0x00003000;         // Map external interrupt on PD11
  EXTI_RTSR = 0x00000000;              // Set interrupt on Rising edge
  //EXTI_FTSR = 0x00000400;            // Set Interrupt on Falling edge PD10
  //EXTI_IMR |= 0x00000400;              // Set mask
  EXTI_FTSR = 0x00000800;            // Set Interrupt on Falling edge PD11
  EXTI_IMR |= 0x00000800;              // Set mask PD11
  NVIC_IntEnable(IVT_INT_EXTI15_10);   // Enable External interrupt
  led = 1;   // Led inicia encendido
  
  while(1) {
      // Espera por la Interrupci�n
  }
}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************