// Functions
void ADXL345_Write(unsigned short address, unsigned short data1);
unsigned short ADXL345_Read(unsigned short address);
char ADXL345_Init(void);

// Read X Axis
int Accel_ReadX(void);

// Read Y Axis
int Accel_ReadY(void);

// Read Z Axis
int Accel_ReadZ(void);

/**************************************************************************************************
* End of File
**************************************************************************************************/