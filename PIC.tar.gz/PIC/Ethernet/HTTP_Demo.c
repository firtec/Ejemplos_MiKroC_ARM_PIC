/****************************************************************************
Descripci�n:
                Este c�digo muestra c�mo usar la mini biblioteca Spi_Ethernet:
                El PIC responder� a las peticiones de eco de ARP e ICMP
                El PIC responder� a las peticiones UDP en cualquier puerto:
                Devuelve la solicitud con una cabecera hecha de host remoto 
                IP y n�mero de puerto.
                El PIC responder� a las peticiones HTTP en el puerto 80, 
                m�todo GET con par�metros:
                      / Devolver� la p�gina principal HTML
                      / S devolver� el estado del PIC como una cadena de texto
                      / B0 ... / b7 conmutar� RB0 a bit RB7 y devolver� p�gina 
                      principal HTML
                      / D0 ... / d7 cambiar� el RD0 al bit RD7 y devolver� la 
                      p�gina principal HTML
                      Todas las dem�s solicitudes devuelven tambi�n p�gina 
                      principal HTML
Dispositivos de destino:
      Cualquier PIC con SPI y memoria de programa con m�s de 4 KB
      32 a 40 MHz reloj se recomienda para obtener de 8 a 10 Mhz reloj SPI,
      Si intenta bajar la velocidad del reloj PIC, no se sorprenda si 
      se cuelga o se pierda algunas solicitudes!

 RST : RC0
 CS  : RC1
 MISO : RC4
 MOSI : RC5
 SCK  : RC3
 
 NOTA:
     - Dado que la ENC28J60 no admite la negociaci�n autom�tica, el modo d�plex
       No es compatible con la mayor�a de switches / routers. 
       Si se utiliza una red dedicada donde el d�plex del nodo remoto puede 
       configurarse manualmente, puede cambiar esta configuraci�n. 
       De lo contrario, siempre se debe utilizar half duplex.
 ****************************************************************************/


typedef struct {
  unsigned canCloseTCP: 1;  // Bandera que cierra socket TCP
                            // (no es relevante para UDP)
  unsigned isBroadcast: 1;  // Flag que indica que el paquete IP se ha 
                            // recibido a trav�s de la direcci�n de difusi�n de 
                            // subred (no se utiliza para la familia PIC16)
} TEthPktFlags;

#define Spi_Ethernet_HALFDUPLEX     0x00  // half duplex
#define Spi_Ethernet_FULLDUPLEX     0x01  // full duplex

// Pines Ethernet
sfr sbit SPI_Ethernet_Rst at LATC0_bit;
sfr sbit SPI_Ethernet_CS  at LATC1_bit;
sfr sbit SPI_Ethernet_Rst_Direction at TRISC0_bit;
sfr sbit SPI_Ethernet_CS_Direction  at TRISC1_bit;

const code unsigned char httpHeader[] = "HTTP/1.1 200 OK\nContent-type: ";
const code unsigned char httpMimeTypeHTML[] = "text/html\n\n";
const code unsigned char httpMimeTypeScript[] = "text/plain\n\n";
unsigned char httpMethod[] = "GET /";

//*************************************************************************
const char *index_MENU = "<HTML><HEAD></HEAD><BODY>\
<a href=\"http://192.168.1.170/\">Estado de Pines</a><p>\
<a href=\"http://192.168.1.170/D\">Puerto D</a><p>\
</BODY></HTML>";
//*************************************************************************
const char *indexPageHEAD = "<meta http-equiv='refresh' content='5;url=http://192.168.1.170/'>\
<HTML><HEAD></HEAD><BODY>\
<P ALIGN=center>EJEMPLO SIMPLE DE WEB SERVER<p>\
PIC PIC18F4620 (40MHz) con ENC28J60<p>MikroC PRO v7.1.0\
<p><a href=\"http://192.168.1.170/M\">Menu Principal</a><p>\
<p><a href=/>Recargar</a><p>\
<script src=/s></script>";
//*************************************************************************
const char *indexPageBODY =  "<table><tr><td valign=top><table border=1 style='font-size:20px; font-family: terminal;'>\
<tr><th colspan=2>ADC</th></tr>\
<tr><td>Canal_0</td><td><script>document.write(CH0);</script></td></tr>\
<tr><td>Canal_1</td><td><script>document.write(CH1);</script></td></tr>\
</table></td><td><table border=1 style='font-size:20px; font-family: terminal;'>\
<tr><th colspan=2>Puerto_B: <script>document.write(PORTB);</script></th></tr>\
<script>\
var str,i;\
str='';\
for(i=0;i<8;i++)\
{\
str+='<tr><td bgcolor=#cccccc>Pulsador _'+i+'</td>';\
if(PORTB&(1<<i))\
{str+='<td bgcolor=green>ON';}\
else\
{str+='<td bgcolor=red>OFF';}\
str+='</td></tr>';}\
document.write(str);\
</script>";
//**************************************************************************
const char *indexPageBODY2 =  "</table></td><td>\
<table border=1 style='font-size:20px; font-family: terminal;'>\
<tr><th colspan=3>Puerto_D: <script>document.write(PORTD);</script></th></tr>\
<script>\
var str,i;\
str='';\
for(i=0;i<8;i++)\
{\
str+='<tr><td bgcolor=#cccccc>LED _'+i+'</td>';\
if(PORTD&(1<<i))\
{\
str+='<td bgcolor=yellow>ON';\
}\
else\
{\
str+='<td bgcolor=#999999>OFF';\
}\
str+='</td></tr>';}\
document.write(str);\
</script>\
</table></td></tr></table>\
<p>Consultas HTTP = <script>document.write(REQ)</script><p>\
</BODY></HTML>";
//*************************************************************************
const char *PagePORT_D =  "<HTML><HEAD></HEAD><BODY>\
<script src=/s></script>\
<table border=1 style='font-size:20px; font-family: terminal;'>\
<tr><th colspan=3>Puerto_D: <script>document.write(PORTD);</script></th></tr>\
<script>\
var str,i;\
str='';\
for(i=0;i<8;i++)\
{\
str+='<tr><td bgcolor=#cccccc>LED #'+i+'</td>';\
if(PORTD&(1<<i))\
{\
str+='<td bgcolor=yellow><a href=\"/d'+i+'o\">ON</a>';\
}\
else\
{\
str+='<td bgcolor=#999999><a href=\"/d'+i+'f\">OFF</a>';\
}\
str+='</td></tr>';}\
document.write(str);\
</script>\
</table>\
</BODY></HTML>";

 // Variables en RAM **********************************************

unsigned char   myMacAddr[6] = {0x00, 0x14, 0xA5, 0x76, 0x19, 0x3f} ; // MAC
unsigned char   myIpAddr[4]  = {192, 168,  1, 170};  // Direcci�n IP
unsigned char   gwIpAddr[4]  = {192, 168,  1, 1};    // Direcci�n del Router
unsigned char   ipMask[4]    = {255, 255, 255,  0};  // M�scara de RED
unsigned char   dnsIpAddr[4] = {192, 168,  1, 10};   // Dir. del servidor DNS

unsigned char   getRequest[15];   // Buffer de solicitudes HTTP
unsigned char   get_Request, digit_getRequest, etat_interrupteur;
unsigned char   dyna[29] ;        // Buffer para respuestas din�micas
unsigned long   httpCounter = 0;  // Contador de solicitudes HTTP

#define putConstString  SPI_Ethernet_putConstString
#define putString  SPI_Ethernet_putString

/*
 * Esta funci�n es llamada por la biblioteca
 * El usuario accede a la solicitud HTTP mediante sucesivas llamadas a 
 * Spi_Ethernet_getByte()
 * El usuario pone los datos en el b�fer de transmisi�n por sucesivas llamadas 
 * a Spi_Ethernet_putByte()
 * La funci�n debe devolver la longitud en bytes de la respuesta HTTP, 
 * o 0 si nada para transmitir
 *
 * Si no necesita responder a las peticiones HTTP,
 * Solo defina esta funci�n con un retorno (0) con una sola sentencia
 *
 */
unsigned int    SPI_Ethernet_UserTCP(unsigned char *remoteHost, unsigned int 
remotePort, unsigned int localPort, unsigned int reqLength, char *canClose)
{
        unsigned int    len;
        if(localPort != 80)  // Solo escucha el puerto 80 para web�s
        {
         return(0) ;
        }
        // Solo los primeros 10 bytes importan en este punto
        for(len = 0 ; len < 10 ; len++)
        {
         getRequest[len] = SPI_Ethernet_getByte() ;
        }
        getRequest[len] = 0 ;
        len = 0;
        if(memcmp(getRequest, httpMethod, 5)) // Es la funci�n GET method?
        {
         return(0) ;
        }
        httpCounter++ ;   // Cuenta las solicitudes recibidas
        
        get_Request = getRequest[5];  // s , d , h
        
        if(get_Request == 's')  // Variable usada en <script src=/s></script>
        {
         // La cadena de texto contestada por esta solicitud puede ser 
         //interpretada como sentencias javascript por navegadores

         len = putConstString(httpHeader) ;         // Encabezado HTTP
         len += putConstString(httpMimeTypeScript) ;// con texto tipo MIME

         // Agrega el valor de los canales anal�gicos a la respuesta
         // Primero el canal 0
         WordToStr(ADC_Read(0), dyna);
         len += putConstString("var CH0=");
         len += putString(dyna);
         len += putConstString(";");

         // Luego agrega el canal 1
         WordToStr(ADC_Read(1), dyna);
         len += putConstString("var CH1=");
         len += putString(dyna);
         len += putConstString(";");
         
         // Agrega el estado de los pulsadores
         len += putConstString("var PORTB=") ;
         WordToStr(PORTB, dyna);
         len += putString(dyna);
         len += putConstString(";");

         // Agrega el estado de los LED�s
         len += putConstString("var PORTD=");
         WordToStr(PORTD, dyna);
         len += putString(dyna);
         len += putConstString(";") ;

         // Agrega el estado del contador de solicitudes
         WordToStr(httpCounter, dyna);
         len += putConstString("var REQ=");
         len += putString(dyna);
         len += putConstString(";");
        }

         if(get_Request == 'd') // Comando para evaluar el Puerto D
         {
          if( isdigit(getRequest[6]) )
          {
           digit_getRequest  = getRequest[6] - '0'; // N�mero de bit 0 a 7

           if( getRequest[7] == 'o' )
           etat_interrupteur = 0;

           if( getRequest[7] == 'f' )
           etat_interrupteur = 1;

           switch(digit_getRequest)
           {
            case 0: PORTD.B0 = etat_interrupteur; break;
            case 1: PORTD.B1 = etat_interrupteur; break;
            case 2: PORTD.B2 = etat_interrupteur; break;
            case 3: PORTD.B3 = etat_interrupteur; break;
            case 4: PORTD.B4 = etat_interrupteur; break;
            case 5: PORTD.B5 = etat_interrupteur; break;
            case 6: PORTD.B6 = etat_interrupteur; break;
            case 7: PORTD.B7 = etat_interrupteur; break;
           }
          }
         }

        if(get_Request == 'M')
        { // Acci�n por defecto
         len =  putConstString(httpHeader);       // Cabecera HTTP
         len += putConstString(httpMimeTypeHTML); // tipo HTML MIME
         len += putConstString(index_MENU);       // P�gina HTML del Puerto D
        }
        
        if(get_Request == 'D')
        { // Acci�n por defecto
         len =  putConstString(httpHeader);
         len += putConstString(httpMimeTypeHTML);
         len += putConstString(PagePORT_D);
        }
        
        if(get_Request == 'h')
        {  // Acci�n por defecto
         len =  putConstString(httpHeader);       // Cabecera HTTP
         len += putConstString(httpMimeTypeHTML); // tipo HTML MIME
        }

        if(len == 0)
        { // Acci�n por defecto
         len =  putConstString(httpHeader);       // HTTP header
         len += putConstString(httpMimeTypeHTML); // with HTML MIME type
         len += putConstString(indexPageHEAD);    // HTML page first part
         len += putConstString(indexPageBODY);    // HTML page second part
         len += putConstString(indexPageBODY2);   // HTML page second part
        }
        
         return(len) ;  // Retorna con el n�mero de bytes para transmitir
        }

/*
 * Esta funci�n es llamada por la biblioteca
 * El usuario accede a la petici�n UDP por sucesivas llamadas a 
 * Spi_Ethernet_getByte ()
 * El usuario pone los datos en el b�fer de transmisi�n por sucesivas 
 * llamadas a Spi_Ethernet_putByte ()
 * La funci�n debe devolver la longitud en bytes de la respuesta UDP, o 
 * 0 si nada para transmitir
 * Si no necesita responder a las peticiones UDP,
 * Solo defina esta funci�n con un retorno (0) como una sola sentencia
 *
 */

unsigned int    SPI_Ethernet_UserUDP(unsigned char *remoteHost, 
         unsigned int remotePort, unsigned int destPort, 
         unsigned int reqLength, TEthPktFlags *flags)
        {
        unsigned int    len ;           // my reply length

        // Responde a la direcci�n IP que corresponde
        ByteToStr(remoteHost[0], dyna) ;        // Pimer Byte IP address
        dyna[3] = '.' ;
        ByteToStr(remoteHost[1], dyna + 4) ;    // Segundo Byte IP address
        dyna[7] = '.' ;
        ByteToStr(remoteHost[2], dyna + 8) ;    // Tercer Byte IP address
        dyna[11] = '.' ;
        ByteToStr(remoteHost[3], dyna + 12) ;   // Cuarto Byte IP address

        dyna[15] = ':' ;                        // Separador

        // Puerto del Host remoto
        WordToStr(remotePort, dyna + 16) ;
        dyna[21] = '[' ;
        WordToStr(destPort, dyna + 22) ;
        dyna[27] = ']' ;
        dyna[28] = 0 ;
        len = 28 + reqLength;

        // Coloca el string en el buffer transmisor
        SPI_Ethernet_putBytes(dyna, 28) ;
        while(reqLength--)
                {
                SPI_Ethernet_putByte(toupper(SPI_Ethernet_getByte())) ;
                }

        return(len) ;  // Retornar con la longitud de la respuesta UDP
        }

/*
 * main entry
 */
void   main()
       {
        ADCON1 = 0x0D;  // Pines digitales
        PORTA = 0 ;
        TRISA = 0x03 ;  // Pines RA0 y RA1 como entrada
        PORTB = 0 ;
        TRISB = 0xff ; // Puerto B como entrada para botones
        PORTD = 0;
        TRISD = 0;    // Puerto D como salida

        /*
         * Inicia ENC28J60 con:
         * Reset bit en RC0
         * CS bit en RC1
         * Mi direcci�n MAC & IP
         * duplex completo
         */
        SPI1_Init();
        SPI_Rd_Ptr = SPI1_Read;
        SPI_Ethernet_Init(myMacAddr, myIpAddr, Spi_Ethernet_FULLDUPLEX) ;

        // DHCP no se utilizar�, as� que usa direcciones preconfiguradas
        SPI_Ethernet_confNetwork(ipMask, gwIpAddr, dnsIpAddr) ;

        while(1)
                {
                SPI_Ethernet_doPacket() ;// Procesa el paquete
                /*
                 * Aqu� agregar el c�digo del usuario si fuera necesario pero
                 * recordando que Spi_Ethernet_doPacket () debe ser llamado 
                 * tan a menudo como sea posible, de lo contrario los paquetes 
                 * se podr�an perder
                 */
                }
        }