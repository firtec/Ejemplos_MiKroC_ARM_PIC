const code char Arial16x19_Bold[];
const code char Arial21x24_Bold[];
const code char Courier_New12x23_Bold[];
const code char Tahoma11x13_Regular[];
const code char Tahoma13x13_Bold[];
const code char Tahoma13x16_Regular[];
