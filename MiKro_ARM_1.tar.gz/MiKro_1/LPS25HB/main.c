/*****************************************************************************
*  Descripci�n  : Ejemplo de uso para el sensor LPS25HB
*                 Sensor I2C para Temperatura y Bar�metro.
*                 Este ejemplo utiliza I2C1 en pines PB7 y PB8.
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
// Pines usados en la pantalla LCD
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

unsigned char I2C_LeerRegistro(char);
void I2C_EscribirRegistro(char,char);
float LPS25HB_LeerTemperatura(void);
float LPS25HB_LeerPresMilibares(void);
char LPS25HB_LeerStatus(void);

unsigned char device_id = 0;
unsigned char temporal_datos[12];
float temperatura, presion;

#define I2C_ADR       0x5D

//=====================================================
// Esta funci�n lee el registro Status del sensor
// ====================================================
char LPS25HB_LeerStatus() {
  return I2C_LeerRegistro(0x27);
}

//======================================================
// Esta funci�n lee el valor del bar�metro y retorna la
// presi�n medida en milibares.
// El valor barom�trico se lee de tres registros.
// =====================================================
float LPS25HB_LeerPresMilibares() {
  char temporal;
  unsigned long resultado;
  temporal = I2C_LeerRegistro(0x2A);
  resultado = (unsigned long) temporal;
  temporal = I2C_LeerRegistro(0x29);
  resultado = (resultado << 8) | temporal;
  temporal = I2C_LeerRegistro(0x28);
  resultado = (resultado << 8) | temporal;
  return (float)resultado/4096;
}
//=====================================================
// Esta funci�n escribe en los registros internos
// del sensor.
// ====================================================
void I2C_EscribirRegistro(char wrDir, char wrDato) {
  temporal_datos[0] = wrDir;
  temporal_datos[1] = wrDato;
  I2C1_Start();
  I2C1_Write(I2C_ADR,temporal_datos,2,END_MODE_STOP);
}
//=====================================================
// Esta funci�n lee el valor de temperatura desde el
// sensor.
// ====================================================
float LPS25HB_LeerTemperatura() {
  unsigned char temporal;
  int resultado;
  temporal = I2C_LeerRegistro(0x2C);
  resultado = (int) temporal;
  temporal = I2C_LeerRegistro(0x2B);
  resultado = (resultado << 8) | temporal;
  return ((float)resultado / 480) + 42.5;
}
//=====================================================
// Esta funci�n lee en los registros internos
// del sensor.
// ====================================================
unsigned char I2C_LeerRegistro(char rDir) {
  temporal_datos[0] = rDir;
  I2C1_Start();
  I2C1_Write(I2C_ADR,temporal_datos,1,END_MODE_RESTART);
  I2C1_Read(I2C_ADR,temporal_datos,1,END_MODE_STOP);
  return temporal_datos[0];
}

/*********************** PROGRAMA PRINCIPAL *********************************/
void main(){
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  Delay_ms(200);
  Lcd_Out(1,2,"Sensor Barometrico");   // Carteles iniciales
  Lcd_Out(2,7,"LPS25HB");
  Lcd_Out(3,1,"Temperatura:  ");
  Lcd_Out(4,1,"P/Milibares:");
  device_id = I2C_LeerRegistro(0x0F); // Lee ID del sensor Barom�trico
  if(device_id != 0xBD){
  Lcd_Out(2,1,"ERROR de Sensor");
   while(1);
  }
  I2C_EscribirRegistro(0x20,0xB0);  // Configura el sensor

  while(1) {
  unsigned char status;
  Status = LPS25HB_LeerStatus();
  if(status & 0x01) {
       temperatura = LPS25HB_LeerTemperatura();  // Lee temperatura
       sprintf(temporal_datos, "%2.2f", temperatura);
       Lcd_Out(3,13,temporal_datos);
       }
  Delay_ms(250);
  if(status & 0x02) {
       presion = LPS25HB_LeerPresMilibares(); // Lee presi�n en milibares
       sprintf(temporal_datos, "%4.0f", presion);
       Lcd_Out(4,13,temporal_datos);
       }
  Delay_ms(250);
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************