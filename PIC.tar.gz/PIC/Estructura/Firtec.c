/****************************************************************************
**  Descripci�n  : Lectura de dos canales anal�gicos (PIN2 y PIN3) mediante
**                 una estructura que almacena los datos le�dos.
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 20MHZ
****************************************************************************/
 #include "Str_lcd.h" // Archivo con declaraci�nes

 /*Estructura con los datos de los Canales A/D */
 struct Conversor{
 float Canal_0;    // Contiene los datos de AN0
 float Canal_1;    // Contiene los datos de AN1
 }Medir;  // Rotulo para acceder a los miembros de la estrucutra

 void ISR_Timer() iv 0x0008 ics ICS_AUTO {
  // Reset the timer count
  TMR0H=0xF8;
  TMR0L=0x30;
  PORTC.B2 = ~PORTC.B2;  // Cambia de estado pin 33
  bandera = 1;
  INTCON.TMR0IF = 0;
}

void Leer_Conversor(){

   GO_DONE_bit =1;
   while(GO_DONE_bit);
   voltaje = ADC_Read(canal);
   GO_DONE_bit =0;
   //PORTC.B2 = ~PORTC.B2;
}

void main() {
  TRISA = 0x03;          // RA0 y RA1 son entradas
  ADCON1 = 0x0D;         // Dos canales anal�gicos AN0 y AN1
  ADCON2 = 0b10010100;   // Configura el reloj del conversor
  TRISC2_bit  = 0;       // Bit 2 del puerto C es salida
  PORTC.B2 = 0;          // LED inicia apagado

  INTCON.PEIE=1;        //peripharel interrupt enable
  INTCON.TMR0IF = 0x0;  //Clear timer0 overflow interrupt flag
  INTCON.TMR0IE = 1;    //enable the timer0 by setting TRM0IE flag

  T0CON.T08BIT = 0;     // 16 Bit timer
  T0CON.T0CS = 0;       // Internal clock
  T0CON.PSA = 1;        // Set scaler to 1:4
  TMR0H = 0xF8;         // Initial count of 0xF830
  TMR0L = 0x30;
  T0CON.TMR0ON = 1;     // Turn Timer0 on.
  PIE1.ADIE = 0;        // Interrupci�n del conversor desactivada
  INTCON.GIE=1;         //globle interrupt enable

  Lcd_Init();                      // Configura el LCD
  Delay_ms(10);                    // Espera 10 milisegundos
  Lcd_Cmd(_LCD_CLEAR);             // Limpia la pantalla
  Lcd_Cmd(_LCD_CURSOR_OFF);        // Apaga el cursor
  Lcd_Out(1, 4, "VOLTIMETRO");     // Carteles iniciales en el LCD
  Lcd_Out(2,1, "A0: ");
  Lcd_Out(2,10, "A1: ");

   while(1){
    if(bandera){
        switch(canal){
             case 0:{
                   canal = 0;
                   Delay_us(100);
                   Leer_Conversor();
                   Medir.Canal_0 = voltaje;
                   canal ++;
                   bandera =0;
                   break;
              }
             case 1:{
                  Delay_us(100);
                  Leer_Conversor();
                  Medir.Canal_1 = voltaje;
                  canal =0;
                  bandera =0;
                  break;
              }
        }
     }
     LcdFloat(2,4,((Medir.Canal_0 * 5.0)/1024),2);   // Muestra el canal 0
     LcdFloat(2,13,((Medir.Canal_1 * 5.0)/1024),2);  // Muestra el canal 1

   }
 }