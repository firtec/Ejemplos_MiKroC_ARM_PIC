/****************************************************************************
**  Descripci�n  : Manejo de un sensor de posici�n RPI-1035
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 40MHZ - (XTAL 10Mhz con PLLx4)
**  NOTA         : Pines del sensor: VO1 a RC0 (p15) y VO2 a PB0(p33)
*****************************************************************************/
// Pines asignados al LCD
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

 sbit Tilt_V01 at RC0_bit;
 sbit Tilt_V02 at RB0_bit;
 sbit Tilt_V01_Direction at TRISC0_bit;
 sbit Tilt_V02_Direction at TRISB0_bit;


void main() {
  char k = 0, t;
  CMCON |=7;
  ADCON1 = 0x0f;
  Tilt_V01_Direction = 1;       // Configura RC0 como entrada
  Tilt_V02_Direction = 1;       // Configura RB0 como entrada

  LCD_Init();
  Lcd_Cmd(_LCD_CURSOR_OFF);
  LCD_Cmd(_LCD_CLEAR);
  Lcd_Out(1,1,"Sensor RPI-1035");

  while (1) {
    if ((Tilt_V02 == 1) & (Tilt_V01 == 0)){
     Lcd_Out(2,5,"Izquierda    ");
    }

    if ((Tilt_V02 == 0) & (Tilt_V01 == 1)){
     Lcd_Out(2,5,"Derecha    ");

    }

    if ((Tilt_V02 == 1) & (Tilt_V01 == 1)){
      Lcd_Out(2,5,"Arriba    ");

    }

    if ((Tilt_V02 == 0) & (Tilt_V01 == 0)){
    Lcd_Out(2,5,"Abajo    ");

    }

    Delay_ms(10);
  }
}