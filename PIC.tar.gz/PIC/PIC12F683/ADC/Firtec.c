
/*
Como se mencion� anteriormente, 4 de 6 GPIO en un PIC12F683 
tambi�n proporcionan entradas de convertidor anal�gico a digital 
con una resoluci�n de 10 bits. Son GP0-GP2 y GP4. En este experimento 
vamos a alimentar una tensi�n anal�gica a una de las entradas ADC 
(digamos AN0, que es GP0) y mostrar el valor digital de salida en una 
ventana hiper-terminal en la PC. El voltaje anal�gico ser� simulado 
con el potenci�metro en nuestro tablero.

Configuraci�n experimental:
Conectar la salida del potenci�metro (POT2) a AN0 (pin 7). GP5 (pin 2) 
servir� como pin de TX para el Software UART as� que con�ctelo a la 
entrada Tx de TTL a RS232 Level Shifter circuito. Tambi�n conecte 
Rx (2) y Gnd (5) de un puerto RS232 a la placa.

  PIC12F683 Experiment Board
  Experimen No. 3 : Read analog voltage from AN0 and diplay
  on Hyperterminal window on PC using Software UART.
  Date: 06/25/2010
*/
char Message1[] = "Dato del conversor = ";
unsigned int adc_value, backup=0 ;
char *temp = "0000", error;
int i;
void main() {
OSCCON = 0b01110101; // Oscilador interno en 8MHz
CMCON0 = 7;
TRISIO = 11;  // GPIO 0, 1, 3 Inputs; Rest are O/Ps
ANSEL = 0x01;
GPIO = 0;
// Define GPIO.3 as UART Rx, and 5 as Tx
error = Soft_UART_Init(&GPIO,3, 5, 9600, 0 );
Delay_ms(100);

do {
 adc_value = ADC_Read(0);


 if(adc_value != backup) {

  if (adc_value/1000)
   temp[0] = adc_value/1000 + 48;
  else
  temp[0] = '0';

  temp[1] = (adc_value/100)%10 + 48;
  temp[2] = (adc_value/10)%10 + 48;
  temp[3] = adc_value%10 + 48;

 for (i=0; i<= 20; i++) {
      Soft_UART_Write(Message1[i]);
      Delay_ms(50);
     }

 for (i=0; i<= 3; i++) {
      Soft_UART_Write(temp[i]);
      Delay_ms(50);
     }
     Soft_UART_Write(10); // Line Feed
     Soft_UART_Write(13); // Carriage Return

 backup = adc_value;
 }

 delay_ms(100);
 } while(1);
}


/*
sbit led at GP2_bit;
void main() {
    TRISIO.B2 = 0;
    OSCCON = 0b01110101; // Oscilador interno en 8MHz
    ADCON0 = 0;                         // all pins digital
    ANSEL = 0;                          // all pins digital
    CMCON0 = 7;                         // Comparators off.

    while (1){
       //led = 1;
       led = !led;                      // All LEDs off
       Delay_ms(1000);
       //led = 0;
       //Delay_ms(500);
    }
}

*/