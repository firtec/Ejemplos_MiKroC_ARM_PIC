/**************************************************************************************************
* File: ACCEL_Test.c
* File Type: C - Source Code File
* Project Name: Accel
* Company: (c) mikroElektronika, 2011
* Revision History:
*       - initial release;
* Description:
*     This module demonstrates communication with 3-axis digital
*     accelerometer ADXL345 ac:Accel on mmB STM32 M3. Values from accelerometer
*     are shown on the TFT display.
* Test configuration:
*    MCU:             STM32F207VG
*                     http://www.st.com/internet/com/TECHNICAL_RESOURCES/TECHNICAL_LITERATURE/DATASHEET/CD00237391.pdf
*    Dev.Board:       mikromedia for STM32 M3 - ac:MMB
*                     http://www.mikroe.com/eng/products/view/853/mikromedia-for-stm32-m3/
*    Oscillator:      HSI-PLL, 120.000MHz
*    SW:              mikroC PRO for ARM
*                     http://www.mikroe.com/eng/products/view/752/mikroc-pro-for-arm/
* NOTES:
*     I2C bus is used for communication with accel.
**************************************************************************************************/
#include "ACCEL_Test.h"
#include "resources.h"
#include "built_in.h"
/*************************************************************************************************/
char cACCEL_test_status;

// TFT module connections
unsigned int TFT_DataPort at GPIOE_ODR;
sbit TFT_RST at GPIOE_ODR.B8;
sbit TFT_RS at GPIOE_ODR.B12;
sbit TFT_CS at GPIOE_ODR.B15;
sbit TFT_RD at GPIOE_ODR.B10;
sbit TFT_WR at GPIOE_ODR.B11;
sbit TFT_BLED at GPIOE_ODR.B9;
// End TFT module connections

/*************************************************************************************************
* Draw Accel Screen function
**************************************************************************************************/
void DrawAccelScr() {
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_Black, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("ACCEL  TEST", 75, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("mikromedia for STM32 M3", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

void InitMCU(){
  // TFT config
  GPIO_Config(&GPIOE_BASE, _GPIO_PINMASK_9, _GPIO_CFG_DIGITAL_OUTPUT);
  // Init TFT
  TFT_Set_Default_Mode();
  TFT_Init_ILI9341_8bit(320, 240);
  Delay_ms(1000);
  TFT_BLED = 1;
}

/**************************************************************************************************
* Function Accel_Average()
* -------------------------------------------------------------------------------------------------
* Overview: Function calculate the average values of the X, Y and Z axis reads
* Input: Nothing
* Output: X,Y and Z values are stored in readings[] buffer
**************************************************************************************************/
void Accel_Average() {
  int i, sx, sy, sz;

  // sum
  sx = sy = sz = 0;

  // average accelerometer reading over last 16 samples
  for (i=0; i<16; i++) {
    sx += Accel_ReadX();
    sy += Accel_ReadY();
    sz += Accel_ReadZ();
  }
  // average
  readings[0] = sx >> 4;
  readings[1] = sy >> 4;
  readings[2] = sz >> 4;
}

/**************************************************************************************************
* Function Display_X_Value()
* -------------------------------------------------------------------------------------------------
* Overview: Function display average X-axis read value on TFT
* Input: value stored in readings[0] buffer
* Output: Nothing
**************************************************************************************************/
void Display_X_Value() {
  TFT_Rectangle(160, 100, 200, 115);
  TFT_Write_Text("X: ", 140, 100);
  IntToStr(readings[0], out);
  TFT_Write_Text(out, 160, 100);
  Delay_ms(100);
}

/**************************************************************************************************
* Function Display_Y_Value()
* -------------------------------------------------------------------------------------------------
* Overview: Function display average Y-axis read value on TFT
* Input: value stored in readings[1] buffer
* Output: Nothing
**************************************************************************************************/
void Display_Y_Value() {
  TFT_Rectangle(160, 130, 200, 145);
  TFT_Write_Text("Y: ", 140, 130);
  IntToStr(readings[1], out);
  TFT_Write_Text(out, 160, 130);
  Delay_ms(100);
}

/**************************************************************************************************
* Function Display_Z_Value()
* -------------------------------------------------------------------------------------------------
* Overview: Function display average Z-axis read value on TFT
* Input: value stored in readings[2] buffer
* Output: Nothing
**************************************************************************************************/
void Display_Z_Value() {
  TFT_Rectangle(160, 160, 200, 175);
  TFT_Write_Text("Z: ", 140, 160);
  IntToStr(readings[2], out);
  TFT_Write_Text(out, 160, 160);
  Delay_ms(100);
}

/**************************************************************************************************
* Function ACCEL_Start()
* -------------------------------------------------------------------------------------------------
* Overview: Function Initialize I2C bus and accel module
* Input: Nothing
* Output: test status: 0 - skiped; 1 - pass; 2 - fail
**************************************************************************************************/
void ACCEL_Start(char *test) {
  // Reset error flag
  *test = 0;

  // Initialize I2C communication
  I2C1_Init_Advanced(400000, &_GPIO_MODULE_I2C1_PB67);

  TFT_Set_Font(TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
  TFT_Set_Pen(CL_WHITE, 1);
  TFT_Set_Brush(1, CL_WHITE, 0, 0, 0, 0);

  TFT_Write_Text("Starting Accel test...", 90, 100);
  Delay_ms(2000);
  TFT_Rectangle(70, 70, 250, 130);

  // Initialize ADXL345 accelerometer
  if (ADXL345_Init() == 0) {
    TFT_Write_Text("Accel module initialized.", 90, 100);
    *test = 1;
    Delay_ms(2000);
  }
  else {
    TFT_Write_Text("Error during Accel module initialization.", 90, 100);
    *test = 2;
  }

  TFT_Rectangle(70, 70, 250, 130);
}

/**************************************************************************************************
* Function ACCEL_Test()
* -------------------------------------------------------------------------------------------------
* Overview: Function run the accel test
* Input: Nothing
* Output: Nothing
**************************************************************************************************/
void ACCEL_Test(void) {
  TFT_Write_Text("Reading axis values :", 90, 70);
  Accel_Average();               // Calculate average X, Y and Z reads
  Display_X_Value();             // Display average X value read
  Display_Y_Value();             // Display average Y value read
  Display_Z_Value();             // Display average Z value read
  Delay_ms(100);
}

/**************************************************************************************************
* main function
**************************************************************************************************/

void main() {
  InitMCU();
  DrawAccelScr();
  ACCEL_Start(&cACCEL_test_status);
  while (1){
    ACCEL_Test();
  }
}

/**************************************************************************************************
* End of File
**************************************************************************************************/