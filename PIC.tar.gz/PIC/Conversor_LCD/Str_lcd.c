           /******************************************************************************
*  Funci�n para convertir dato float en ASCII y mostrarlo en una coordenada
*  X - y determinada del LCD.
******************************************************************************/
void LcdFloat(unsigned char x,unsigned char y, float num, unsigned char dec){
unsigned char fila = 0;
unsigned char a = 0;
unsigned char nent = 0;
unsigned long ent = num;
float decimales = num;
float resultado = 0;
unsigned long rdec = 0;
unsigned char texto[10];

 fila = x;
 for(a=0;ent>0;a++){
   ent /= 10;
   nent++;
 }
 if(nent==0) nent=1;
 ent=num;
 resultado = decimales-ent;

 for(a=1;a<=dec;a++)
   resultado*=10;
 for(a=0;a<nent;a++){
   texto[a]=ent%10;
   ent/=10;
 }
 for(a=nent;a>0;a--)
   Lcd_Chr(fila,y++,texto[a-1]+48);
 Lcd_Chr_cp('.');
 y++;
 rdec=resultado;
 for(a=0;a<dec;a++){
   texto[a]=rdec%10;
   rdec/=10;
 }
 for(a=dec;a>0;a--)
 Lcd_Chr(fila,y++,texto[a-1]+48);
}