
// LCD module connections
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

char dato, texto[]="Programa en C.";
unsigned char i=0;

void main() {
  Lcd_Init();
  Delay_ms(100);
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  I2C1_Init(100000);            //Inicializa la comunicaci�n I2C.
    //Lcd_Out(1,1,"I2C 24LC256");

  
  //Escritura de una p�gina con los datos de la cadena.
I2C1_Start();           //Env�a una se�al de START.
I2C_Write(0b10100000); //Byte de Control. Operaci�n de escritura.
I2C_Write(0x3B);       //MSByte de direcci�n.
I2C_Write(0x00);       //LSByte de direcci�n.
while (texto[i] != 0x00){
 I2C_Write(texto[i]);  //Dato.
 i++;
}
I2C_Write(0x00);       //Dato (car�cter NULO).
I2C_Stop();            //Env�a una se�al de STOP.
Delay_ms(5);                //Ciclo interno de escritura.
 
//Lectura secuencial desde la memoria.
I2C_Start();           //Env�a una se�al de START.
I2C_Write(0b10100000); //Byte de Control. Operaci�n de escritura.
I2C_Write(0x3B);       //MSByte de direcci�n.
I2C_Write(0x00);       //LSByte de direcci�n.
I2C_Start();
I2C_Write(0b10100001); //Byte de Control. Operaci�n de lectura.
do{
 dato= I2C_Read(1);     //Lee un dato y responde con ACK.
 if(dato !=0)
 Lcd_Chr_CP(dato);          //Env�a el car�cter al LCD.
}
while (dato != 0x00);
dato= I2C_Read(0);      //Lee el �ltimo dato (NULO) y responde con NO ACK.
 I2C_Stop();            //Env�a una se�al de STOP.

  while(1);

}
