#ifndef ZIGBEE_RECEPTOR_RESOURCES
#define ZIGBEE_RECEPTOR_RESOURCES

const code char Tahoma_29x35_Regular[];
const code char Tahoma_43x52_Regular[];
const code char Tahoma_85x103_Regular[];

#endif
