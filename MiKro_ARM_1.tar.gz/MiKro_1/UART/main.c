/*****************************************************************************
*  Descripci�n  : Ejemplo de uso para el puerto UART.
*                 Este ejemplo utiliza UART2 -> Delay_us [PA2 TX|PA3 RX] .
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

char caracter;   // Contenedor para el dato recibido

void main(){
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off

UART2_Init_Advanced(9600, _UART_8_BIT_DATA, _UART_NOPARITY,
                            _UART_ONE_STOPBIT, &_GPIO_MODULE_USART2_PA23);

  //UART2_Init(9600);                  // 9600 Baudios
  Delay_ms(100);
  Lcd_Out(1,5,"Ejemplo UART");      // Carteles iniciales
  Lcd_Out(2,1,"Dato Recibido:  ");
  Lcd_Out(4,2,"www.firtec.com.ar");
  UART2_Write_Text("Esperando Datos");
  UART2_Write(13);
  UART2_Write(10);

  while(1) {                         // Bucle infinito
      if (UART2_Data_Ready()){
         caracter = UART2_Read();     // Lee el registro del receptor
         Lcd_Chr(2,15,caracter);      // Muestra el caracter recibido
         UART2_Write(caracter );
         //UART2_Write_Text("ISR");
          //if (UART2_Tx_Idle() == 1) {
          //  UART2_Write_Text("ISR");
           // UART2_Write(caracter );
     //}
        // UART2_Write(caracter);       // Env�a el caracter recibido
    }
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************