/***********************************************************************
*  Descripci�n  : Env�o de datos con un modulo WiFi ESP8266. Se conecta
*                 a la red enviando los datos de temperatura y humedad
*                 de un sensor  I2C Texas HDC1000.
*                 los datos tambi�n se muestran en un LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC 5
*
*         www.firtec.com.ar
************************************************************************/
 void Configurar_ESP8266(void);
// Pines asignados el LCD
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
// Definiciones para el sensor HDC1000
#define HDC1000_I2C_ADDR        0x40             //Sensor address                                                                              //Jumper ADR0 = 0                                                                             //Jumper ADR1 = 0
#define TEMP_I2C_ADDR           0x00
#define DEVICEID_I2C_ADDR       0xFF
#define Tconstant               0.0025177      //For 14bit resolution
#define Hconstant               0.0015259      //For 14bit resolution
// Variables usadas en el proyecto
char tmp_data[12];
char floatStr[12];
float temperature;
float humidity;
float dewpoint;
unsigned int device_id = 0;
unsigned int temp_value,humidity_value;
unsigned char x =0;
/******************************************************************************
* Funci�n para el env�o de cadenas por el puerto UART.
******************************************************************************/
void Enviar_String(const char *s)
{
  while(*s)
  {
    UART2_Write(*s++);
  }
}
/******************************************************************************
*  Funci�n leer el sensor HDC1000. 
*  Retorna el valor de temperatura y la humedad.
******************************************************************************/
void Leer_Sensor() {
  tmp_data[0] = TEMP_I2C_ADDR;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,1,END_MODE_RESTART);
  delay_ms(20);
  I2C1_Read(HDC1000_I2C_ADDR,tmp_data,4,END_MODE_STOP);
  temp_value = (tmp_data[0] << 8) + tmp_data[1];
  humidity_value = (tmp_data[2] << 8) + tmp_data[3];
  temperature = ((float)temp_value * Tconstant)-40;
  humidity = (float)humidity_value * Hconstant;
}
/******************************************************************************
*  Configura el sensor con los valores provistos por el fabricante.
******************************************************************************/
void Config_Sensor(){
  tmp_data[0] = 0x02;
  tmp_data[1] = 0x10;
  tmp_data[2] = 0x00;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,3,END_MODE_STOP);
  delay_ms(5);
}
/******************************************************************************
*  Lectura del ID del sensor que debe corresponder con 0x1000.
******************************************************************************/
unsigned int Leer_SensorID() {
 unsigned int id_value;
  tmp_data[0] = DEVICEID_I2C_ADDR;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,1,END_MODE_RESTART);
  I2C1_Read(HDC1000_I2C_ADDR,tmp_data,2,END_MODE_STOP);
  id_value = (tmp_data[0] << 8) + tmp_data[1];
  return id_value;
}

/************************* PROGRAMA PRINCIPAL ********************************/
void main(){
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  UART2_Init(9600);
  Delay_ms(500);
  Lcd_Out(1,2,"Socket con MiKroC");      // Carteles iniciales
  Lcd_Out(3,1,"Conectando.....");
  device_id = Leer_SensorID();
        if(device_id != 0x1000){
               Lcd_Out(2,1,"ERROR de Sensor");
              while(1);
        }
  Config_Sensor();
  Configurar_ESP8266();
  Lcd_Out(3,1,"IP/Serv:192.168.1.12");
  Lcd_Out(4,2,"www.firtec.com.ar");
  while(1) {
  char caracter;
           Leer_Sensor();
           sprintf(floatStr,"%2.1f - %2.1f%% ", temperature,humidity);
           Enviar_String(floatStr);
           sprintf(floatStr,"Temp:%2.1f ",temperature);
           Lcd_Out(2,1,floatStr);
           sprintf(floatStr,"Hum:%2.1f%%",humidity);
           Lcd_Out(2,11,floatStr);
           Delay_ms(500);
  }
}
/****************************************************************
* Configuraci�n b�sica para crear un cliente UDP sobre una IP y
* puerto determinado.
* IMPORTANTE_1: los pines PA2 se conecta a RX del ESP8266 y el
* pin PA3 al TX .
*
* IMPORTANTE_2:
* Se supone que los datos de conexi�nes WiFi (SSI y PASS) ya
* fueron cargados antes ya que estos datos no se pierden si el
* modulo se apaga o resetea, pero si la configuraci�n del socket.
* Esta configuraci�n dispone el modo wifi para que todo lo enviado
* por la USART pase directamente al socket.
* (Transparent Transmission Mode)
*
*****************************************************************/
void Configurar_ESP8266(void){
        Enviar_String("AT+RST\r\n");  // Reset general del m�dulo.
        Delay_ms(2000);
        Enviar_String("AT\r\n");        // Comando de control
        Delay_ms(500);
        Enviar_String("AT+CIPSTART=");  // Configura el Socket UDP
        Enviar_String("\"");
        Enviar_String("UDP");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("\"");
        Enviar_String("192.168.1.12");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("30000\r\n");
        Delay_ms(500);
        Enviar_String("AT+CIPMODE=1\r\n"); // Activa el modo " TX transparente"
        Delay_ms(500);
        Enviar_String("AT+CIPSEND\r\n");  // Confirmo el modo
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************