/*****************************************************************
*  Descripci�n  : Driver para el RFID ClicK de MiKroElectronica.
*                 El modulo utiliza el chip CR95HF.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC pro para ARM 5
*  www.firtec.com.ar - consulas@firteconline.com.ar															www.firtec.com.ar
******************************************************************/
#include "CR95HF_Driver.h"

sbit CS at GPIOB_ODR.B12;
extern unsigned short tmp;
unsigned short res = 0, dataNum = 0;
unsigned short j = 0, tmp = 0;
char bandera = 0;
unsigned char NFC_bandera = 1;
unsigned char TAG_bandera = 0;
unsigned short rdata[18];
unsigned short sdata[18];
char ID[38];
char txt_hex[3];
char CR95HF_ID[13];

void AutoFDet() {
  sdata[0] = 0x09;
  sdata[1] = 0x04;
  sdata[2] = 0x0A;
  sdata[3] = 0x01;
  sdata[4] = 0x02;
  sdata[5] = 0xA1;
  Escribe_Comando(WrReg, 6);
  Leer_Comando();
}
/**********************************************
* Funci�n para lee el TAG ID
***********************************************/
void Buscar_TagID() {
  sdata[0] = 0x26;
  sdata[1] = 0x07;
  Escribe_Comando(SendRecv , 2);
  Leer_Comando();

  sdata[0] = 0x93;
  sdata[1] = 0x20;
  sdata[2] = 0x08;
  Escribe_Comando(SendRecv , 3);
  Leer_Comando();

  if(res == 0x80) {
    for(j=1; j<dataNum-3; j++) {
      ByteToHex(rdata[j], txt_hex);
      strcat(ID, txt_hex);
    }
    TAG_bandera = 1;
  }
  else {
    TAG_bandera = 0;
    Protocolo_18092();
  }
}

/**********************************************
* Funci�n para lee el NFC TAG
***********************************************/
void Buscar_NFCTag() {
  sdata[0] = 0x00;
  sdata[1] = 0xFF;
  sdata[2] = 0xFF;
  sdata[3] = 0x00;
  sdata[4] = 0x00;
  Escribe_Comando(SendRecv, 5);
  Leer_Comando();

  if(res == 0x80){
    for(j=0; j<dataNum; j++){
      ByteToHex(rdata[j], txt_hex);
      strcat(ID, txt_hex);
    }
    NFC_bandera = 1;
  }
  else {
    NFC_bandera = 0;
    Protocolo_14443_A();
  }
}
/**********************************************
* Seleciona el protocolo de RF ISO/IEC 14443-A
***********************************************/
void Protocolo_14443_A(){
  sdata[0] = 0x02;
  sdata[1] = 0x00;
  Escribe_Comando(ProtocolSelect, 2);
  Leer_Comando();
  for(j=0; j<18; j++ ){
    rdata[j] = 0;
    sdata[j] = 0;
  }
}
/**********************************************
* Seleciona el protocolo de RF ISO/IEC 18092
***********************************************/
void Protocolo_18092(){
  sdata[0] = 0x04;
  sdata[1] = 0x51;
  Escribe_Comando(ProtocolSelect, 2);
  Leer_Comando();
  for(j=0; j<18; j++ ){
    rdata[j] = 0;
    sdata[j] = 0;
  }
}
/**********************************************
* Esta funci�n ajusta el comportamiento de RF
* Configuraci�n con valores sacados de la hoja
* de datos del chip.
***********************************************/
void RF_Config(){
  sdata[0] = 0x09;
  sdata[1] = 0x04;
  sdata[2] = 0x68;
  sdata[3] = 0x01;
  sdata[4] = 0x01;
  sdata[5] = 0x50;
  Escribe_Comando(WrReg, 6);
  Leer_Comando();
}
/************************************************************
*   Esta funci�n interroga la presencia del chip CR95HF.
*   Env�a el commando 0x55 esperando un eco desde CR95HF
************************************************************/
char EchoResponse() {
  CS = 0;
  SPI2_Write(0x00);  // Byte de control
  SPI2_Write(ECHO);
  CS = 1;

  while(1){
    CS = 0;
    SPI2_Write(0x03);
    tmp = SPI2_Read(0);
    CS = 1;

    if((tmp & 0x08) >> 3){
      CS = 0;
      SPI2_Write(0x02);
      tmp = SPI2_Read(0);
      CS = 1;
      if(tmp == ECHO){
        return 1;
      }
      return 0;
    }
  }
}

/*********************************************************
* Esta funci�n lee datos en el chip CR95HF respetando el
* protocolo activo en ese momento.
**********************************************************/
void Leer_Comando(){
  unsigned short i = 0;
  while(1){
    CS = 0;
    SPI2_Write(0x03);
    res = SPI2_Read(0);
    CS = 1;

    if((res & 0x08) >> 3){
      CS = 0;
      SPI2_Write(0x02);
      res = SPI2_Read(0);
      dataNum = SPI2_Read(0);
      for(i=0; i<dataNum; i++)
        rdata[i] = SPI2_Read(0);
      CS = 1;
      break;
    }
    CS = 1;
    Delay_ms(10);
  }
}
/*************************************************************
* Esta funci�n ecribe un comando en el chip CR95HF respetando
* el formato de datos que el chip espera recibir.
**************************************************************/
void Escribe_Comando(unsigned short cmd, unsigned short dataLen){
  unsigned short i = 0;

  CS = 0;
  SPI2_Write(0x00);  // Byte de control
  SPI2_Write(cmd);
  SPI2_Write(dataLen);
  while (dataLen == 0){
    CS = 1;
    break;
  }
  for(i=0; i<dataLen; i++){
    SPI2_Write(sdata[i]);
  }
  CS = 1;
}
/*************************************************
* Esta funci�n calibra el CR95HF con los valores
* indicados en la hoja de datos del chip.
**************************************************/
void Calibrar_CR95HF() {
unsigned char x = 0;
do{
  sdata[0] = 0x03;
  sdata[1] = 0xA1;
  sdata[2] = 0x00;
  sdata[3] = 0xF8;
  sdata[4] = 0x01;
  sdata[5] = 0x18;
  sdata[6] = 0x00;
  sdata[7] = 0x20;
  sdata[8] = 0x60;
  sdata[9] = 0x60;
  sdata[10] = 0x00;
  sdata[11] = 0x00;
  sdata[12] = 0x3F;
  sdata[13] = 0x01;
  Escribe_Comando(Idle, 0x0E);
  Leer_Comando();
        x++;
  }while(x < 6);
 }
/********************************************************
*   Esta funci�n env�a el comando para solicitar el ID
*   del chip CR95HF conectado.
********************************************************/
void Leer_CR95HF_ID() {
unsigned char x =0;
do{
  Escribe_Comando(IDN, 0);
  Leer_Comando();
  for(j=0; j<dataNum; j++){
    CR95HF_ID[j] = rdata[j];
  }
  x++;
 }while(x < 3);
}
