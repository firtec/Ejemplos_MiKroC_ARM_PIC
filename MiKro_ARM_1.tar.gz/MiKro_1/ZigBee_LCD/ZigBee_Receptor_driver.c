#include "ZigBee_Receptor_objects.h"
#include "ZigBee_Receptor_resources.h"
#include "built_in.h"
#include "FT812_Types.h"


// TFT module connections
sbit FT812_RST at GPIOE_ODR.B10;
sbit FT812_CS at GPIOB_ODR.B12;
sbit FT812_RST_Direction at GPIOC_ODR.B1;
sbit FT812_CS_Direction at GPIOA_ODR.B1;
// End TFT module connections

// Object type constants
// Usage: VTFT stack internally
const VTFT_OT_LABEL  = 4;
const VTFT_OT_CLABEL = 5;
// ~Object type constants

// Event type constants
// Usage: OnEvent
const VTFT_EVT_UP    = 0;
const VTFT_EVT_DOWN  = 1;
const VTFT_EVT_CLICK = 2;
const VTFT_EVT_PRESS = 3;
// ~Event type constants

// Sound action constants
// Usage: sound event action property and ProcessEvent
const VTFT_SNDACT_NONE  = 0;
const VTFT_SNDACT_PLAY  = 1;
const VTFT_SNDACT_STOP  = 2;
// ~Sound action constants

// Resource loading constants.
// Usage: DrawScreenO and LoadCurrentScreenResToGRAM
const VTFT_LOAD_RES_NONE    = 0x00; // do not load g-ram resources
const VTFT_LOAD_RES_STATIC  = 0x01; // load g-ram resources for static objects
const VTFT_LOAD_RES_DYNAMIC = 0x02; // load g-ram resources for dynamic objects
const VTFT_LOAD_RES_ALL     = 0x03; // load g-ram resources for all objects
// ~Resource loading constants

// Display effect constants
// Usage: DrawScreenO
const VTFT_DISPLAY_EFF_NONE         = 0x00; // no effect when switching between screens
const VTFT_DISPLAY_EFF_LIGHTS_FADE  = 0x04; // backlight: fade out before, fade in after drawing new screen
const VTFT_DISPLAY_EFF_LIGHTS_OFF   = 0x08; // backlight: turn off before, turn on after drawing new screen
// ~Display effect constants

// Stack flags
// Usage: internally used by VTFT stack
const VTFT_INT_REPAINT_ON_DOWN     = 1 << 0;
const VTFT_INT_REPAINT_ON_UP       = 1 << 1;
const VTFT_INT_BRING_TO_FRONT      = 1 << 2;
const VTFT_INT_INTRINSIC_CLICK_EFF = 1 << 3;
// ~Stack flags

// Table of object draw handlers
// Use object type constants to access coresponding object draw handler
const TPointer DrawHandlerTable[44] = {
  0,               // Button draw handler not used
  0,               // CButton draw handler not used
  0,               // ButtonRound draw handler not used
  0,               // CButtonRound draw handler not used
  &DrawLabel,      // Label draw handler
  &DrawCLabel,     // CLabel draw handler
  0,               // Image draw handler not used
  0,               // CImage draw handler not used
  0,               // Circle draw handler not used
  0,               // CCircle draw handler not used
  0,               // CircleButton draw handler not used
  0,               // CCircleButton draw handler not used
  0,               // Box draw handler not used
  0,               // CBox draw handler not used
  0,               // BoxRound draw handler not used
  0,               // CBoxRound draw handler not used
  0,               // Line draw handler not used
  0,               // CLine draw handler not used
  0,               // Polygon draw handler not used
  0,               // CPolygon draw handler not used
  0,               // CheckBox draw handler not used
  0,               // RadioButton draw handler not used
  0,               // ProgressBar draw handler not used
  0,               // Audio draw handler not used
  0,               // EveClock draw handler not used
  0,               // EveGauge draw handler not used
  0,               // EveDial draw handler not used
  0,               // EveKeys draw handler not used
  0,               // CEveKeys draw handler not used
  0,               // EveProgressBar draw handler not used
  0,               // EveScrollBar draw handler not used
  0,               // EveToggle draw handler not used
  0,               // EveSlider draw handler not used
  0,               // EveSpinner draw handler not used
  0,               // EveScreenSaver draw handler not used
  0,               // EveSketch draw handler not used
  0,               // EveButton draw handler not used
  0,               // CEveButton draw handler not used
  0,               // EveGradient draw handler not used
  0,               // CEveGradient draw handler not used
  0,               // EveText draw handler not used
  0,               // CEveText draw handler not used
  0,               // EveNumber draw handler not used
  0                // CEveNumber draw handler not used
};
// ~Table of draw handler pointers


// Default configuration parameters
const TFT812Display VTFT_FT812_CONFIG_DISPLAY =
{
  12000000,        // Frequency          = main clock frequency
  0,               // OutRenderMode      = 0 normal, 1 write, 2 read
  0,               // RenderReadScanLine = scanline for read render mode
  0,               // RenderWriteTrigger = trigger for write render mode (read only)
  928,             // hCycle             = number if horizontal cycles for display
  32,              // hOffset            = horizontal offset from starting signal
  800,             // hSize              = width resolution
  0,               // hSync0             = hsync falls
  3,               // hSync1             = hsync rise
  525,             // vCycle             = number of vertical cycles for display
  32,              // vOffset            = vertical offset from start signal
  480,             // vSize              = height resolution
  0,               // vSync0             = vsync falls
  3,               // vSync1             = vsync rise
  0,               // Rotate             = rotate display
  0x01B6,          // OutBits            = output bits resolution
  0,               // OutDither          = output number of bits
  0x0000,          // OutSwizzle         = output swizzle
  0,               // OutCSpread         = output clock spread enable
  0,               // PClockPolarity     = clock polarity: 0 - rising edge, 1 - falling edge
  1,               // PClock             = clock prescaler of FT812: - 0 means disable and >0 means 48MHz/pclock
};

const TFT812GPIO VTFT_FT812_CONFIG_GPIO =
{
  0xFFF0,          // GPIODIR = GPIO direction: 1 - output, 0 - input (16bit wide)
  0xFFFF,          // GPIO    = GPIO data latch
};

const TFT812PWM VTFT_FT812_CONFIG_PWM =
{
  250,             // Freq = PWM frequency - 14 bits
  128,             // Duty = PWM duty cycle, 0 to 128 is the range
};

const TFT812Interrupt VTFT_FT812_CONFIG_INTERRUPT =
{
  0,               // Flags  = interrupt flags (read only)
  0,               // Enable = global interrupt enable: 1 - enabled, 0 - disabled
  255,             // Mask   = interrupt mask value (individual interrupt enable): 1 - masked/disabled, 0 - enabled
};

const TFT812Sound VTFT_FT812_CONFIG_SOUND =
{
  0,               // Volume
  {0,              // Effect
  0},              // Pitch
  0,               // Play
};

const TFT812Audio VTFT_FT812_CONFIG_AUDIO =
{
  0,               // Volume
  0,               // StartAddress
  0,               // Length
  0,               // ReadPtr
  8000,            // Frequency
  0,               // Format
  0,               // Loop = audio playback mode
  0,               // Play
};

// Global variables

TTouchStat TouchS = {0};


/////////////////////////
TScreen *CurrentScreen = 0;


TScreen Screen1;

TCLabel Encabezado = {
  &Screen1,             // Encabezado.OwnerScreen
  0,                    // Encabezado.Order
  1,                    // Encabezado.Visible
  255,                  // Encabezado.Opacity
  255,                  // Encabezado.Tag
  215,                  // Encabezado.Left
  19,                   // Encabezado.Top
  420,                  // Encabezado.Width
  57,                   // Encabezado.Height
  Encabezado_Caption,   // Encabezado.Caption
  Tahoma_43x52_Regular, // Encabezado.FontName
  0xFFFFFF,             // Encabezado.Font_Color
  1,                    // Encabezado.FontHandle
  0,                    // Encabezado.Source
  1,                    // Encabezado.Active
  0,                    // Encabezado.OnUp
  0,                    // Encabezado.OnDown
  0,                    // Encabezado.OnClick
  0                     // Encabezado.OnPress
};
const code char Encabezado_Caption[19] = "ZigBee  MRF24J40MA";
TLabel  Label1;
char    Label1_Caption[2] = "0";
TLabel  Label2;
char    Label2_Caption[2] = "0";
TLabel  Label3;
char    Label3_Caption[5] = "Text";
TLabel  Label4;
char    Label4_Caption[59] = "Temperatura                                        Humedad";
TLabel  Label5;
char    Label5_Caption[18] = "www.firtec.com.ar";

TLabel *const code Screen1_Labels[5] = {
  &Label1,              
  &Label2,              
  &Label3,              
  &Label4,              
  &Label5               
};

TCLabel *const code Screen1_CLabels[1] = {
  &Encabezado           
};


static char IsInsideObject(TObjInfo *AObjInfo, unsigned int X, unsigned int Y) {
  TRect *ptrPressRect = 0;
  TRect *ptrPressCircle = 0;

  if ((AObjInfo->HitX == X) && (AObjInfo->HitY == Y))
    return 1;

  switch (AObjInfo->Type) {
    // Label
    case VTFT_OT_LABEL: {
      ptrPressRect = (TRect *)&(((TLabel *)AObjInfo->Obj)->Left);
      break;
    }
    // CLabel
    case VTFT_OT_CLABEL: {
      ptrPressRect = (TRect *)&(((TCLabel *)AObjInfo->Obj)->Left);
      break;
    }
  }

  if (ptrPressRect) {
    if ((ptrPressRect->Left <= X) && (ptrPressRect->Left+ptrPressRect->Width-1 >= X) &&
        (ptrPressRect->Top  <= Y) && (ptrPressRect->Top+ptrPressRect->Height-1 >= Y))
      return 1;
  }
  else if (ptrPressCircle) {
    if ((ptrPressCircle->Left <= X) && (ptrPressCircle->Left+ptrPressCircle->Width*2-1 >= X) &&
        (ptrPressCircle->Top  <= Y) && (ptrPressCircle->Top+ptrPressCircle->Width*2-1 >= Y))
      return 1;
  }

  return 0;
}

void DrawLabel(TLabel *ALabel) {
  if (ALabel->Visible) {
    if (ALabel->FontHandle >= 16)
      FT812_Canvas_FontSystem(ALabel->FontHandle, ALabel->Font_Color, ALabel->Opacity);
    else
      FT812_Canvas_Font(ALabel->FontHandle, ALabel->FontName, ALabel->Source, ALabel->Font_Color, ALabel->Opacity);

    if (ALabel->Tag)
      FT812_Canvas_Tag(ALabel->Tag);

    FT812_Screen_TextPos(ALabel->Left, ALabel->Top, ALabel->Caption);
  }
}

void DrawCLabel(TCLabel *ACLabel) {
  if (ACLabel->Visible) {
    if (ACLabel->FontHandle >= 16)
      FT812_Canvas_FontSystem(ACLabel->FontHandle, ACLabel->Font_Color, ACLabel->Opacity);
    else
      FT812_Canvas_Font(ACLabel->FontHandle, ACLabel->FontName, ACLabel->Source, ACLabel->Font_Color, ACLabel->Opacity);

    if (ACLabel->Tag)
      FT812_Canvas_Tag(ACLabel->Tag);

    FT812_Screen_TextPos(ACLabel->Left, ACLabel->Top, ACLabel->Caption);
  }
}

void SetIdenticalFontSources(const code char *AFontName, unsigned long ASource) {
  char i;
  TLabel *pLabel;
  void *const code *ptrO;

  // Label
  i    = CurrentScreen->LabelsCount;
  ptrO = CurrentScreen->Labels;
  while (i--) {
    pLabel = (TLabel *)(*ptrO);
    if (pLabel->FontName == AFontName)
      pLabel->Source = ASource;
    ptrO++;
  }
}

static void ClearDynObjSource() {
  char i;
  TLabel *pLabel;
  void *const code *ptrO;

  // Label
  i    = CurrentScreen->LabelsCount;
  ptrO = CurrentScreen->Labels;
  while (i--) {
    pLabel = (TLabel *)(*ptrO);
    pLabel->Source = 0xFFFFFFFF;
    ptrO++;
  }
}

void LoadCurrentScreenResToGRAM(char loadOptions) {
  char i;
  long currSource = -1;
  long tmpDynResStart;
  TLabel  *pLabel;
  TCLabel *pCLabel;
  void *const code *ptrO;

  // clear dynamic resource addresses first, if necessary
  if (loadOptions & VTFT_LOAD_RES_DYNAMIC)
    ClearDynObjSource();

  // static resources are allocated by VTFT tool,
  // starting from address 0 in G Ram
  if (loadOptions & VTFT_LOAD_RES_STATIC) {

    // CLabel
    i    = CurrentScreen->CLabelsCount;
    ptrO = (void *)(CurrentScreen->CLabels);
    while (i--) {
      pCLabel = (TCLabel *)(*ptrO);
      if (pCLabel->FontHandle < 16)
        if (pCLabel->Source > currSource) {
          currSource = FT812_Res_LoadFontAddr(pCLabel->Source, pCLabel->FontName);
          SetIdenticalFontSources(pCLabel->FontName, currSource);
        }
      ptrO++;
    }
  }

  // dynamic resources allocation
  if (loadOptions & VTFT_LOAD_RES_DYNAMIC) {

    tmpDynResStart = CurrentScreen->DynResStart;
    if (FT812_RES_BeginLoad(tmpDynResStart)) {
      return;
    }

    // Label
    i    = CurrentScreen->LabelsCount;
    ptrO = CurrentScreen->Labels;
    while (i--) {
      pLabel = (TLabel *)(*ptrO);
      if (pLabel->FontHandle < 16)
        if (pLabel->Source == 0xFFFFFFFF) {
          currSource = FT812_Res_LoadFont(pLabel->FontName);
          pLabel->Source = currSource;
          SetIdenticalFontSources(pLabel->FontName, currSource);
        }
      ptrO++;
    }

    FT812_RES_EndLoad();
  }
}

void DrawObject(TPointer aObj, char aObjType) {
  TDrawHandler drawHandler;

  drawHandler = DrawHandlerTable[aObjType];
  if (drawHandler)
    drawHandler(aObj);
}

void DrawScreenO(TScreen *aScreen, char aOptions) {
  unsigned short cOrder, saveOrder;
  signed   int   actObjOrder;
  unsigned short pwmDuty;
  // counter variables
  char cntLabel;
  char cntCLabel;
  // pointer variables
  TLabel  *const code *pLabel;
  TCLabel *const code *pCLabel;

  // process screen switching effects
  if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_FADE) {
    FT812_PWM_Get(0, &pwmDuty);
    FT812_PWM_FadeOut(pwmDuty, 0, pwmDuty/32? pwmDuty/32 : 1, 1);
  }
  else if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_OFF) {
    FT812_PWM_Get(0, &pwmDuty);
    FT812_PWM_Duty(0);
  }

  if (CurrentScreen != aScreen) {
    // clear active object when drawing to new screen
    memset(&TouchS.ActObjInfo, 0, sizeof(TObjInfo));
  }

  CurrentScreen = aScreen;

  LoadCurrentScreenResToGRAM(aOptions);

  // init counter variables
  cntLabel  = CurrentScreen->LabelsCount;
  cntCLabel = CurrentScreen->CLabelsCount;
  // init pointer variables
  pLabel  = CurrentScreen->Labels;
  pCLabel = CurrentScreen->CLabels;

  FT812_Screen_BeginUpdateCP();

  if ((FT812_Controller.Display.Width != CurrentScreen->Width) ||
      (FT812_Controller.Display.Height != CurrentScreen->Height)) {
    FT812_Controller.Display.Width = CurrentScreen->Width;
    FT812_Controller.Display.Height = CurrentScreen->Height;
    FT812_Canvas_UnClip();

    if (FT812_Controller.Display.Width > FT812_Controller.Display.Height) {
      FT812_CP_CmdSetRotate(VTFT_FT812_CONFIG_DISPLAY.Rotate180 % 2);
    }
    else {
      FT812_CP_CmdSetRotate((VTFT_FT812_CONFIG_DISPLAY.Rotate180 % 2) + 2);
    }
  }

  FT812_Canvas_BrushSingleColor(_FT812_BRUSH_STYLE_SOLID, CurrentScreen->Color, 255);
  FT812_Canvas_Tag(0);
  FT812_Screen_Clear(_FT812_CLEAR_ALL);
  FT812_CP_CmdStop();

  actObjOrder = -1;
  if (TouchS.ActObjInfo.Obj)
    if (TouchS.ActObjInfo.Flags & VTFT_INT_BRING_TO_FRONT)
      actObjOrder = TouchS.ActObjInfo.Order;

  cOrder = 0;
  while (cOrder < CurrentScreen->ObjectsCount) {
    saveOrder = cOrder;
    if (pLabel) {
      while ((*pLabel)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawLabel(*pLabel);
        cOrder++;
        pLabel++;
        cntLabel--;
        if (!cntLabel) {
          pLabel = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pCLabel) {
      while ((*pCLabel)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawCLabel(*pCLabel);
        cOrder++;
        pCLabel++;
        cntCLabel--;
        if (!cntCLabel) {
          pCLabel = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    cOrder++;
  }

  // draw pressed object now
  if (TouchS.ActObjInfo.Obj)
    DrawObject(TouchS.ActObjInfo.Obj, TouchS.ActObjInfo.Type);

  FT812_Screen_EndUpdate();
  FT812_Screen_Show();

  // process screen switching effects
  if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_FADE) {
    FT812_PWM_FadeIn(0, pwmDuty, 1, 3);
  }
  else if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_OFF) {
    FT812_PWM_Duty(pwmDuty);
  }

}

void DrawScreen(TScreen *aScreen) {
  if (aScreen != CurrentScreen)
    DrawScreenO(aScreen, VTFT_LOAD_RES_ALL | VTFT_DISPLAY_EFF_LIGHTS_FADE);
  else
    DrawScreenO(aScreen, VTFT_LOAD_RES_NONE);
}

static void InitObjects() {
  // Screen1: Init block start
  Screen1.Color             = 0x0000;
  Screen1.Width             = 800;
  Screen1.Height            = 480;
  Screen1.ObjectsCount      = 6;
  Screen1.LabelsCount       = 5;
  Screen1.Labels            = Screen1_Labels;
  Screen1.CLabelsCount      = 1;
  Screen1.CLabels           = Screen1_CLabels;
  Screen1.DynResStart       = 30104;
  Screen1.Active            = 1;
  Screen1.SniffObjectEvents = 0;
  Screen1.OnUp              = 0;
  Screen1.OnDown            = 0;
  Screen1.OnTagChange       = 0;
  Screen1.OnPress           = 0;

  Label1.OwnerScreen = &Screen1;
  Label1.Order       = 1;
  Label1.Visible     = 1;
  Label1.Opacity     = 255;
  Label1.Tag         = 255;
  Label1.Left        = 157;
  Label1.Top         = 181;
  Label1.Width       = 48;
  Label1.Height      = 113;
  Label1.Caption     = Label1_Caption;
  Label1.FontName    = Tahoma_85x103_Regular;
  Label1.Font_Color  = 0xFFFF00;
  Label1.FontHandle  = 2;
  Label1.Source      = -1UL;
  Label1.Active      = 1;
  Label1.OnUp        = 0;
  Label1.OnDown      = 0;
  Label1.OnClick     = 0;
  Label1.OnPress     = 0;

  Label2.OwnerScreen = &Screen1;
  Label2.Order       = 2;
  Label2.Visible     = 1;
  Label2.Opacity     = 255;
  Label2.Tag         = 255;
  Label2.Left        = 439;
  Label2.Top         = 182;
  Label2.Width       = 48;
  Label2.Height      = 113;
  Label2.Caption     = Label2_Caption;
  Label2.FontName    = Tahoma_85x103_Regular;
  Label2.Font_Color  = 0xFFFF00;
  Label2.FontHandle  = 2;
  Label2.Source      = -1UL;
  Label2.Active      = 1;
  Label2.OnUp        = 0;
  Label2.OnDown      = 0;
  Label2.OnClick     = 0;
  Label2.OnPress     = 0;

  Label3.OwnerScreen = &Screen1;
  Label3.Order       = 3;
  Label3.Visible     = 1;
  Label3.Opacity     = 255;
  Label3.Tag         = 255;
  Label3.Left        = 202;
  Label3.Top         = 126;
  Label3.Width       = 22;
  Label3.Height      = 15;
  Label3.Caption     = Label3_Caption;
  Label3.FontName    = 26;
  Label3.Font_Color  = 0x0000;
  Label3.FontHandle  = 26;
  Label3.Source      = -1UL;
  Label3.Active      = 1;
  Label3.OnUp        = 0;
  Label3.OnDown      = 0;
  Label3.OnClick     = 0;
  Label3.OnPress     = 0;

  Label4.OwnerScreen = &Screen1;
  Label4.Order       = 4;
  Label4.Visible     = 1;
  Label4.Opacity     = 255;
  Label4.Tag         = 255;
  Label4.Left        = 151;
  Label4.Top         = 136;
  Label4.Width       = 670;
  Label4.Height      = 39;
  Label4.Caption     = Label4_Caption;
  Label4.FontName    = Tahoma_29x35_Regular;
  Label4.Font_Color  = 0xFFFF00;
  Label4.FontHandle  = 3;
  Label4.Source      = -1UL;
  Label4.Active      = 1;
  Label4.OnUp        = 0;
  Label4.OnDown      = 0;
  Label4.OnClick     = 0;
  Label4.OnPress     = 0;

  Label5.OwnerScreen = &Screen1;
  Label5.Order       = 5;
  Label5.Visible     = 1;
  Label5.Opacity     = 255;
  Label5.Tag         = 255;
  Label5.Left        = 536;
  Label5.Top         = 418;
  Label5.Width       = 242;
  Label5.Height      = 39;
  Label5.Caption     = Label5_Caption;
  Label5.FontName    = Tahoma_29x35_Regular;
  Label5.Font_Color  = 0xC0C0C0;
  Label5.FontHandle  = 3;
  Label5.Source      = -1UL;
  Label5.Active      = 1;
  Label5.OnUp        = 0;
  Label5.OnDown      = 0;
  Label5.OnClick     = 0;
  Label5.OnPress     = 0;

}

void Init_MCU() {
SPI2_Init_Advanced(_SPI_FPCLK_DIV4, _SPI_MASTER | _SPI_8_BIT | _SPI_CLK_IDLE_LOW 
                   | _SPI_FIRST_CLK_EDGE_TRANSITION | _SPI_MSB_FIRST | _SPI_SS_DISABLE 
                   | _SPI_SSM_ENABLE | _SPI_SSI_1, &_GPIO_MODULE_SPI2_PB13_14_15);
}

void InitVTFTStack() {
  Init_MCU();

  SPI_Set_Active(SPI2_Read, SPI2_Write);

  // Init all dynamic objects
  InitObjects();

  // Init FT812 controller core and library stack
  FT812_Init();

  FT812_Core_ClockSource(_FT812_CLK_SOURCE_INTERNAL);
  FT812_Core_SetFrequency(VTFT_FT812_CONFIG_DISPLAY.Frequency);

  // Internal modules setup
  FT812_Display_SetConfig(&VTFT_FT812_CONFIG_DISPLAY);

  FT812_Audio_SetConfig(&VTFT_FT812_CONFIG_AUDIO);

  FT812_Sound_SetConfig(&VTFT_FT812_CONFIG_SOUND);

  FT812_Interrupt_SetConfig(&VTFT_FT812_CONFIG_INTERRUPT);

  FT812_PWM_SetConfig(&VTFT_FT812_CONFIG_PWM);

  FT812_GPIO_SetConfig(&VTFT_FT812_CONFIG_GPIO);

  // Draw start screen
  DrawScreen(&Screen1);
}
