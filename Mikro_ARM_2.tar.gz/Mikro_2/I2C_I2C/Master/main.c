/*****************************************************************************
*  Descripci�n  : Medici�n de luz visible con sensor OPT3001
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/

    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

 void Enviar_Dato();
#define SLAVE_ADDRESS 0x49
unsigned char tmp_data[12];
char floatStr[10];
char txt_viejo[10];
unsigned char temp;
float luz_ambiente = 0;

/*****************************************************
*        Esta funci�n lee la cantidad de luz ambiente
******************************************************/
void Enviar_Dato() {
  unsigned int DataSum;
  float Ambient_Data;
  tmp_data[0] = 0x04;
  I2C1_Start();
  I2C1_Write(SLAVE_ADDRESS,tmp_data,1,END_MODE_STOP);

}

void main(){
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  Delay_ms(200);
  //Config_Sensor();
  Lcd_Out(1,4,"Prueba I2C");      // Carteles iniciales
  //Lcd_Out(2,1,"Luz Visible:");
  Lcd_Out(4,2,"www.firtec.com.ar");

  while(1) {                         // Bucle infinito

    /*sprintf(floatStr, "%2.1f%% ", luz_ambiente);
    temp = strcmp(floatStr,txt_viejo);  // Compara las cadenas
         if(temp != 0){
                  //Lcd_Out(2,13,floatStr);
                  strcpy(txt_viejo,floatStr);  // Actualiza nuevo valor
         }*/
   Enviar_Dato();
   Delay_ms(1000);
   }
  }
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************