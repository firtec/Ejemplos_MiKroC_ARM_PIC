/*****************************************************************************
*  Descripci�n  : Ejemplo de uso para el puerto UART.
*                 Este ejemplo utiliza UART2 -> Delay_us [PA2 TX|PA3 RX] .
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
#define led   GPIOD_ODR.B15
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

char caracter;   // Contenedor para el dato recibido
volatile unsigned char datoRX;
volatile unsigned char kbhit = 0;
volatile unsigned char array[16];
volatile unsigned char i = 0;
unsigned char bandera = 0;
unsigned char error, pagina, componente, eventopres, dato1, dato2, dato3;

void usart_RX() iv IVT_INT_USART2 ics ICS_AUTO
{
   led = ~ led;
  if(UART2_Data_Ready()){
      
      array[i] =  UART2_Read();
      i++;
      if(i == 15)
         kbhit =1;
    }

  }


void main(){
GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);
led = 0;
  /*Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off*/
UART2_Init_Advanced(9600, _UART_8_BIT_DATA, _UART_NOPARITY,
                            _UART_ONE_STOPBIT, &_GPIO_MODULE_USART2_PA23);

  EnableInterrupts();
  UE_USART2_CR1_bit = 1;
  RE_USART2_CR1_bit = 1;
  RXNEIE_USART2_CR1_bit = 1;
  TXEIE_USART2_CR1_bit = 0;
  NVIC_IntEnable(IVT_INT_USART2);

  /*Delay_ms(100);
  Lcd_Out(1,5,"Ejemplo UART");      // Carteles iniciales
  Lcd_Out(2,1,"Dato Recibido:  ");
  Lcd_Out(4,2,"www.firtec.com.ar");
  UART2_Write(13);
  UART2_Write(10);*/

  while(1) { 
  if(kbhit ==1){
          /*unsigned char a;
           for (a=0; a<10; a++){
               UART2_Write(array[a]);
           }*/
    array[16] = '\0';         // imprimira arreglo despues de un enter
    error = array[1];     // nombre del primer nibble del arreglo
    pagina = array[2];    //nombre de segundo nibble del arreglo
    componente = array[3];//nombre de tercer nibble del arreglo
    eventopres = array[4];//nombre de cuarto nibble del arreglo
    dato1 = array[5];     //nombre de primer quinto nibble del arreglo
    dato2 = array[6];     //nombre de primer sexto nibble del arreglo
    dato3 = array[7];     //nombre de primer septimo nibble del  arreglo
    kbhit =0;
    i = 0;

    if (pagina == 0 && componente == 1 && bandera == 0) {   // si tenemos un evento de la pagina 0 y el componente 1(el unico boton de esa pagina) y no ah sido activada la bandera
      led = 1;                    // enciende el led
      bandera = 1;                 // suma 1  a la bandera
      componente = 0;              // has 0 la variable componente
    }
   if (pagina == 0 && componente == 1 && bandera == 1) {   // si vuelves apresionar el boton en nextion y la bandera tiene un 1
      led = 0;                   // apaga el led
      bandera = 0;                           // has 0 la bandera
      }
     }
    }
  }

