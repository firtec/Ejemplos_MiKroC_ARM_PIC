/*****************************************************************************
*  Descripci�n  : Programa ejemplo para el reloj calendario DS3231
*                 Este ejemplo utiliza I2C1 en pines PB8(SCL) y PB7(SDA).
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

/* Register Definitions
 *  --- Reg  -- Value
 *  --- 0x00 -- Seconds
 *  --- 0x01 -- Minutes
 *  --- 0x02 -- Hours
 *  --- 0x03 -- Day of Week ( 1 - 7, 1 = Sunday, 7 = Saturday )
 *  --- 0x04 -- Day of Month
 *  --- 0x05 -- Month ( 1 - 12 )
 *  --- 0x05 -- Year ( 00 - 99 )
 */
#define I2C_ADR 0x68
unsigned char temporal_datos[12];
unsigned char segundos, minutos, hora, dia_mes, dia_semana, mes, year;
char floatStr[12];
void Ajustar_BCD(void);
void Ajustar_para_DS3231(void);
void Leer_ds3231(void);
void Escribir_DS3231(void);
unsigned char I2C_LeerRegistro(char);
char TxtStr[12];

struct DS3231 {
    unsigned char dia_semana;
    unsigned char dia_mes;
    unsigned char mes;
    unsigned char hora;           // Stored in 24hr format.
    unsigned char minuto;
    unsigned char segundos;
    unsigned char year;
} Dato;

// Converts data from raw device output to psuedo-human-readable
// See https://datasheets.maximintegrated.com/en/ds/DS3231.pdf
void Ajustar_BCD(){
    segundos = ((segundos & 0x0f) + ((segundos >> 4)*10));
    minutos = ((minutos & 0x0f) + ((minutos >> 4)*10));
    hora = ((hora & 0x0f) + ((hora >> 4)*10));
    dia_mes = ((dia_mes & 0x0f) + ((dia_mes >> 4)*10));
    mes = ((mes & 0x0f) + ((mes >> 4)*10));
    year = ((year & 0x0f) + ((year >> 4)*10));
}

void Ajustar_para_DS3231(){
    segundos = ((segundos/10) << 4) + (segundos % 10);
    minutos = ((minutos/10) << 4) + (minutos % 10);
    hora = ((hora/10) << 4) + (hora % 10);
    dia_mes = ((dia_mes/10) << 4) + (dia_mes % 10);
    mes = ((mes/10) << 4) + (mes % 10);
    year = ((year/10) << 4) + (year % 10);
}

unsigned char I2C_LeerRegistro(char rDir) {
  temporal_datos[0] = rDir;
  I2C1_Start();
  I2C1_Write(I2C_ADR,temporal_datos,1,END_MODE_RESTART);
  I2C1_Read(I2C_ADR,temporal_datos,1,END_MODE_STOP);

  return temporal_datos[0];
}
void Leer_ds3231(){
   segundos = I2C_LeerRegistro(0x00);
   minutos = I2C_LeerRegistro(0x01);
   hora = I2C_LeerRegistro(0x02);
   dia_semana = I2C_LeerRegistro(0x03);
   dia_mes = I2C_LeerRegistro(0x04);
   mes = I2C_LeerRegistro(0x05);
   year = I2C_LeerRegistro(0x06);
   Ajustar_BCD();
}

void Escribir_DS3231(){
       segundos = 0;
       minutos = 59;
       hora = 18;
       dia_mes = 28;
       mes = 8;
       year = 20;
      // temporal_datos[0] = 0x0E;
       //temporal_datos[1] = 0xFB;
       //I2C1_Write(I2C_ADR,temporal_datos,2,END_MODE_STOP);
       
        Ajustar_para_DS3231();
        temporal_datos[0] = 0;
        temporal_datos[1] = segundos;
        temporal_datos[2] = minutos;
        temporal_datos[3] = hora;
        temporal_datos[4] = 0;
        temporal_datos[5] = dia_mes;
        temporal_datos[6] = mes;
        temporal_datos[7] = year;
        I2C1_Start();
        I2C1_Write(I2C_ADR,temporal_datos,8,END_MODE_STOP);
}

// =========================== PROGRAMA PRINCIPAL ==============================
void main(){
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  Delay_ms(500);
  Escribir_DS3231(); //---------------------------
  Lcd_Out(1,5,"Reloj DS3231");      // Carteles iniciales
  Lcd_Out(2,1,"Reloj:  ");
  Lcd_Out(3,1,"Fecha:");
  Lcd_Out(4,2,"www.firtec.com.ar");
  
  while(1) {
  Leer_ds3231();
  sprintf(TxtStr,"%02u:%02u:%02u",hora,minutos,segundos);
  Lcd_Out(2,7,TxtStr);
  sprintf(TxtStr,"%02u/%02u/20%02u",dia_mes,mes,year);
  Lcd_Out(3,7,TxtStr);
  Delay_ms(800);

  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************