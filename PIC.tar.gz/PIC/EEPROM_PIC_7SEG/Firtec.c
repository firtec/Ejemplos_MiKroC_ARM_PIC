

const unsigned char Display[16] =
{0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67,0x77,0x7C,0x39,0x5E,0x79,0x71};
unsigned short direccion =0; // 1024 Vectores disponibles
unsigned char dato =0;

void main() {

    TRISB=0X00;
    direccion = 1;    // Direcci�n de memoria
    dato = 4;         // El dato a guardar
    EEPROM_Write(direccion, dato);  // Escribe la memoria
    delay_ms(20);            // Espera a que termine
    dato = 0;                // Limpia vector dato
    dato = EEPROM_Read(direccion);  // Lee la memoria
    PORTB=Display[dato];       // Muestra el dato

  while(1);

}