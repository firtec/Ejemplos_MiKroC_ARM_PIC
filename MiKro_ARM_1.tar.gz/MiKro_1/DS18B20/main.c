/*****************************************************************************
*  Descripci�n  : Ejemplo de uso para el protocolo 1-Wire utilizando
*                 sensores como el DS18x20 y una pantalla 20x4.
*                 En este ejemplo el Sensor se conecta en PC0.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
 
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

 char texto[20] = "";
 char a[2];
 const unsigned char TEMP_RES_B = 12;
 const unsigned char TEMP_RES_S = 9;
 unsigned char TEMP_RESOLUTION;
 unsigned char Sensor;
 unsigned temp;
 float temperatura;
 
 void Display_SerialNumber(void);
 void Sensor_Tipo(void);
 void Leer_Temperatura(void);
 void Mostrar_ROM_Code(void);
 float  Leer_DS18B20(void);
 float Leer_DS18S20(void);
 
 unsigned char ROM_DATA [8]; // Array donde se guardar� el codigo ROM
 unsigned char puntero_array = 0;
 char family_code;
 unsigned char i;

/***************************  SENSOR_TIPO *****************************/
/* Esta funci�n identifica y lee todos los datos del Sensor 1-Wire */
/* Argumentos: Ninguno */
/* Retorna: Nada */
/***********************************************************************/
void Sensor_Tipo(){
      Ow_Reset(&GPIOC_BASE, 0);
      Ow_Write(&GPIOC_ODR, 0, 0x33);
      Delay_us(120);
      family_code = Ow_Read(&GPIOC_ODR, 0);

      switch( family_code ){
       case 0x28:
       Lcd_Out(2, 6, "DS18B20" );
       Sensor = TEMP_RES_B;
       break;

       case 0x10:
       Lcd_Out(2, 6, "DS18S20" );
       Sensor = TEMP_RES_S;
       break;

       case 0x01:
       Sensor = 0;
       break;

       case 0xFF:
       Sensor = 0;
       break;

       default:
       Sensor = 0;
       break;
      }

     Ow_Reset(&GPIOC_BASE, 0);   // Env�a Reset
     Ow_Write(&GPIOC_ODR, 0, 0x33); // Env�a comando para leer ID
     Delay_us(120);

  for(i = 0; i <= 7; i++){    // Lee y almacena en ROM_DATA
   ROM_DATA[i] = Ow_Read(&GPIOC_ODR, 0);
  }
}
/*************************  LEER_TEMPERATURA ***************************/
/* Esta funci�n lee la temperatura del Sensor 1-Wire */
/* Argumentos: Ninguno */
/* Retorna: Nada */
/***********************************************************************/
void Leer_Temperatura()
{
 // Perform temperature reading
    Ow_Reset(&GPIOC_BASE, 0);
    Ow_Write(&GPIOC_ODR, 0, 0xCC);
    Ow_Write(&GPIOC_ODR, 0, 0x44);
    Delay_us(120);
    Ow_Reset(&GPIOC_BASE, 0);
    Ow_Write(&GPIOC_ODR, 0, 0xCC);            // Issue command SKIP_ROM
    Ow_Write(&GPIOC_ODR, 0, 0xBE);           // Issue command READ_SCRATCHPAD

    temp =  Ow_Read(&GPIOC_ODR, 0); // Lee 16 bits y concatena los Byte's
    temp = (Ow_Read(&GPIOC_ODR, 0) << 8) + temp;
    if (((temp >> 15)) == 1) {
      // Complemento a dos si la temperatura es negativa
      temp = ~temp + 1;
   }
}
/***************************  LEER_DS18B20 *****************************/
/* Esta funci�n procesa la temperatura de un Sensor DS18B20 */
/* Argumentos: Ninguno */
/* Retorna: temperatura */
/***********************************************************************/

float Leer_DS18B20(){
    temperatura = 6*temp + temp/4; // multiply by (100 * 0.0625) or 6.25
    temperatura = temperatura/100;
    return temperatura;
}
/***************************  LEER_DS18S20 *****************************/
/* Esta funci�n procesa la temperatura de un Sensor DS18S20 */
/* Argumentos: Ninguno */
/* Retorna: temperatura */
/***********************************************************************/
float Leer_DS18S20(){
    temperatura = (temp & 0x00FF)*0.5f;
    return temperatura;
}
/************************* MOSTRAR_ROM_CODE *****************************/
/* Esta funci�n muestra los 64 bit's del ROM CODE */
/* Argumentos: Ninguno */
/* Retorna: Nada */
/***********************************************************************/
void Mostrar_ROM_Code(){
unsigned char y = 4;
 for(puntero_array=0;puntero_array<=7;puntero_array++){
    sprintf(a,"%02X",ROM_DATA[puntero_array]);
    Lcd_Out(3, y, a);
    y= y+2;
}
}
//************** FUNCI�N PRINCIPAL DEL PROGRAMA ************************
void main() {
    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    Lcd_Out(1, 3, "Protocolo 1-Wire" );
    Lcd_Out(2, 1, "Tipo: " );
    Lcd_Out(3, 1, "ID: " );
    Lcd_Out(4, 1, "Temp: " );
    Sensor_Tipo();
    Mostrar_ROM_Code();
    if(Sensor == 0){
    Lcd_Out(2, 6, "Desconocido!!" );
    while(1);
    }
  while(1) {
  Leer_Temperatura();
  if(Sensor == TEMP_RES_B){
  sprintf(texto,"%2.1f",Leer_DS18B20());
  }
  if(Sensor == TEMP_RES_S){
  sprintf(texto,"%2.1f ",Leer_DS18S20());
  }
    Lcd_Out(4, 6, texto );
    Delay_ms(100);
  }
}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************