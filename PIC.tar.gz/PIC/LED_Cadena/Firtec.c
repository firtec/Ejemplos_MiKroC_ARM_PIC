

#define limite 16
#define retardo 80
const unsigned char tabla[] = // Cadena en Flash
{0,1,3,7,15,31,63,127,255,254,252,248,240,224,192,128,0};

void main() {
  unsigned char indice;
   PORTB = 0;	// Se limpia el puerto B
   TRISB = 0;   // Todo el puerto es salida para alimentar los led's
  while(1){
     for (indice = 0;indice < limite;indice++){// Secuencia para encender los led
      PORTB = tabla[indice];// Coloca en el puerto la secuencia de n�meros FLASH
      delay_ms(retardo);    // Tiempo de espera entre n�mero y n�mero
     }
    for (;indice >0;indice--){	// Secuencia para apagar los led
      PORTB = tabla[indice];
      delay_ms(retardo);
    }
  }
 }