/*****************************************************************************
*  Descripci�n  : Registrador de temperatura y humedad. Cada 15 minutos
*                 escribe en una memoria SD datos de un sensor HTU21D.
*                 Puerto SDIO (La memoria debe estar formateada en FAT32).
*                 El sensor es I2C y se conecta en I2C1 pines PB8(SCL) y
*                 PB7(SDA). El reloj DS3231 se encuentra en los mismos pines.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*  Perifericos  : RTC DS3231 + HTU21D + Shield + Pantalla LCD 20x4
*         www.firtec.com.ar
*****************************************************************************
* IMPORTANTE:
*   NO RETIRAR LA MEMORIA CUANDO EL LED VERDE EST� ENCENDIDO!!!!
*   Remover la memoria durante el ciclo de escritura da�ar� el archivo.
*
* FUNCIONAMIENTO:
*   Cada un segundo se toman datos del sensor y cada quince minutos se
*   escriben datos en la memoria SD (Hora,  Minutos, temperatura y humedad).
*   Al inicio de cada nuevo d�a (Hora cero) se crea un nuevo archivo usando
*   como nombre de archivo la fecha del d�a, el archivo creado es del tipo
*   csv para poder leerlo con cualquier hoja de c�lculo.
*   Para asegurar el funcionamiento del sistema se ha configurado el IWD con
*   un tiempo de alrededor de dos segundos para reiniciar.
*   LED Verde indica aceso a la memoria, LED Rojo avisa que la memoria ha sido
*   retirada.
*****************************************************************************/

#include "__Lib_FAT32.h"
void Init_SDIO(void);
char Init_FAT(void);

// Necesarios para el driver. (Sin uso en el programa)
sbit Mmc_Chip_Select   at GPIOD_ODR.B12;
sbit MMC_Card_Detect   at GPIOB_IDR.B15;
/************ Pines de la memoria ****************
NCD         PB15
DATO 0      PC8
DATO 1      PC9
DATO2       PC10
DATO3       PC11
CLK         PC12
CMD         PD2
*******  Pines usados en la pantalla LCD ***********/
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B6;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

#define DS3231_ADDR                 (0x68)
#define HTU21D_ADDR                 (0x40)
#define dato_temp                   (0x01)
#define dato_hum                    (0x02)
#define CD  GPIOA_IDR.B9  // Pin para detectar la memoria SD

void Ajustar_BCD(void);
void Ajustar_para_DS3231(void);
void Leer_ds3231(void);
void Escribir_DS3231(void);
unsigned char I2C_LeerRegistro(char);
float Leer_sensor(unsigned char);
void Actualizar_Archivo(void);
void Sensor_Reset();
void Iniciar_SDIO_Fat(void);
char Init_FAT();
void Init_SDIO();
void setup_IWDG();
void CustomChar(char, char);

unsigned char temporal_datos[12];
unsigned char segundos, minutos, hora, dia_mes, dia_semana, mes, year;
unsigned char  Fat_Initialized_Flag;
signed long Ext_fhandle;
char Ext_res_initialized;
char ext[5]= ".csv";
static char ArchNombre[13];
char TxtStr[12];
unsigned char flag_NuevoArhivo = 0;
unsigned char minutos_viejos;
unsigned long fat32_file;

const char character[] = {0,0,31,31,31,31,0,0};
unsigned char bandera_CD =0;

/******************************************************************************
*  Funci�n para condigurar el Watch-Dog (2 Seg aprox.)
******************************************************************************/
void setup_IWDG()
{
     IWDG_KR = 0x5555;    //Disable write protection of IWDG registers
     IWDG_PR = 0x06;      //Set PR value
     IWDG_RLR = 0xFE;     //Set RLR value (254) o (0xBBA 302)
     IWDG_KR = 0xAAAA;    //Reload IWDG
     IWDG_KR = 0xCCCC;    //Start IWDG
}

/******************************************************************************
*  Funci�n para crear caracteres especiales en el LCD
******************************************************************************/
void CustomChar(char pos_row, char pos_char) {
  char i;
    Lcd_Cmd(64);
    for (i = 0; i<=7; i++) Lcd_Chr_CP(character[i]);
    Lcd_Cmd(_LCD_RETURN_HOME);
    Lcd_Chr(pos_row, pos_char, 0);
}
/******************************************************************************
*  Funci�n para ajustar los datos que vienen del reloj calendario
******************************************************************************/
void Ajustar_BCD(){
    segundos = ((segundos & 0x0f) + ((segundos >> 4)*10));
    minutos = ((minutos & 0x0f) + ((minutos >> 4)*10));
    hora = ((hora & 0x0f) + ((hora >> 4)*10));
    dia_mes = ((dia_mes & 0x0f) + ((dia_mes >> 4)*10));
    mes = ((mes & 0x0f) + ((mes >> 4)*10));
    year = ((year & 0x0f) + ((year >> 4)*10));
}
/******************************************************************************
*  Funci�n para ajustar los datos que se env�an al reloj calendario
******************************************************************************/
void Ajustar_para_DS3231(){
    segundos = ((segundos/10) << 4) + (segundos % 10);
    minutos = ((minutos/10) << 4) + (minutos % 10);
    hora = ((hora/10) << 4) + (hora % 10);
    dia_mes = ((dia_mes/10) << 4) + (dia_mes % 10);
    mes = ((mes/10) << 4) + (mes % 10);
    year = ((year/10) << 4) + (year % 10);
}
/******************************************************************************
*  Funci�n para leer registros internos del calendario
******************************************************************************/
unsigned char I2C_LeerRegistro(char rDir) {
  temporal_datos[0] = rDir;
  I2C1_Start();
  I2C1_Write(DS3231_ADDR,temporal_datos,1,END_MODE_RESTART);
  I2C1_Read(DS3231_ADDR,temporal_datos,1,END_MODE_STOP);

  return temporal_datos[0];
}
/******************************************************************************
*  Funci�n para leer y guardar los datos del calendario
******************************************************************************/
void Leer_ds3231(){
   segundos = I2C_LeerRegistro(0x00);
   minutos = I2C_LeerRegistro(0x01);
   hora = I2C_LeerRegistro(0x02);
   dia_semana = I2C_LeerRegistro(0x03);
   dia_mes = I2C_LeerRegistro(0x04);
   mes = I2C_LeerRegistro(0x05);
   year = I2C_LeerRegistro(0x06);
   Ajustar_BCD();
}
/******************************************************************************
*  Funci�n para actualizar los datos del calendario.
******************************************************************************/
void Escribir_DS3231(){
/*Ajustar_para_DS3231();

        I2C_start(I2C1, SLAVE_ADDRESS, I2C_Direction_Transmitter);
        I2C_write(I2C1, DS3231_SECONDS_REGISTER);
        I2C_write(I2C1,segundos);
        I2C_write(I2C1, minutos);
        I2C_write(I2C1, hora);
        I2C_write(I2C1, dia_semana);
        I2C_write(I2C1, dia_mes);
        I2C_write(I2C1, mes);
        I2C_write(I2C1, year);
        I2C_stop(I2C1); // stop*/
}
/******************************************************************************
*  Funci�n para iniciar el sensor HTU21D
******************************************************************************/
void Sensor_Reset(){
char reg_command[1];
  reg_command[0] = 0xFE;
  I2C1_Start();
  I2C1_Write(HTU21D_ADDR,reg_command, 1, END_MODE_STOP);
  Delay_ms(15);
}
/******************************************************************************
*  Funci�n leer el sensor HTU21D.
*  Retorna el valor de la temperatura o la humedad.
******************************************************************************/
float Leer_sensor(unsigned char ajuste){
unsigned dato = 0;
char reg_dato[3];
float resultado;
  if(ajuste == dato_temp)
            reg_dato[0] = 0xE3;           // Lee valor de temperatura
  if(ajuste == dato_hum)
            reg_dato[0] = 0xE5;           // Lee valor de humedad
  I2C1_Start();
  I2C1_Write(HTU21D_ADDR, reg_dato, 1, END_MODE_RESTART);
  I2C1_Read (HTU21D_ADDR, reg_dato, 3, END_MODE_STOP);
  dato = ((unsigned short)reg_dato[0] << 8) | reg_dato[1] ;
  dato = dato & 0xFFFC;               // Limpia bit de status
  if(ajuste == dato_temp){            // Ajusta lectura de temperatura
  resultado = -46.85 + 175.72 * dato / 65536.0;
  return resultado;
  }
  if(ajuste == dato_hum){            // Ajusta lectura de humedad
  resultado = -6.0 + 125.0 * dato / 65536.0;
  return resultado;
  }
}
/**************** Funci�n Principal del Programa *****************************/
void main()
{
    unsigned char a;
    
    GPIO_Config(&GPIOD_BASE,
            _GPIO_PINMASK_12 | _GPIO_PINMASK_13 | _GPIO_PINMASK_15,
            _GPIO_CFG_MODE_OUTPUT | _GPIO_CFG_SPEED_MAX | 
            _GPIO_CFG_OTYPE_PP);
    GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9);

  Iniciar_SDIO_Fat();
    
  Lcd_Init();
  Delay_ms(500);
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);

  Delay_ms(250);
  Sensor_Reset();
  Delay_ms(250);

  Lcd_Out(3,1,"Temp:");
  Lcd_Out(3,11,"Hum:");

  for(a=1; a <= 20; a++){
   CustomChar(1,a);
  }

  for(a=1; a <= 20; a++){
   CustomChar(4,a);
  }
  Lcd_Out(1,6," Ambiente ");
  Lcd_Out(2,1,"Info:");
  Leer_ds3231();
  sprintf(ArchNombre,"%02d_%02d_%02d", dia_mes,mes,year);
  strcat(ArchNombre,ext);
  fat32_file = FAT32_Open(ArchNombre, FILE_APPEND); //FILE_WRITE
  setup_IWDG();   // Inicia el watchdog
  while(1)
  {
  IWDG_KR = 0xAAAA;  // Recarga del WatchDog
  Leer_ds3231(); // Lee el estado del calendario
  
  if(CD == 0)   // Hay memoria conectada??
   {
     if(bandera_CD == 1){   // La memoria fu� retirada antes?
      Iniciar_SDIO_Fat();   // Re-Iniciar la Fat
      bandera_CD = 0;       // Borrar la bandera
      GPIOD_ODR.B13 = 0;
      delay_ms(100);
     }
        Actualizar_Archivo(); // Actualizar valores en el archivo
   }
   else
   {
     bandera_CD =1; // Aviso que la memoria se retir�
     GPIOD_ODR.B13 = 1;
   }

  sprintf(TxtStr,"%02u:%02u",hora,minutos);
  Lcd_Out(2,15,TxtStr);
  sprintf(TxtStr,"%02u/%02u/%02u",dia_mes,mes,year);
  Lcd_Out(2,6,TxtStr);
  sprintf(TxtStr,"%2.1f ",Leer_Sensor(dato_temp));
  Lcd_Out(3,6,TxtStr);
  sprintf(TxtStr,"%2.1f%% ",Leer_Sensor(dato_hum));
  Lcd_Out(3,15,TxtStr);
  Delay_ms(1000);
  }
}
/******************************************************************************
*  Esta funci�n gestiona el manejo del archivo en la memoria SD.
*  Crea un nuevo archivo a la hora cero de cada nuevo d�a y actualiza los
*  datos hora, minuto, temperatura y humedad cada 15 minutos.
******************************************************************************/
void Actualizar_Archivo(void){
 char temp_dato[6];
 char datos_sensor[12];
 char dato_texto[30];

 // Crea nuevo archivo en el inicio de cada d�a
 if(hora == 0 && flag_NuevoArhivo ==0){
    sprintf(ArchNombre,"%02d_%02d_%02d", dia_mes,mes,year);
    strcat(ArchNombre,ext);
    fat32_file = FAT32_Open(ArchNombre, FILE_APPEND);
    flag_NuevoArhivo =1;
 }
 
 if (1 == hora)
    flag_NuevoArhivo = 0;  // Borrar bandera de nuevo archivo
    
  // Actualiza el contenido del archivo cada 15 minutos.
 if((minutos == 0) || (minutos == 15) || (minutos == 30) || (minutos == 45)){
   IWDG_KR = 0xAAAA;  // Recarga del WatchDog
   if(minutos_viejos != minutos){
       minutos_viejos = minutos;
       sprintf(datos_sensor,"%2.1f,%2.1f%%\n",
       Leer_Sensor(dato_temp),Leer_Sensor(dato_hum));
       sprintf(dato_texto,"%02u:%02u,",hora,minutos);
       strcat(dato_texto,datos_sensor);
       fat32_file = FAT32_Open(ArchNombre, FILE_APPEND);
       FAT32_Write(fat32_file, dato_texto, strlen(dato_texto));
       FAT32_Close(fat32_file);
       GPIOD_ODR.B12 = 1;
   }
   else
   GPIOD_ODR.B12 = 0;
  }
}
/******************************************************************************
*  Esta funci�n configura el puerto SDIO y el sistema de archivos FAT.
*  Esta funci�n es invocada cuando el sistema inicia o cada vez que la
*  memoria es retirada de la ranura porta memoria.
******************************************************************************/
void Iniciar_SDIO_Fat(void){  
  char FAT_cnt = 0;
  SDIO_Reset();
  IWDG_KR = 0xAAAA;   // Recarga del WatchDog
  SDIO_Init(_SDIO_CFG_POWER_SAVE_DISABLE | _SDIO_CFG_1_WIDE_BUS_MODE |
              _SDIO_CFG_CLOCK_BYPASS_DISABLE | _SDIO_CFG_CLOCK_RISING_EDGE |
              _SDIO_CFG_HW_FLOW_DISABLE, 125, &_GPIO_MODULE_SDIO_D0_D3);

// Set pull-ups en los pines SDIO
    GPIOD_PUPDRbits.PUPDR2 = 1;
    GPIOC_PUPDRbits.PUPDR8 = 1;
    GPIOC_PUPDRbits.PUPDR9 = 1;
    GPIOC_PUPDRbits.PUPDR10 = 1;
    GPIOC_PUPDRbits.PUPDR11 = 1;
    GPIOB_PUPDRbits.PUPDR15 = 1;
    Mmc_Set_Interface(_MMC_INTERFACE_SDIO);

        while ((FAT32_Init() != 0) && (FAT_cnt < 5))
            FAT_cnt ++;
        if (FAT_cnt < 5)
        {
        SDIO_Init(_SDIO_CFG_POWER_SAVE_DISABLE | _SDIO_CFG_1_WIDE_BUS_MODE |
        _SDIO_CFG_CLOCK_BYPASS_DISABLE | _SDIO_CFG_CLOCK_RISING_EDGE |
        _SDIO_CFG_HW_FLOW_DISABLE, 1, &_GPIO_MODULE_SDIO_D0_D3);

        }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************