const code char Tahoma10x11_Regular[];
