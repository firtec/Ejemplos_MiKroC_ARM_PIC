/*****************************************************************************
*  Descripci�n  : Lectura de la temperatura interna de CPU medianto ADC1.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

 void Leer_Conversor(void);
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
  unsigned int M0;
  float conversion =0;
  unsigned char muestras = 0;
  char texto[20] = "";

void main() {

    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    ADC1_Init();
    ADC_CCRbits.TSVREFE=1;
    delay_ms(10);

    Lcd_Out(1, 1, "Temp_CPU:" );

  while(1) {
   Leer_Conversor();
   conversion = ((conversion *3.3)/4095);
   conversion = ((conversion - 0.76)/.025)+25;
   sprintf(texto,"%2.1f", conversion);
   Lcd_Out(1,10, texto );
   delay_ms(1000);
  }
}
/******************************************************************************
*  Funci�n para la lectura del canal anal�gico.
*  Se toman 16 lecturas en cada pin y se promedian para obtener una medici�n
*  estable dispersando el error en la cantidad de muestras.
******************************************************************************/
 void Leer_Conversor(){
    do{
    M0 += ADC1_Get_Sample(16); // Sensor interno en el canal 16
    muestras++;
    }while(muestras <= 15);
        conversion = M0/16;
        M0 = 0;
        muestras =0;
 }

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************