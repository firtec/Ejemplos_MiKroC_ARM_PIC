/****************************************************************************
**  Descripci�n  : Lectura de calidad de aire con un sensor MQ135.
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 40MHZ - (XTAL 10Mhz con PLLx4)
**  NOTA         : El pin analogico del sensor se conecta al pin 2 (AN0)
**
*****************************************************************************/
// LCD module connections
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// End LCD module connections

const double Rl      = 1000.0;
//const double Rl      = 5000.0;        // Rl (Ohm) - Resistencia de carga
const double Vadc_5  = 0.0048828125;    // ADC 5V/1024 4,88mV (10bit ADC)
const double Vadc_33 = 0.0032226562;    // ADC 3,3V/1024 3,22mV (10bit ADC)
double Vrl;                             // Output voltage
double Rs;                              // Rs (Ohm) - Resistencia del sensor
double ppm;                             // ppm
double ratio;                           // Rs/Rl ratio

unsigned int adc_rd;
char txt[16];


//Calculation of PPM
void calcular_PPM() {
  double lgPPM;
  Vrl = (double)adc_rd * Vadc_33;  // Para 5V Vadc_5, para 3V Vadc_33 !!!!
  //Vrl = (double)adc_rd * Vadc_5;
  Rs = Rl * (5 - Vrl)/Vrl;         // Calculo para la resistencia del sensor

  ratio = Rs/Rl;
  lgPPM = (log10(ratio) * -0.8)+ 0.9;   // Calcula partes por millon
  ppm = pow(10,lgPPM);
}

void leer_Sensor() {
  adc_rd = ADC_Read(0);                      // Read RA2
  delay_ms(10);                              // Pause 10ms
}

void main() {

  LCD_Init();                                // Initialize Lcd
  Lcd_Cmd(_LCD_CLEAR);                       // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);                  // Cursor off
  Lcd_Out(1,1,"Calidad del Aire");           // Write text in first row
  
  /*ADCON0 = 0;    // RA0
  ADCON1 = 0b00001110;
  ADCON2 = 0b10010100;*/
  TRISA = 0x01; // RA0 is input

  LATA   = 0;                                // Set PORTA as 0
  ADC_Init();                                // Initialize ADC
  delay_ms(100);                             // Pause of 100ms for ADC module stabilization

  //Initial read ADC and display PPM value on LCD
  leer_Sensor();                              // Read sensor
  calcular_PPM();                            // Calculating PPM value

  while(1) {

    delay_ms(500);                           // Pause 500ms
    leer_Sensor();                            // Read sensor
    calcular_PPM();                          // Calculating PPM value
    sprintf(txt, "PPM:%2.2f ", ppm);
    //FloatToStr(ppm,&txt);                    // Conversion float ppm to string txt
    //LCD_Out(2,1,"             ");
    LCD_Out(2,1,txt);                        // Print txt value on LCD

  }
}