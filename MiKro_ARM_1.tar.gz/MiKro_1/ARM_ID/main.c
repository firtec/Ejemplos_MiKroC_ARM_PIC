/*****************************************************************************
*  Descripci�n  : Lee los tres registros donde se guardan los n�meros ID que
*                 que identifican cada procesador STM.
*
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
* NOTA: El ID tiene 12 Bytes (96 bits). Est� escrito en tres registros cada
*       uno de 32 bits (cuatro bytes por registro).
*       El primer registro est� en la direcci�n 0x1FFF7A10 saltando cuatro
*       Bytes el segundo registro 0x1FFF7A14 y el tercer registro 0x1FFF7A18
*****************************************************************************/

    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
 const unsigned long ID[3]={0x1FFF7A10,0x1FFF7A14,0x1FFF7A18};
 unsigned long *_ps;     // Puntero para acceder a los registros
 char txt[12];

void main(){
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1,2,"ID del Procesador");
  Lcd_Out(2,1,"REG_1:");
  Lcd_Out(3,1,"REG_2:");
  Lcd_Out(4,1,"REG_3:");

                          _ps = ID[0];  // Conecta puntero con registro
                          longtostr(*_ps,txt);
                          Lcd_Out(2,7,Ltrim(txt));

                          _ps = ID[1]; // Conecta puntero con registro
                          longtostr(*_ps,txt);
                          Lcd_Out(3,7,Ltrim(txt));

                          _ps = ID[2]; // Conecta puntero con registro
                          longtostr(*_ps,txt);
                          Lcd_Out(4,7,Ltrim(txt));

         while(1);
  }
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************