/* Project name:
     HID_Read_Write_Polling (USB HID Read & Write Test)
 * Copyright:
     (c) Mikroelektronika, 2011.
 * Revision History:
     20111223:
       - initial release;
 * Description:
     This example establishes connection with the HID terminal that is active
     on the PC. Upon connection establishment, the HID Device Name will appear
     in the respective window. The character that user sends to PIC from the HID
     terminal will be re-sent back to user and dispay it on TFT.
 * Test configuration:
*     MCU:             STM32F207VG
*                      http://www.st.com/internet/com/TECHNICAL_RESOURCES/TECHNICAL_LITERATURE/DATASHEET/CD00237391.pdf
*     dev.board:       mikromedia for stm32 m3 : ac:STM32_mmb
*                      http://www.mikroe.com/eng/products/view/853/mikromedia-for-stm32-m3/
*     Oscillator:      HSI-PLL, 120.000MHz
*     modules:         on-board usb : ac:USB_HID
*     SW:              mikroC PRO for ARM
*                      http://www.mikroe.com/eng/products/view/752/mikroc-pro-for-arm/
* NOTES:  - None
*/

#include "resources.h"

// TFT module connections
unsigned int TFT_DataPort at GPIOE_ODR;
sbit TFT_RST at GPIOE_ODR.B8;
sbit TFT_RS at GPIOE_ODR.B12;
sbit TFT_CS at GPIOE_ODR.B15;
sbit TFT_RD at GPIOE_ODR.B10;
sbit TFT_WR at GPIOE_ODR.B11;
sbit TFT_BLED at GPIOE_ODR.B9;
// End TFT module connections

/*************************************************************************************************
* Draw Accel Screen function
**************************************************************************************************/
void DrawScr() {
  TFT_Fill_Screen(CL_WHITE);
  TFT_Set_Pen(CL_Black, 1);
  TFT_Line(20, 220, 300, 220);
  TFT_LIne(20,  46, 300,  46);
  TFT_Set_Font(&HandelGothic_BT21x22_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("USB HID  TEST", 75, 14);
  TFT_Set_Font(&Verdana12x13_Regular, CL_BLACK, FO_HORIZONTAL);
  TFT_Write_Text("mikromedia for STM32 M3", 19, 223);
  TFT_Set_Font(&Verdana12x13_Regular, CL_RED, FO_HORIZONTAL);
  TFT_Write_Text("www.mikroe.com", 200, 223);
  TFT_Set_Font(&TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
}

char cnt;
char kk;
char readbuff[64];
char writebuff[64];

unsigned long int i = 0;

void main(void){
  TFT_Set_Default_Mode();
  TFT_Init_ILI9341_8bit(320, 240);
  DrawScr();

  TFT_Set_Pen(CL_WHITE, 1);
  TFT_Set_Brush(1, CL_WHITE, 0, 0, 0, 0);
  TFT_Write_Text("Received:", 50, 80);

  HID_Enable(&readbuff,&writebuff);


  while(1){
    USB_Polling_Proc();               // Call this routine periodically
    kk = HID_Read();
    if(kk != 0){
      for(cnt=0;cnt<64;cnt++)
        writebuff[cnt]=readbuff[cnt];
      HID_Write(&writebuff,64);
      TFT_Rectangle(0, 100, 320, 180);
      TFT_Write_Text(readbuff, 50, 150);
    }
  }
}