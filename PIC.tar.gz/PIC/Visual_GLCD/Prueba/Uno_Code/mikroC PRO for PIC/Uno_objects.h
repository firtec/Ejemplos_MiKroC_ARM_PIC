enum GlcdColor {_clClear, _clDraw, _clInvert};
typedef enum {_taLeft, _taCenter, _taRight} TTextAlign;

typedef struct Screen TScreen;

typedef struct  CircleButton {
  TScreen*  OwnerScreen;
  char          Order;
  char          Left;
  char          Top;
  char          Radius;
  char          Visible;
  char          Active;
  char          *Caption;
  TTextAlign     TextAlign;
  const char    *FontName;
  char          PressColEnabled;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TCircleButton;

typedef struct CheckBox {
  TScreen*  OwnerScreen;
  char          Order;
  char          Left;
  char          Top;
  char          Width;
  char          Height;
  char          Visible;
  char          Active;
  char          Checked;
  char          Transparent;
  char          *Caption;
  TTextAlign    TextAlign;
  const char    *FontName;
  char          Rounded;
  char          Corner_Radius;
  void          (*OnUpPtr)();
  void          (*OnDownPtr)();
  void          (*OnClickPtr)();
  void          (*OnPressPtr)();
} TCheckBox;

struct Screen {
  unsigned short         ObjectsCount;
  unsigned int           CircleButtonsCount;
  TCircleButton          * const code *CircleButtons;
  unsigned int           CheckBoxesCount;
  TCheckBox               * const code *CheckBoxes;
};

extern   TScreen                Screen1;
extern   TCircleButton          CircleButton1;
extern   TCheckBox                 CheckBox1;
extern   TCircleButton          * const code Screen1_CircleButtons[1];
extern   TCheckBox               * const code Screen1_CheckBoxes[1];



/////////////////////////
// Events Code Declarations
/////////////////////////

/////////////////////////////////
// Caption variables Declarations
extern char CircleButton1_Caption[];
extern char CheckBox1_Caption[];
/////////////////////////////////

void DrawScreen(TScreen *aScreen);
void DrawCircleButton(TCircleButton *ACircle_button);
void DrawCheckBox(TCheckBox *ACheckBox);
void Check_TP();
void Start_TP();
