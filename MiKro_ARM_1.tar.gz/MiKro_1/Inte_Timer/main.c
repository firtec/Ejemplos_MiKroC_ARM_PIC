 /*************************************************************
*  Descripci�n  : Uso de una interruci�n por Timer_3.
*                 Enciende un LED cada un segundo.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
***************************************************************/
void Timer3_interrupt() iv IVT_INT_TIM3 {
  TIM3_SR.UIF = 0;
  GPIOD_ODR.B15 = ~ GPIOD_ODR.B15;
}

void main() {

  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15); // PD15 como salida
  RCC_APB1ENR.TIM3EN = 1;
  TIM3_CR1.CEN = 0;
  TIM3_PSC = 1343;
  TIM3_ARR = 62499;
  NVIC_IntEnable(IVT_INT_TIM3);
  TIM3_DIER.UIE = 1;
  TIM3_CR1.CEN = 1;

  //GPIO_Clk_Disable(&GPIOD_BASE);   // Desactiva el reloj del puerto
  //GPIO_Clk_Enable(&GPIOD_BASE);    // Activa el reloj del puerto
  while(1)  ;
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************