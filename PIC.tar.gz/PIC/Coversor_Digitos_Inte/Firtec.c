/****************************************************************************
**  Descripci�n  : Lectura de de un canal anal�gico (PIN2).
**                 La informaci�n se muestra en un display de tres d�gitos
**                 c�todo com�n controlados por tres transistores NPN.
**                 Los valores le�dos est�n en Hexadecimal 000 a 3FF.
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 20MHZ
****************************************************************************/
void Leer_Conversor(void);    // Funci�n que leer� el conversor A/D
void Mostrar_Conversor(void); // Funci�n que mostrar� los datos

//unsigned char resto=0;
volatile unsigned char muestras =0;
volatile unsigned int M0=0;

unsigned char unidad=0, decena=0, centena=0;
volatile unsigned int conversion=0;
const unsigned char Digito[16] =
{0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,
 0x67,0x77,0x7C,0x39,0x5E,0x79,0x71};
#define tiempo 5


void Coversor() iv 0x008 ics ICS_AUTO {
 if (PIR1.ADIF) {
    PORTC.B2 = ~PORTC.B2;
    M0 += ADC_Get_Sample(0);
    muestras++;              // Incrementa el contador de muestras

   if(muestras == 10)
    {
        conversion = M0/10;    // Se busca el promedio de las 50 muestras
        unidad = conversion & 0x0F;  // Se enmascara la parte baja (4 de 16bit�s)
        decena = (conversion /16) & 0x0F;         // Intercambia Nibbles bajos
        centena = (conversion /256)& 0x0F;
        muestras =0;             // Limpia registros
        M0=0;
     }

     PIR1.ADIF=0; // Borra la bandera del conversor.
 }
}

void main()
{
 TRISA = 0x01; // RA0 is input
 TRISD = 0; // Puerto D outputs
 TRISB = 0;    // PORTB is output
 TRISC2_bit  = 0;           // Set bit2 de PTC
  PORTC.B2 = 0;
  ADCON0 = 0; // AN0
  ADCON1 = 0x0E; // RA0 AN0
  ADCON2 = 0b10010100;

  GIE_bit = 1; //Enable global interrupt
  PEIE_bit = 1;  //Enable peripheral interrupt
  PIE1.ADIE = 1; //Enable ADC interrupt
  Delay_us(20); //wait for acquisition time
  ADON_bit = 1; //switch on adc module

  while(1)
   {
    Mostrar_Conversor(); // Muestro los datos
    GO_DONE_bit =1;
   }
 }
 
 void Mostrar_Conversor(void){

      PORTB=Digito[unidad];         // Escribe la unidad en el puerto B
      PORTD.RD2 = 1;            // Pone el pin 21
      delay_ms(tiempo);               // Espera 5mS
      PORTD.RD2 = 0;                   // Pone a 0 el pin 21
      PORTB=Digito[decena];         // Escribe la decena en el puerto B
      if((decena > 0) | (centena > 0))  // Si es cero apaga decena
      PORTD.RD1 = 1;                   // Pone a 1 el pin 20
      delay_ms(tiempo);                 // Espera 5mS
      PORTD.RD1 = 0;                 // Pone a 0 el pin 20
      PORTB=Digito[centena];         // Escribe la centena en el puerto B
      if(centena >0)                 // Si es cero apaga centena
      PORTD.RD0 = 1;                   // Pone a 1 el pin 19
      delay_ms(tiempo);                // Espera 5mS
      PORTD.RD0 = 0;                   // Pone a 0 el pin 19

}