/*****************************************************************************
*  Descripci�n  : Ejemplo para el protocolo SPI manejando un modulo ZigBEE
*                 con chip MRF24J40MA de Microchip .
*                 Este ejemplo utiliza SPI3 pines 3|4|5 y I2C1 pines 7|8.
*                 Los datos se muestran en pantalla LCD 20x4
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/

#include "registers.h"
#include "ReadWrite_Routines.h"
#include "Reset_Routines.h"
#include "Misc_Routines.h"
#include "Init_Routines.h"

// Pines usados en la pantalla LCD
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
// Pines usados por el modulo BEE Click
sbit CS at GPIOE_ODR.B5;                // CS pin
sbit RST at GPIOE_ODR.B4;               // RST pin
sbit INT at GPIOD_ODR.B2;               // INT pin
sbit WAKE_ at GPIOC_ODR.B5;             // WAKE pin

extern short int DATA_RX[];
short int  DATA_RX_old[10];
short int temp1;
unsigned char temp;
char txt[4];
char temperatura[6];
char humedad[8];

void main() {
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_12);
   Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  delay_ms(200);
  Lcd_Out(1,1,"ZigBee & ARM MikroC");
  Lcd_Out(2,1,"Temperatura:");
  Lcd_Out(3,1,"Humedad:");
  Lcd_Out(4,2,"www.firtec.com.ar");

  Initialize();     // Configura pines y puerto para ZigBEE

  
  while(1){   

    if(Debounce_INT() == 0 ){             // Espero por datos del ZigBEE
      temp1 = read_ZIGBEE_short(INTSTAT); // Lee y limpia banderas
      read_RX_FIFO(); 
      temp = strcmp(DATA_RX,DATA_RX_old);  // Compara las cadenas
      if(temp != 0){
             temperatura[0] = DATA_RX[0]; // Recupera los datos de temperatura
             temperatura[1] = DATA_RX[1];
             temperatura[2] = DATA_RX[2];
             temperatura[3] = DATA_RX[3];
            // temperatura[4] = DATA_RX[4];
            
             /*humedad[0] = DATA_RX[5];    // Recupera los datos de humedad
             humedad[1] = DATA_RX[6];
             humedad[2] = DATA_RX[7];
             humedad[3] = DATA_RX[8];
             humedad[4] = DATA_RX[9];
             humedad[5] = DATA_RX[10];
             humedad[6] = DATA_RX[11];*/
             
             humedad[0] = DATA_RX[4];    // Recupera los datos de humedad
             humedad[1] = DATA_RX[5];
             humedad[2] = DATA_RX[6];
             humedad[3] = DATA_RX[7];
             humedad[4] = DATA_RX[8];
             humedad[5] = DATA_RX[9];
              //humedad[6] = DATA_RX[10];
             Lcd_Out(2,13,temperatura);
             Lcd_Out(3,13,humedad);
             strcpy(DATA_RX_old,DATA_RX);  // Actualiza nuevo valor
      }
      delay_ms(500);                 // Espera 1/2 segundo
      GPIOD_ODR.B12 = ~ GPIOD_ODR.B12;  // Cambia de estado led verde.
    }
  }
}