 /*************************************************************
*  Descripci�n  : Uso del temporizador de sitema Systick
*
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
***************************************************************/
unsigned char a,b; // Variables del programa

 // Interrupci�n del sistema cada 10 milisegundos.
 void SysTicK_ISR() iv IVT_INT_SysTick ics ICS_AUTO {
   GPIOD_ODR.B14 = ~ GPIOD_ODR.B14;  // Cada 10 mS cambia de estado
  a++;
  b++;
}

void main() {

  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_14);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_13);
  // Interrumpe cada 10 milisegundos
 // Frecuencia del sistema en Mhz * Per�odo en seg
 // 168000000 * 0.01 = 1680000 (solo valores de 24 bits)
  STK_LOAD= 1680000;
  STK_VAL =0;
  STK_CTRL.B0 = 1; // Habilita el SysTick
  STK_CTRL.B1 = 1; // Habilita la interrupci�n del SysTick
  STK_CTRL.B2 = 1; // Systick en modo de contador libre

  while(1){
  if(a== 50) {  // Cada 500 mS cambia de estado
  GPIOD_ODR.B15 = ~ GPIOD_ODR.B15;
  a=0;
  }
  if(b == 25){  // Cada 250 mS cambia de estado
  GPIOD_ODR.B13 = ~ GPIOD_ODR.B13;
  b=0;
   }
  }
}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************