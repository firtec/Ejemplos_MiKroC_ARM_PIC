/*****************************************************************************
*  Descripci�n  : Lectura de ADC1 pin PA5 por interrupcion
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

 // ----- LCD Configuraci�n de pines -----------------------------------------
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
  
 volatile unsigned int conversion = 0;
 char Str[6];
#define led   GPIOD_ODR.B15


 void Enviar_String(const char *s)
{
  while(*s)
  {
   // while(USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
    UART2_Write(*s++);
  }
}

 void ADC_ISR() iv IVT_INT_ADC ics ICS_AUTO {
 if(ADC1_SRbits.EOC){
  ADC1_SRbits.EOC =0;
  led = ~ led;
  conversion = ADC1_Get_Sample(5);
 }
}
  
void main() {

    GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);
    UART2_Init(9600);                  // 9600 Baudios
    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
 
  //------- Config general del modulo ADC ------------------------------------
    ADC_Set_Input_Channel(_ADC_CHANNEL_5);//|_ADC_CHANNEL_6);
    ADC1_Init();
    //ADC1_CR2bits.ADON = 1;
    ADC_CCRbits. ADCPRE = 2;// ADC prescaler APB2 84Mhz/6 = 14hz clock max
    ADC_CCRbits. MULT = 0;  // Independent mode
    ADC_CCRbits. DELAY = 1; // Delay between 2 sampling phases 0000: 5 * TADCCL
    NVIC_IntEnable(IVT_INT_ADC);
  //------ Config particular del ADC1 -  -------------------------------------

    ADC1_SMPR1bits. SMPx_x = 0; // sampling time selection 3 ciclos
    ADC1_SMPR2bits. SMPx_x = 0;
    ADC1_CR1bits. EOCIE = 1; // Interrupt enable for EOC

    Lcd_Out(1, 4, "STM32 -> ESP32" );
    Lcd_Out(2, 1, "PA5_V:" );
    led = 0;

  while(1) {
  ADC1_CR2bits. SWSTART = 1;
  sprintf(Str,"%2.2f ", (conversion *3.3)/4096);
  Lcd_Out(2, 7, Str);
  Enviar_String(Str);
  Delay_ms(1000);

  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************