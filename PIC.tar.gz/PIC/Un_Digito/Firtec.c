
   //#pragma config OSC=HS,PWRT=ON,MCLRE=OFF,LVP=OFF,WDT=OFF
unsigned char contador=0; // Variable en RAM usada para contar
const unsigned char Display[16] =
{0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67,0x77,0x7C,0x39,0x5E,0x79,0x71};

void main() {
  TRISB=0X00;			// Puerto B todo como salida
  PORTB=Display[contador];	// Se pasa el puerto B el estado de contador

    while(1){
    PORTB=Display[contador];
    contador++;					// Incrementa contador en 1
    if(contador >9)				// Si contador es mayor que 15 borrar contador
       contador=0;
    delay_ms(500);

   }
 }