#include "Uno_objects.h"
#include "Uno_resources.h"
#include "built_in.h"


// Glcd module connections
char GLCD_DataPort at PORTD;
sbit GLCD_CS1 at LATB1_bit;
sbit GLCD_CS2 at LATB0_bit;
sbit GLCD_RS at LATB2_bit;
sbit GLCD_RW at LATB3_bit;
sbit GLCD_EN at LATB4_bit;
sbit GLCD_RST at LATB5_bit;
sbit GLCD_CS1_Direction at TRISB1_bit;
sbit GLCD_CS2_Direction at TRISB0_bit;
sbit GLCD_RS_Direction at TRISB2_bit;
sbit GLCD_RW_Direction at TRISB3_bit;
sbit GLCD_EN_Direction at TRISB4_bit;
sbit GLCD_RST_Direction at TRISB5_bit;
// End Glcd module connections

// Touch Panel module connections
sbit DriveA at Todo;
sbit DriveB at Todo;
sbit DriveA_Direction at Todo;
sbit DriveB_Direction at Todo;
// End Touch Panel module connections

// Global variables
unsigned int Xcoord, Ycoord;
const ADC_THRESHOLD = Todo;
char PenDown;
void *PressedObject;
int PressedObjectType;
unsigned int Glcd_caption_length, Glcd_caption_height;
unsigned int display_width, display_height;

int _object_count;
unsigned short object_pressed;
TCircleButton *local_circle_button;
TCircleButton *exec_circle_button;
int circle_button_order;
TCheckBox *local_checkBox;
TCheckBox *exec_checkBox;
int checkBox_order;


static void InitializeTouchPanel() {
  Glcd_Init();                                             // Initialize GLCD
  Glcd_Fill(0);                                            // Clear GLCD

}


/////////////////////////
  TScreen*  CurrentScreen;

  TScreen                Screen1;
  TCircleButton          CircleButton1;
char CircleButton1_Caption[5] = "Text";

  TCheckBox                 CheckBox1;
char CheckBox1_Caption[5] = "Text";

  TCircleButton          * const code Screen1_CircleButtons[1]=
         {
         &CircleButton1        
         };
  TCheckBox               * const code Screen1_CheckBoxes[1]=
         {
         &CheckBox1            
         };




static void InitializeObjects() {
  Screen1.CircleButtonsCount        = 1;
  Screen1.CircleButtons             = Screen1_CircleButtons;
  Screen1.CheckBoxesCount           = 1;
  Screen1.CheckBoxes                = Screen1_CheckBoxes;
  Screen1.ObjectsCount              = 2;


  CircleButton1.OwnerScreen     = &Screen1;
  CircleButton1.Order           = 0;
  CircleButton1.Left            = 89;
  CircleButton1.Top             = 16;
  CircleButton1.Radius          = 15;
  CircleButton1.Visible         = 1;
  CircleButton1.Active          = 1;
  CircleButton1.Caption         = CircleButton1_Caption;
  CircleButton1.TextAlign       = _taCenter;
  CircleButton1.FontName        = Glcd_defaultFont;
  CircleButton1.PressColEnabled = 1;
  CircleButton1.OnUpPtr         = 0;
  CircleButton1.OnDownPtr       = 0;
  CircleButton1.OnClickPtr      = 0;
  CircleButton1.OnPressPtr      = 0;

  CheckBox1.OwnerScreen     = &Screen1;
  CheckBox1.Order           = 1;
  CheckBox1.Left            = 24;
  CheckBox1.Top             = 36;
  CheckBox1.Width           = 36;
  CheckBox1.Height          = 14;
  CheckBox1.Visible         = 1;
  CheckBox1.Active          = 1;
  CheckBox1.Checked          = 1;
  CheckBox1.Transparent     = 1;
  CheckBox1.Caption         = CheckBox1_Caption;
  CheckBox1.TextAlign            = _taLeft;
  CheckBox1.FontName        = Glcd_defaultFont;
  CheckBox1.Rounded          = 1;
  CheckBox1.Corner_Radius      = 3;
  CheckBox1.OnUpPtr         = 0;
  CheckBox1.OnDownPtr       = 0;
  CheckBox1.OnClickPtr      = 0;
  CheckBox1.OnPressPtr      = 0;
}

static char IsInsideObject (unsigned int X, unsigned int Y, unsigned int Left, unsigned int Top, unsigned int Width, unsigned int Height) { // static
  if ( (Left<= X) && (Left+ Width - 1 >= X) &&
       (Top <= Y)  && (Top + Height - 1 >= Y) )
    return 1;
  else
    return 0;
}


#define GetCircleButton(index)        CurrentScreen->CircleButtons[index]
#define GetCheckBox(index)           CurrentScreen->CheckBoxes[index]


void DrawCircleButton(TCircleButton *ACircle_button) {
  if (ACircle_button->Visible == 1) {
    if (object_pressed == 1) {
      object_pressed = 0;
      Glcd_Circle(ACircle_button->Left + ACircle_button->Radius,
                    ACircle_button->Top  + ACircle_button->Radius,
                    ACircle_button->Radius+1, _clDraw);
      Glcd_Circle(ACircle_button->Left + ACircle_button->Radius,
                    ACircle_button->Top  + ACircle_button->Radius,
                    ACircle_button->Radius, _clClear);
      Glcd_Circle(ACircle_button->Left + ACircle_button->Radius,
                    ACircle_button->Top  + ACircle_button->Radius,
                    ACircle_button->Radius-1, _clDraw);
      Glcd_Circle_Fill(ACircle_button->Left + ACircle_button->Radius,
        ACircle_button->Top  +  ACircle_button->Radius,
        ACircle_button->Radius - 2, _clDraw);
    }
    else {
      Glcd_Circle(ACircle_button->Left + ACircle_button->Radius,
                    ACircle_button->Top  + ACircle_button->Radius,
                    ACircle_button->Radius+1, _clClear);
      Glcd_Circle_Fill(ACircle_button->Left + ACircle_button->Radius,
        ACircle_button->Top  + ACircle_button->Radius,
        ACircle_button->Radius, _clDraw);
      if (ACircle_button->Radius >= 5) {
        Glcd_Circle(ACircle_button->Left + ACircle_button->Radius,
          ACircle_button->Top  + ACircle_button->Radius,
          ACircle_button->Radius-1, _clClear);
      }
    }
    Glcd_Set_Font_Adv(ACircle_button->FontName, _clClear, _GLCD_HORIZONTAL);
    Glcd_Write_Text_Return_Pos(ACircle_button->Caption, ACircle_button->Left, ACircle_button->Top);
    if (ACircle_button->TextAlign == _taLeft)
      Glcd_Write_Text_Adv(ACircle_button->Caption, ACircle_button->Left + 3, (ACircle_button->Top + ACircle_button->Radius - Glcd_caption_height / 2));
    else if (ACircle_button->TextAlign == _taCenter)
      Glcd_Write_Text_Adv(ACircle_button->Caption, (ACircle_button->Left + (ACircle_button->Radius*2 - Glcd_caption_length) / 2), (ACircle_button->Top + ACircle_button->Radius - Glcd_caption_height / 2));
    else if (ACircle_button->TextAlign == _taRight)
      Glcd_Write_Text_Adv(ACircle_button->Caption, ACircle_button->Left + (ACircle_button->Radius*2 - Glcd_caption_length - 4), (ACircle_button->Top + ACircle_button->Radius - Glcd_caption_height / 2));
  }
}

void DrawCheckBox(TCheckBox *ACheckBox) {
char _drawcol;
  if (ACheckBox->Visible == 1) {
    Glcd_Set_Font_Adv(ACheckBox->FontName, _clDraw, _GLCD_HORIZONTAL);
    if (ACheckBox->Transparent == 1)
      _drawcol = _clClear;
    else
      _drawcol = _clDraw;
    if (ACheckBox->TextAlign == _taLeft) {
      if (ACheckBox->Rounded == 1) {
        if (ACheckBox->Transparent == 1) {
          Glcd_Rectangle_Round_Edges_Fill(ACheckBox->Left, ACheckBox->Top, ACheckBox->Left + ACheckBox->Height, ACheckBox->Top + ACheckBox->Height - 1, ACheckBox->Corner_Radius, _clDraw);
          Glcd_Rectangle_Round_Edges(ACheckBox->Left + 1, ACheckBox->Top + 1, ACheckBox->Left + ACheckBox->Height - 1, ACheckBox->Top + ACheckBox->Height - 2, ACheckBox->Corner_Radius, _clClear);
        }
        else {
          Glcd_Rectangle_Round_Edges_Fill(ACheckBox->Left + 1, ACheckBox->Top + 1, ACheckBox->Left + ACheckBox->Height - 2, ACheckBox->Top + ACheckBox->Height - 2, ACheckBox->Corner_Radius, _clClear);
          Glcd_Rectangle_Round_Edges(ACheckBox->Left, ACheckBox->Top, ACheckBox->Left + ACheckBox->Height, ACheckBox->Top + ACheckBox->Height - 1, ACheckBox->Corner_Radius, _clDraw);
        }
      } else {
        if (ACheckBox->Transparent == 1) {
          Glcd_Box(ACheckBox->Left, ACheckBox->Top, ACheckBox->Left + ACheckBox->Height, ACheckBox->Top + ACheckBox->Height - 1, _clDraw);
          Glcd_Rectangle(ACheckBox->Left + 1, ACheckBox->Top + 1, ACheckBox->Left + ACheckBox->Height - 1, ACheckBox->Top + ACheckBox->Height - 2, _clClear);
        }
        else {
          Glcd_Box(ACheckBox->Left - 1, ACheckBox->Top - 1, ACheckBox->Left + ACheckBox->Height - 2, ACheckBox->Top + ACheckBox->Height - 2, _clClear);
          Glcd_Rectangle(ACheckBox->Left, ACheckBox->Top, ACheckBox->Left + ACheckBox->Height, ACheckBox->Top + ACheckBox->Height - 1, _clDraw);
        }
      }
      if (ACheckBox->Checked == 1) {
        Glcd_Line(ACheckBox->Left  + (ACheckBox->Height - 2) / 5 + 1, ACheckBox->Top   + (ACheckBox->Height - 2) / 2 + 1,
                  ACheckBox->Left  + (ACheckBox->Height - 2) / 2 , ACheckBox->Top   + (ACheckBox->Height - 2) - (ACheckBox->Height - 2) / 5, _drawcol);
        Glcd_Line(ACheckBox->Left  + (ACheckBox->Height - 2) / 2, ACheckBox->Top   + (ACheckBox->Height - 2) -  (ACheckBox->Height - 2) / 5 - 1,
                  ACheckBox->Left  + (ACheckBox->Height - 2) - (ACheckBox->Height - 2) / 5 , ACheckBox->Top   + (ACheckBox->Height - 2) / 5 + 1, _drawcol);
      }
      Glcd_Write_Text_Return_Pos(ACheckBox->Caption, ACheckBox->Left + ACheckBox->Height + 4, ACheckBox->Top);
      Glcd_Write_Text_Adv(ACheckBox->Caption, ACheckBox->Left + ACheckBox->Height + 4, (ACheckBox->Top + ((ACheckBox->Height - Glcd_caption_height) / 2)));
    } else {
      if (ACheckBox->Rounded == 1) {
        if (ACheckBox->Transparent == 1) {
          Glcd_Rectangle_Round_Edges_Fill(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height  , ACheckBox->Top, ACheckBox->Left + ACheckBox->Width, ACheckBox->Top + ACheckBox->Height - 1, ACheckBox->Corner_Radius, _clDraw);
          Glcd_Rectangle_Round_Edges(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height + 1, ACheckBox->Top + 1, ACheckBox->Left + ACheckBox->Width - 1, ACheckBox->Top + ACheckBox->Height - 2, ACheckBox->Corner_Radius, _clClear);
        }
        else {
          Glcd_Rectangle_Round_Edges_Fill(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height + 1, ACheckBox->Top + 1, ACheckBox->Left + ACheckBox->Width - 2, ACheckBox->Top + ACheckBox->Height - 2, ACheckBox->Corner_Radius, _clClear);
          Glcd_Rectangle_Round_Edges(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height  , ACheckBox->Top, ACheckBox->Left + ACheckBox->Width, ACheckBox->Top + ACheckBox->Height - 1, ACheckBox->Corner_Radius, _clDraw);
        }
      } else {
        if (ACheckBox->Transparent == 1) {
          Glcd_Box(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height  , ACheckBox->Top, ACheckBox->Left + ACheckBox->Width, ACheckBox->Top + ACheckBox->Height - 1, _clDraw);
          Glcd_Rectangle(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height + 1, ACheckBox->Top + 1, ACheckBox->Left + ACheckBox->Width - 1, ACheckBox->Top + ACheckBox->Height - 2, _clClear);
        }
        else {
          Glcd_Box(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height + 1, ACheckBox->Top + 1, ACheckBox->Left + ACheckBox->Width - 2, ACheckBox->Top + ACheckBox->Height - 2, _clClear);
          Glcd_Rectangle(ACheckBox->Left + ACheckBox->Width - ACheckBox->Height  , ACheckBox->Top, ACheckBox->Left + ACheckBox->Width, ACheckBox->Top + ACheckBox->Height - 1, _clDraw);
        }
      }
      if (ACheckBox->Checked == 1) {
        Glcd_Line(ACheckBox->Left  + ACheckBox->Width - (ACheckBox->Height - 2) + (ACheckBox->Height - 2) / 5 - 1, ACheckBox->Top +  (ACheckBox->Height - 2) / 2 + 1,
                  ACheckBox->Left + ACheckBox->Width  - (ACheckBox->Height - 2) / 2 - 2, ACheckBox->Top   + ACheckBox->Height - (ACheckBox->Height - 2) / 5 - 2, _drawcol);
        Glcd_Line(ACheckBox->Left + ACheckBox->Width  - (ACheckBox->Height - 2) /2 - 2, ACheckBox->Top   + (ACheckBox->Height - 2) -  (ACheckBox->Height - 2) / 5 - 1,
                  ACheckBox->Left + ACheckBox->Width  - (ACheckBox->Height - 2) / 5 - 2, ACheckBox->Top   + (ACheckBox->Height - 2) / 5 + 1, _drawcol);
      }
      Glcd_Write_Text_Return_Pos(ACheckBox->Caption, ACheckBox->Left + 3, ACheckBox->Top);
      Glcd_Write_Text_Adv(ACheckBox->Caption, ACheckBox->Left + 3, ACheckBox->Top + (ACheckBox->Height - Glcd_caption_height) / 2);
    }
  }
}

void DrawScreen(TScreen *aScreen) {
 int order;
  unsigned short circle_button_idx;
  TCircleButton *local_circle_button;
  unsigned short checkbox_idx;
  TCheckBox *local_checkBox;

  object_pressed = 0;
  order = 0;
  circle_button_idx = 0;
  checkbox_idx = 0;
  CurrentScreen = aScreen;

  Glcd_Fill(0x00);

  while (order < CurrentScreen->ObjectsCount) {
    if (circle_button_idx < CurrentScreen->CircleButtonsCount) {
      local_circle_button = GetCircleButton(circle_button_idx);
      if (order == local_circle_button->Order) {
        circle_button_idx++;
        order++;
        DrawCircleButton(local_circle_button);
      }
    }

    if (checkbox_idx  < CurrentScreen->CheckBoxesCount) {
      local_checkBox = GetCheckBox(checkbox_idx);
      if (order == local_checkBox->Order) {
        checkbox_idx++;
        order++;
        DrawCheckBox(local_checkBox);
      }
    }

  }
}

void Init_MCU() {
  // Place your code here
}

void Start_TP() {
  Init_MCU();

  InitializeTouchPanel();

  InitializeObjects();
  DrawScreen(&Screen1);
}
