#define __COMPILER__ "MikroC v6.0.0"

void Display_Version_UART()
{
 //UART1_Write_Text("MikroC v5.80");
 UART1_Write_Text(__COMPILER__" - ");
 UART1_Write_Text(__DATE__" - ");
 UART1_Write_Text(__TIME__"\r");
}  