const code char Tahoma11x13_Regular[];
const code char Tahoma12x16_Regular[];
const code char Tahoma21x25_Regular[];
