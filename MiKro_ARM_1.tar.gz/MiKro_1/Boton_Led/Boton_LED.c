/*************************************************************
*  Descripci�n  : Lectura de un bit de un puerto.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
***************************************************************/
#define boton  GPIOA_IDR.B0   // Pin Entrada
#define led    GPIOD_ODR.B15  // Pin salida

void main() {
    /*GPIO_Config(&GPIOD_BASE,  // Configura el pin PD15 como salida
            _GPIO_PINMASK_15,
            _GPIO_CFG_MODE_OUTPUT | _GPIO_CFG_SPEED_2MHZ | _GPIO_CFG_OTYPE_PP);

    GPIO_Config(&GPIOA_BASE, // Confirgura el pin PA0 como entrada
            _GPIO_PINMASK_0,
            _GPIO_CFG_MODE_INPUT | _GPIO_CFG_SPEED_2MHZ | _GPIO_CFG_OTYPE_PP);
            */
    GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);  // PD15 como salida
    GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);  // PA0 como entrada

     GPIOD_ODR.B15 = 1;
  while(1){
           if(boton == 0){
           led = ~ led;
           while(boton ==0);
           }
  /*if(GPIOA_IDR.B0 == 0) {
      GPIOD_ODR.B15 = ~ GPIOD_ODR.B15;
      //delay_ms(200);
      while(GPIOA_IDR.B0 == 0);
      }*/
  
  }

}