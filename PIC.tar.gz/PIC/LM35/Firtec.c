
void Leer_Conversor(void);  // Se declara la funci�n que leer� el conversor A/D
void Mostrar_Conversor(void); // Funci�n que mostrar� los datos

unsigned char contador =0;
unsigned char unidad=0, decena=0, centena=0;
unsigned int conversion=0;
const unsigned char Digito[16] =
{0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,
 0x67,0x77,0x7C,0x39,0x5E,0x79,0x71};
#define tiempo 5

   unsigned int adc;
void main()
{
 ADCON0 = 0;    // RA0
 ADCON1 = 0b00001110;
 ADCON2 = 0b10010100;
 TRISA = 0x01; // RA0 is input
 TRISD = 0; // Puerto D outputs
 TRISB = 0;    // PORTB is output

 while(1)
 {
 Leer_Conversor();
 Mostrar_Conversor(); // Muestro los datos
 }

 }
 
 void Leer_Conversor(void){
  unsigned char resto=0;
  unsigned char muestras =0;
  unsigned int M0=0;         // Variable 0 a 65535
  GO_DONE_bit =1; //Start conversion
do{
        
        while(GO_DONE_bit); //wait for the conversion to finish
         M0 +=(ADC_Read(0) * 500) >> 10;
        //M0 += ADC_Read(0)>>2;                // Lee el A/D y acumula el dato en M0
        muestras++;                     // Incrementa el contador de muestras
}while(muestras <=49);                // Se tomaron  muestras ??
        ADON_bit =0;    //Stop conversion
        conversion = M0/50;    // Se busca el promedio de las 50 muestras
        decena = (conversion / 10) % 10;
        unidad = conversion % 10;
    	//M0 = 0;
 }
 
 void Mostrar_Conversor(void){
      PORTB=Digito[unidad];     // Escribe la unidad en el puerto B
      PORTD.RD2 = 1;            // Pone el pin 21
      delay_ms(tiempo);         // Espera 5mS
      PORTD.RD2 = 0;            // Pone a 0 el pin 21
      PORTB=Digito[decena];     // Escribe la decena en el puerto B
      PORTD.RD1 = 1;            // Pone a 1 el pin 20
      delay_ms(tiempo);         // Espera 5mS
      PORTD.RD1 = 0;            // Pone a 0 el pin 20
}