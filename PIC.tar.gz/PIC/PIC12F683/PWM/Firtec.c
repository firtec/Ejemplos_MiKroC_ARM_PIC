/*

*/

int duty;

void main() {
  OSCCON = 0b01110101; // Oscilador interno en 8MHz
  ANSEL = 0;           // Canales analogicos desactivados
  TRISIO.B2 = 0;
  TRISIO.B4 = 1;
  TRISIO.B5 = 1;
  PWM1_Init(5000);     // Frecuencia carrier del PWM1 en 5KHz
  duty  = 0;           // Inicia el duty en 0
  PWM1_Start();        // Inicia PWM1
  PWM1_Set_Duty(duty); // Pasa el duty al PWM1

  while (1) {
      if (GPIO.B4){  // estado del bot�n (RA0) activado
      Delay_ms(4);
      duty++;        // incrementa duty
      if(duty >= 256)// duty es mayor a 255?
         duty = 255;
      PWM1_Set_Duty(duty); // Pasa el duty al PWM
     }
    if (GPIO.B5) {       // estado del bot�n (RA1) activado
      Delay_ms(4);
      duty--;            // decrementa duty
      if(duty < 0)       // el duty es menor que 0?
         duty = 0;
      PWM1_Set_Duty(duty);
     }
    Delay_ms(10);        // slow down change pace a little
  }
}