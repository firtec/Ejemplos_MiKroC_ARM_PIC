# -*- coding: utf-8 -*-
#!/usr/bin/env python
import socket
import sys
import errno
import time

from Tkinter import *
from tkMessageBox import showinfo

bandera = 0

class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)

#********** Función para conocer el IP del servidor **************************
def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 0))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP
#*****************************************************************************
UDP_PORT = 30000    # Puerto del socket en el Servidor
Dir_IP = get_ip()   # Obtiene la dirección del Servidor
time.sleep(0.02)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # Crea Socket UDP
sock.bind(("", UDP_PORT)) # Recibir de cualquier cliente
sock.setblocking(0)   # Socket NO Bloqueante

ventana = Tk()    # Crea la ventana
ventana.title('UDP_LED')  # Nombre de la ventana
ventana.config(bg="beige")     # Color de fondo
ventana.geometry("400x200")    # Tamaño de la ventana
ventana.resizable(0,0) # Evita que se pueda cambiar de tamaño la ventana

x = 0    # Variable del sistema
y = 0    # Variable del sistema

#************************ FUNCIÓN RECURSIVA **********************************
def update_label():
    try:
        data,addr = sock.recvfrom(40)
    except socket.error, e:
        err = e.args[0]
        if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
            time.sleep(0.01)
            #print 'No hay datos!!'
            ventana.after(1, update_label)
    else:
        global bandera
        if bandera == 1:
            sock.sendto('4', addr) # Envía comando para el Led Azul
            bandera = 0
        if bandera == 2:
            sock.sendto('5', addr) # Envía comando para el Led Naranja
            bandera = 0
        sock.sendto('0', addr)    # Envía dato control
        label_cliente.config(text = addr) # Muestra info del cliente
        ventana.after(1, update_label)

#******************** Función del Boton LED **********************************
def azul( ):
    global bandera  # Bandera el es comando para encender los led´s
    bandera = 1
def naranja( ):
    global bandera  # Bandera el es comando para encender los led´s
    bandera = 2

label_firtec = Label(ventana, text="www.firtec.com.ar", bg="beige", fg="black", font=("bold", 13))
label_firtec.place(x=140, y=160)
label_rotulo_IP = Label(ventana, text="Configuración del Servidor.", bg="beige", fg="black", font=("Helvetica", 12))
label_rotulo_IP.place(x=10, y=5)
label_Nombre_IP = Label(ventana, text="IP:", bg="beige", fg="blue", font=("Helvetica", 14))
label_Nombre_IP.place(x=40, y=35)

label_IP = Label(ventana, bg="beige", fg="blue", font=("Helvetica", 14))
label_IP.config(text = Dir_IP)
label_IP.place(x=68, y=35)

label_Nombre_Puerto = Label(ventana, text="Puerto:", bg="beige", fg="blue", font=("Helvetica", 14))
label_Nombre_Puerto.place(x=220, y=35)

label_Puerto = Label(ventana, bg="beige", fg="blue", font=("Helvetica", 14))
label_Puerto.config(text = UDP_PORT)
label_Puerto.place(x=288, y=35)

label_Nota = Label(ventana,text="No olvide reiniciar el cliente!!!", bg="beige", fg="red", font=("Helvetica", 14))
label_Nota.place(x=70, y=98)

label_cliente = Label(ventana, text="", bg="beige", fg="blue", font=("Helvetica", 10))
label_cliente.place(x=246, y=120)

Rotulo_cliente = Label(ventana, text="IP del Cliente y Puerto", bg="beige", fg="black", font=("Helvetica", 8))
Rotulo_cliente.place(x=250, y=140)

boton_0 = Button(ventana, text=' LED Naranja ', command=naranja)  # Boton del LED
boton_0.pack()
boton_0.place(x=240, y=70)    # Coordenada del Boton

boton_1 = Button(ventana, text='     LED Azul     ', command=azul)  # Boton del LED
boton_1.pack()
boton_1.place(x=68, y=70)    # Coordenada del Boton

update_label()
#ventana.after(1, update_label)
ventana.mainloop( )
