#include "progress_objects.h"
#include "progress_resources.h"

// TFT module connections
unsigned int TFT_DataPort at GPIOE_ODR;
sbit TFT_RST at GPIOE_ODR.B8;
sbit TFT_RS at GPIOE_ODR.B12;
sbit TFT_CS at GPIOE_ODR.B15;
sbit TFT_RD at GPIOE_ODR.B10;
sbit TFT_WR at GPIOE_ODR.B11;
sbit TFT_BLED at GPIOE_ODR.B9;
// End TFT module connections

// Touch Panel module connections
sbit DriveX_Left at GPIOB_ODR.B1;
sbit DriveX_Right at GPIOB_ODR.B8;
sbit DriveY_Up at GPIOB_ODR.B9;
sbit DriveY_Down at GPIOB_ODR.B0;
// End Touch Panel module connections

// Global variables
unsigned int Xcoord, Ycoord;
const ADC_THRESHOLD = 750;
char PenDown;
void *PressedObject;
int PressedObjectType;
unsigned int caption_length, caption_height;
unsigned int display_width, display_height;

int _object_count;
unsigned short object_pressed;
TButton_Round *local_round_button;
TButton_Round *exec_round_button;
short round_button_order;
TLabel *local_label;
TLabel *exec_label;
short label_order;
TBox *local_box;
TBox *exec_box;
short box_order;
TBox_Round *local_round_box;
TBox_Round *exec_round_box;
short box_round_order;

void Init_ADC() {
  ADC_Set_Input_Channel(_ADC_CHANNEL_8 | _ADC_CHANNEL_9);
  ADC1_Init();
  Delay_ms(100);
}

static void InitializeTouchPanel() {
  Init_ADC();
  TFT_Set_Default_Mode();
  TFT_Init_ILI9341_8bit(320, 240);

  TP_TFT_Init(320, 240, 8, 9);                 // Initialize touch panel
  TP_TFT_Set_ADC_Threshold(ADC_THRESHOLD);     // Set touch panel ADC threshold

  PenDown = 0;
  PressedObject = 0;
  PressedObjectType = -1;
}

void Calibrate() {
  TFT_Set_Pen(CL_WHITE, 3);
  TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
  TFT_Write_Text("Touch selected corners for calibration", 50, 80);
  TFT_Line(315, 239, 319, 239);
  TFT_Line(309, 229, 319, 239);
  TFT_Line(319, 234, 319, 239);
  TFT_Write_Text("first here",235,220);

  TP_TFT_Calibrate_Min();                      // Calibration of bottom left corner
  Delay_ms(500);

  TFT_Set_Pen(CL_BLACK, 3);
  TFT_Set_Font(TFT_defaultFont, CL_BLACK, FO_HORIZONTAL);
  TFT_Line(315, 239, 319, 239);
  TFT_Line(309, 229, 319, 239);
  TFT_Line(319, 234, 319, 239);
  TFT_Write_Text("first here",235,220);

  TFT_Set_Pen(CL_WHITE, 3);
  TFT_Set_Font(TFT_defaultFont, CL_WHITE, FO_HORIZONTAL);
  TFT_Write_Text("now here ", 20, 5);
  TFT_Line(0, 0, 5, 0);
  TFT_Line(0, 0, 0, 5);
  TFT_Line(0, 0, 10, 10);

  TP_TFT_Calibrate_Max();                      // Calibration of bottom left corner
  Delay_ms(500);
}


/////////////////////////
  TScreen*  CurrentScreen;

  TScreen                Screen3;
  TBox                   Box1;
  TLabel                 Label2;
char Label2_Caption[17] = "Welcome  to  the";

  TLabel                 Label3;
char Label3_Caption[23] = "Progress  bar  example";

  TBox_Round             BoxRound2;
  TLabel                 Label5;
char Label5_Caption[11] = "Loading...";

  TBox_Round             DgrBoxRound2;
  TButton_Round          ButtonRound1;
char ButtonRound1_Caption[21] = "Press to continue...";

  TBox_Round             BoxRound1;
  TLabel                 Label1;
char Label1_Caption[8] = "Loaded!";

  TButton_Round          * const code Screen1_Buttons_Round[1]=
         {
         &ButtonRound1         
         };
  TLabel                 * const code Screen1_Labels[4]=
         {
         &Label2,              
         &Label3,              
         &Label5,              
         &Label1               
         };
  TBox                   * const code Screen1_Boxes[1]=
         {
         &Box1                 
         };
  TBox_Round             * const code Screen1_Boxes_Round[3]=
         {
         &BoxRound2,           
         &DgrBoxRound2,        
         &BoxRound1            
         };




static void InitializeObjects() {
  Screen3.Color                     = 0x0000;
  Screen3.Width                     = 320;
  Screen3.Height                    = 240;
  Screen3.Buttons_RoundCount        = 1;
  Screen3.Buttons_Round             = Screen1_Buttons_Round;
  Screen3.LabelsCount               = 4;
  Screen3.Labels                    = Screen1_Labels;
  Screen3.BoxesCount                = 1;
  Screen3.Boxes                     = Screen1_Boxes;
  Screen3.Boxes_RoundCount          = 3;
  Screen3.Boxes_Round               = Screen1_Boxes_Round;
  Screen3.ObjectsCount              = 9;


  Box1.OwnerScreen     = &Screen3;
  Box1.Order           = 0;
  Box1.Left            = 57;
  Box1.Top             = 142;
  Box1.Width           = 210;
  Box1.Height          = 33;
  Box1.Pen_Width       = 1;
  Box1.Pen_Color       = 0x0000;
  Box1.Visible         = 1;
  Box1.Active          = 1;
  Box1.Transparent     = 1;
  Box1.Gradient        = 0;
  Box1.Gradient_Orientation    = 0;
  Box1.Gradient_Start_Color    = 0xFFFF;
  Box1.Gradient_End_Color      = 0xC618;
  Box1.Color           = 0x0000;
  Box1.PressColEnabled     = 0;
  Box1.Press_Color     = 0x8410;
  Box1.OnUpPtr         = 0;
  Box1.OnDownPtr       = 0;
  Box1.OnClickPtr      = 0;
  Box1.OnPressPtr      = 0;

  Label2.OwnerScreen     = &Screen3;
  Label2.Order          = 1;
  Label2.Left           = 89;
  Label2.Top            = 28;
  Label2.Width          = 181;
  Label2.Height         = 24;
  Label2.Visible        = 1;
  Label2.Active         = 1;
  Label2.Caption        = Label2_Caption;
  Label2.FontName       = Tahoma21x25_Regular;
  Label2.Font_Color     = 0x07FF;
  Label2.OnUpPtr         = 0;
  Label2.OnDownPtr       = 0;
  Label2.OnClickPtr      = 0;
  Label2.OnPressPtr      = 0;

  Label3.OwnerScreen     = &Screen3;
  Label3.Order          = 2;
  Label3.Left           = 61;
  Label3.Top            = 55;
  Label3.Width          = 243;
  Label3.Height         = 24;
  Label3.Visible        = 1;
  Label3.Active         = 1;
  Label3.Caption        = Label3_Caption;
  Label3.FontName       = Tahoma21x25_Regular;
  Label3.Font_Color     = 0x07FF;
  Label3.OnUpPtr         = 0;
  Label3.OnDownPtr       = 0;
  Label3.OnClickPtr      = 0;
  Label3.OnPressPtr      = 0;

  BoxRound2.OwnerScreen     = &Screen3;
  BoxRound2.Order           = 3;
  BoxRound2.Left            = 62;
  BoxRound2.Top             = 145;
  BoxRound2.Width           = 200;
  BoxRound2.Height          = 28;
  BoxRound2.Pen_Width       = 1;
  BoxRound2.Pen_Color       = 0xFFFF;
  BoxRound2.Visible         = 1;
  BoxRound2.Active          = 1;
  BoxRound2.Transparent     = 1;
  BoxRound2.Gradient        = 1;
  BoxRound2.Gradient_Orientation    = 0;
  BoxRound2.Gradient_Start_Color    = 0xFFFF;
  BoxRound2.Gradient_End_Color      = 0xF800;
  BoxRound2.Color           = 0xC618;
  BoxRound2.PressColEnabled     = 0;
  BoxRound2.Press_Color     = 0x8410;
  BoxRound2.OnUpPtr         = 0;
  BoxRound2.OnDownPtr       = 0;
  BoxRound2.OnClickPtr      = 0;
  BoxRound2.OnPressPtr      = 0;

  Label5.OwnerScreen     = &Screen3;
  Label5.Order          = 4;
  Label5.Left           = 134;
  Label5.Top            = 118;
  Label5.Width          = 69;
  Label5.Height         = 15;
  Label5.Visible        = 1;
  Label5.Active         = 1;
  Label5.Caption        = Label5_Caption;
  Label5.FontName       = Tahoma12x16_Regular;
  Label5.Font_Color     = 0x0000;
  Label5.OnUpPtr         = 0;
  Label5.OnDownPtr       = 0;
  Label5.OnClickPtr      = 0;
  Label5.OnPressPtr      = 0;

  DgrBoxRound2.OwnerScreen     = &Screen3;
  DgrBoxRound2.Order           = 5;
  DgrBoxRound2.Left            = 31;
  DgrBoxRound2.Top             = 168;
  DgrBoxRound2.Width           = 1;
  DgrBoxRound2.Height          = 28;
  DgrBoxRound2.Pen_Width       = 1;
  DgrBoxRound2.Pen_Color       = 0xFFFF;
  DgrBoxRound2.Visible         = 0;
  DgrBoxRound2.Active          = 1;
  DgrBoxRound2.Transparent     = 1;
  DgrBoxRound2.Gradient        = 1;
  DgrBoxRound2.Gradient_Orientation    = 0;
  DgrBoxRound2.Gradient_Start_Color    = 0xFFFF;
  DgrBoxRound2.Gradient_End_Color      = 0xC618;
  DgrBoxRound2.Color           = 0xC618;
  DgrBoxRound2.PressColEnabled     = 1;
  DgrBoxRound2.Press_Color     = 0x8410;
  DgrBoxRound2.OnUpPtr         = 0;
  DgrBoxRound2.OnDownPtr       = 0;
  DgrBoxRound2.OnClickPtr      = 0;
  DgrBoxRound2.OnPressPtr      = 0;

  ButtonRound1.OwnerScreen     = &Screen3;
  ButtonRound1.Order           = 6;
  ButtonRound1.Left            = 105;
  ButtonRound1.Top             = 192;
  ButtonRound1.Width           = 117;
  ButtonRound1.Height          = 31;
  ButtonRound1.Pen_Width       = 1;
  ButtonRound1.Pen_Color       = 0x0000;
  ButtonRound1.Visible         = 1;
  ButtonRound1.Active          = 1;
  ButtonRound1.Transparent     = 1;
  ButtonRound1.Caption         = ButtonRound1_Caption;
  ButtonRound1.FontName        = Tahoma11x13_Regular;
  ButtonRound1.PressColEnabled = 1;
  ButtonRound1.Font_Color      = 0x0000;
  ButtonRound1.Gradient        = 1;
  ButtonRound1.Gradient_Orientation    = 0;
  ButtonRound1.Gradient_Start_Color    = 0xFFFF;
  ButtonRound1.Gradient_End_Color      = 0x8410;
  ButtonRound1.Color           = 0xC618;
  ButtonRound1.Press_Color     = 0x8410;
  ButtonRound1.OnUpPtr         = 0;
  ButtonRound1.OnDownPtr       = 0;
  ButtonRound1.OnClickPtr      = ButtonRound1Click;
  ButtonRound1.OnPressPtr      = 0;

  BoxRound1.OwnerScreen     = &Screen3;
  BoxRound1.Order           = 7;
  BoxRound1.Left            = 64;
  BoxRound1.Top             = 145;
  BoxRound1.Width           = 2;
  BoxRound1.Height          = 28;
  BoxRound1.Pen_Width       = 1;
  BoxRound1.Pen_Color       = 0xFFFF;
  BoxRound1.Visible         = 0;
  BoxRound1.Active          = 1;
  BoxRound1.Transparent     = 1;
  BoxRound1.Gradient        = 1;
  BoxRound1.Gradient_Orientation    = 0;
  BoxRound1.Gradient_Start_Color    = 0xFFFF;
  BoxRound1.Gradient_End_Color      = 0x07E0;
  BoxRound1.Color           = 0xC618;
  BoxRound1.PressColEnabled     = 0;
  BoxRound1.Press_Color     = 0x8410;
  BoxRound1.OnUpPtr         = 0;
  BoxRound1.OnDownPtr       = 0;
  BoxRound1.OnClickPtr      = 0;
  BoxRound1.OnPressPtr      = 0;

  Label1.OwnerScreen     = &Screen3;
  Label1.Order          = 8;
  Label1.Left           = 135;
  Label1.Top            = 100;
  Label1.Width          = 58;
  Label1.Height         = 15;
  Label1.Visible        = 0;
  Label1.Active         = 1;
  Label1.Caption        = Label1_Caption;
  Label1.FontName       = Tahoma12x16_Regular;
  Label1.Font_Color     = 0x0000;
  Label1.OnUpPtr         = 0;
  Label1.OnDownPtr       = 0;
  Label1.OnClickPtr      = 0;
  Label1.OnPressPtr      = 0;
}

static char IsInsideObject (unsigned int X, unsigned int Y, unsigned int Left, unsigned int Top, unsigned int Width, unsigned int Height) { // static
  if ( (Left<= X) && (Left+ Width - 1 >= X) &&
       (Top <= Y)  && (Top + Height - 1 >= Y) )
    return 1;
  else
    return 0;
}


#define GetRoundButton(index)         CurrentScreen->Buttons_Round[index]
#define GetLabel(index)               CurrentScreen->Labels[index]
#define GetBox(index)                 CurrentScreen->Boxes[index]
#define GetBox_Round(index)           CurrentScreen->Boxes_Round[index]


void DrawRoundButton(TButton_Round *Around_button) {
    if (Around_button->Visible == 1) {
      if (object_pressed == 1) {
        object_pressed = 0;
        TFT_Set_Brush(Around_button->Transparent, Around_button->Press_Color, Around_button->Gradient, Around_button->Gradient_Orientation,
                      Around_button->Gradient_End_Color, Around_button->Gradient_Start_Color);
      }
      else {
        TFT_Set_Brush(Around_button->Transparent, Around_button->Color, Around_button->Gradient, Around_button->Gradient_Orientation,
                      Around_button->Gradient_Start_Color, Around_button->Gradient_End_Color);
      }
      TFT_Set_Pen(Around_button->Pen_Color, Around_button->Pen_Width);
      if (Around_button->Height > Around_button->Width) {
        TFT_Rectangle_Round_Edges(Around_button->Left + 1, Around_button->Top + 1,
          Around_button->Left + Around_button->Width - 2,
          Around_button->Top + Around_button->Height - 2, (Around_button->Width/4));
      }
      else
        {
          TFT_Rectangle_Round_Edges(Around_button->Left + 1, Around_button->Top + 1,
            Around_button->Left + Around_button->Width - 2,
            Around_button->Top + Around_button->Height - 2, (Around_button->Height/4));
        }
      TFT_Set_Font(Around_button->FontName, Around_button->Font_Color, FO_HORIZONTAL);
      TFT_Write_Text_Return_Pos(Around_button->Caption, Around_button->Left, Around_button->Top);
      TFT_Write_Text(Around_button->Caption, (Around_button->Left + ((Around_button->Width - caption_length) / 2)),
                    (Around_button->Top + ((Around_button->Height - caption_height) / 2)));
    }
}

void DrawLabel(TLabel *ALabel) {
int x_pos, y_pos;
  x_pos = 0;
  y_pos = 0;
  if (ALabel->Visible == 1) {
    TFT_Set_Font(ALabel->FontName, ALabel->Font_Color, FO_HORIZONTAL);
    TFT_Write_Text_Return_Pos(ALabel->Caption, ALabel->Left, ALabel->Top);
    x_pos = ALabel->Left + ((int)(ALabel->Width - caption_length) / 2);
    y_pos = ALabel->Top + ((int)(ALabel->Height - caption_height) / 2);
    if (x_pos > ALabel->Left) {
      TFT_Write_Text(ALabel->Caption, x_pos, y_pos);
    }
    else {
      TFT_Write_Text(ALabel->Caption, ALabel->Left, ALabel->Top);
    }
  }
}

void DrawBox(TBox *ABox) {
  if (ABox->Visible == 1) {
    if (object_pressed == 1) {
      object_pressed = 0;
      TFT_Set_Brush(ABox->Transparent, ABox->Press_Color, ABox->Gradient, ABox->Gradient_Orientation, ABox->Gradient_End_Color, ABox->Gradient_Start_Color);
    }
    else {
      TFT_Set_Brush(ABox->Transparent, ABox->Color, ABox->Gradient, ABox->Gradient_Orientation, ABox->Gradient_Start_Color, ABox->Gradient_End_Color);
    }
    TFT_Set_Pen(ABox->Pen_Color, ABox->Pen_Width);
    TFT_Rectangle(ABox->Left, ABox->Top, ABox->Left + ABox->Width - 1, ABox->Top + ABox->Height - 1);
  }
}

void DrawRoundBox(TBox_Round *Around_box) {
    if (Around_box->Visible == 1) {
      if (object_pressed == 1) {
        object_pressed = 0;
        TFT_Set_Brush(Around_box->Transparent, Around_box->Press_Color, Around_box->Gradient, Around_box->Gradient_Orientation,
                      Around_box->Gradient_End_Color, Around_box->Gradient_Start_Color);
      }
      else {
        TFT_Set_Brush(Around_box->Transparent, Around_box->Color, Around_box->Gradient, Around_box->Gradient_Orientation,
                      Around_box->Gradient_Start_Color, Around_box->Gradient_End_Color);
      }
      TFT_Set_Pen(Around_box->Pen_Color, Around_box->Pen_Width);
      if (Around_box->Height > Around_box->Width) {
        TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
          Around_box->Left + Around_box->Width - 2,
          Around_box->Top + Around_box->Height - 2, (Around_box->Width/4));
      }
      else
        {
          TFT_Rectangle_Round_Edges(Around_box->Left + 1, Around_box->Top + 1,
            Around_box->Left + Around_box->Width - 2,
            Around_box->Top + Around_box->Height - 2, (Around_box->Height/4));
        }
    }
}

void DrawScreen(TScreen *aScreen) {
  unsigned short order;
  unsigned short round_button_idx;
  TButton_Round *local_round_button;
  unsigned short label_idx;
  TLabel *local_label;
  unsigned short box_idx;
  TBox *local_box;
  unsigned short round_box_idx;
  TBox_Round *local_round_box;
  char save_bled, save_bled_direction;

  object_pressed = 0;
  order = 0;
  round_button_idx = 0;
  label_idx = 0;
  box_idx = 0;
  round_box_idx = 0;
  CurrentScreen = aScreen;

  if ((display_width != CurrentScreen->Width) || (display_height != CurrentScreen->Height)) {
    save_bled = TFT_BLED;
    TFT_BLED           = 0;
    TFT_Init_ILI9341_8bit(CurrentScreen->Width, CurrentScreen->Height);
    TP_TFT_Init(CurrentScreen->Width, CurrentScreen->Height, 8, 9);    // Initialize touch panel
    TP_TFT_Set_ADC_Threshold(ADC_THRESHOLD);                           // Set touch panel ADC threshold
    TFT_Fill_Screen(CurrentScreen->Color);
    display_width = CurrentScreen->Width;
    display_height = CurrentScreen->Height;
    TFT_BLED           = save_bled;
  }
  else
    TFT_Fill_Screen(CurrentScreen->Color);


  while (order < CurrentScreen->ObjectsCount) {
    if (round_button_idx < CurrentScreen->Buttons_RoundCount) {
      local_round_button = GetRoundButton(round_button_idx);
      if (order == local_round_button->Order) {
        order++;
        round_button_idx++;
        DrawRoundButton(local_round_button);
      }
    }

    if (label_idx < CurrentScreen->LabelsCount) {
      local_label = GetLabel(label_idx);
      if (order == local_label->Order) {
        label_idx++;
        order++;
        DrawLabel(local_label);
      }
    }

    if (box_idx < CurrentScreen->BoxesCount) {
      local_box = GetBox(box_idx);
      if (order == local_box->Order) {
        box_idx++;
        order++;
        DrawBox(local_box);
      }
    }

    if (round_box_idx < CurrentScreen->Boxes_RoundCount) {
      local_round_box = GetBox_Round(round_box_idx);
      if (order == local_round_box->Order) {
        round_box_idx++;
        order++;
        DrawRoundBox(local_round_box);
      }
    }

  }
}

void Get_Object(unsigned int X, unsigned int Y) {
  round_button_order  = -1;
  label_order         = -1;
  box_order           = -1;
  box_round_order     = -1;
  //  Buttons with Round Edges
  for ( _object_count = 0 ; _object_count < CurrentScreen->Buttons_RoundCount ; _object_count++ ) {
    local_round_button = GetRoundButton(_object_count);
    if (local_round_button->Active == 1) {
      if (IsInsideObject(X, Y, local_round_button->Left, local_round_button->Top,
                         local_round_button->Width, local_round_button->Height) == 1) {
        round_button_order = local_round_button->Order;
        exec_round_button = local_round_button;
      }
    }
  }

  //  Labels
  for ( _object_count = 0 ; _object_count < CurrentScreen->LabelsCount ; _object_count++ ) {
    local_label = GetLabel(_object_count);
    if (local_label->Active == 1) {
      if (IsInsideObject(X, Y, local_label->Left, local_label->Top,
                         local_label->Width, local_label->Height) == 1) {
        label_order = local_label->Order;
        exec_label = local_label;
      }
    }
  }

  //  Boxes
  for ( _object_count = 0 ; _object_count < CurrentScreen->BoxesCount ; _object_count++ ) {
    local_box = GetBox(_object_count);
    if (local_box->Active == 1) {
      if (IsInsideObject(X, Y, local_box->Left, local_box->Top,
                         local_box->Width, local_box->Height) == 1) {
        box_order = local_box->Order;
        exec_box = local_box;
      }
    }
  }

  //  Boxes with Round Edges
  for ( _object_count = 0 ; _object_count < CurrentScreen->Boxes_RoundCount ; _object_count++ ) {
    local_round_box = GetBox_Round(_object_count);
    if (local_round_box->Active == 1) {
      if (IsInsideObject(X, Y, local_round_box->Left, local_round_box->Top,
                         local_round_box->Width, local_round_box->Height) == 1) {
        box_round_order = local_round_box->Order;
        exec_round_box = local_round_box;
      }
    }
  }

  _object_count = -1;
  if (round_button_order > _object_count)
    _object_count = round_button_order;
  if (label_order >  _object_count )
    _object_count = label_order;
  if (box_order >  _object_count )
    _object_count = box_order;
  if (box_round_order >  _object_count )
    _object_count = box_round_order;
}


static void Process_TP_Press(unsigned int X, unsigned int Y) {
  exec_round_button   = 0;
  exec_label          = 0;
  exec_box            = 0;
  exec_round_box      = 0;

  Get_Object(X, Y);


  if (_object_count != -1) {
    if (_object_count == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->OnPressPtr != 0) {
          exec_round_button->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnPressPtr != 0) {
          exec_label->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == box_order) {
      if (exec_box->Active == 1) {
        if (exec_box->OnPressPtr != 0) {
          exec_box->OnPressPtr();
          return;
        }
      }
    }

    if (_object_count == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->OnPressPtr != 0) {
          exec_round_box->OnPressPtr();
          return;
        }
      }
    }

  }
}

static void Process_TP_Up(unsigned int X, unsigned int Y) {

  switch (PressedObjectType) {
    // Round Button
    case 1: {
      if (PressedObject != 0) {
        exec_round_button = (TButton_Round*)PressedObject;
        if ((exec_round_button->PressColEnabled == 1) && (exec_round_button->OwnerScreen == CurrentScreen)) {
          DrawRoundButton(exec_round_button);
        }
        break;
      }
      break;
    }
    // Box
    case 6: {
      if (PressedObject != 0) {
        exec_box = (TBox*)PressedObject;
        if ((exec_box->PressColEnabled == 1) && (exec_box->OwnerScreen == CurrentScreen)) {
          DrawBox(exec_box);
        }
        break;
      }
      break;
    }
    // Round Box
    case 7: {
      if (PressedObject != 0) {
        exec_round_box = (TBox_Round*)PressedObject;
        if ((exec_round_box->PressColEnabled == 1) && (exec_round_box->OwnerScreen == CurrentScreen)) {
          DrawRoundBox(exec_round_box);
        }
        break;
      }
      break;
    }
  }

  exec_label          = 0;

  Get_Object(X, Y);


  if (_object_count != -1) {
  // Buttons with Round Edges
    if (_object_count == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->OnUpPtr != 0)
          exec_round_button->OnUpPtr();
        if (PressedObject == (void *)exec_round_button)
          if (exec_round_button->OnClickPtr != 0)
            exec_round_button->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // Labels
    if (_object_count == label_order) {
      if (exec_label->Active == 1) {
        if (exec_label->OnUpPtr != 0)
          exec_label->OnUpPtr();
        if (PressedObject == (void *)exec_label)
          if (exec_label->OnClickPtr != 0)
            exec_label->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // Boxes
    if (_object_count == box_order) {
      if (exec_box->Active == 1) {
        if (exec_box->OnUpPtr != 0)
          exec_box->OnUpPtr();
        if (PressedObject == (void *)exec_box)
          if (exec_box->OnClickPtr != 0)
            exec_box->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  // Boxes with Round Edges
    if (_object_count == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->OnUpPtr != 0)
          exec_round_box->OnUpPtr();
        if (PressedObject == (void *)exec_round_box)
          if (exec_round_box->OnClickPtr != 0)
            exec_round_box->OnClickPtr();
        PressedObject = 0;
        PressedObjectType = -1;
        return;
      }
    }

  }
  PressedObject = 0;
  PressedObjectType = -1;
}

static void Process_TP_Down(unsigned int X, unsigned int Y) {

  object_pressed      = 0;
  exec_round_button   = 0;
  exec_label          = 0;
  exec_box            = 0;
  exec_round_box      = 0;

  Get_Object(X, Y);

  if (_object_count != -1) {
    if (_object_count == round_button_order) {
      if (exec_round_button->Active == 1) {
        if (exec_round_button->PressColEnabled == 1) {
          object_pressed = 1;
          DrawRoundButton(exec_round_button);
        }
        PressedObject = (void *)exec_round_button;
        PressedObjectType = 1;
        if (exec_round_button->OnDownPtr != 0) {
          exec_round_button->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == label_order) {
      if (exec_label->Active == 1) {
        PressedObject = (void *)exec_label;
        PressedObjectType = 2;
        if (exec_label->OnDownPtr != 0) {
          exec_label->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == box_order) {
      if (exec_box->Active == 1) {
        if (exec_box->PressColEnabled == 1) {
          object_pressed = 1;
          DrawBox(exec_box);
        }
        PressedObject = (void *)exec_box;
        PressedObjectType = 6;
        if (exec_box->OnDownPtr != 0) {
          exec_box->OnDownPtr();
          return;
        }
      }
    }

    if (_object_count == box_round_order) {
      if (exec_round_box->Active == 1) {
        if (exec_round_box->PressColEnabled == 1) {
          object_pressed = 1;
          DrawRoundBox(exec_round_box);
        }
        PressedObject = (void *)exec_round_box;
        PressedObjectType = 7;
        if (exec_round_box->OnDownPtr != 0) {
          exec_round_box->OnDownPtr();
          return;
        }
      }
    }

  }
}

void Check_TP() {
  if (TP_TFT_Press_Detect()) {
    // After a PRESS is detected read X-Y and convert it to Display dimensions space
    if (TP_TFT_Get_Coordinates(&Xcoord, &Ycoord) == 0) {
      Process_TP_Press(Xcoord, Ycoord);
      if (PenDown == 0) {
        PenDown = 1;
        Process_TP_Down(Xcoord, Ycoord);
      }
    }
  }
  else if (PenDown == 1) {
    PenDown = 0;
    Process_TP_Up(Xcoord, Ycoord);
  }
}

void Init_MCU(){
  GPIO_Config(&GPIOE_BASE, _GPIO_PINMASK_9, _GPIO_CFG_DIGITAL_OUTPUT);
  TFT_BLED = 1;
  TFT_Set_Default_Mode();
  TP_TFT_Set_Default_Mode();
}

void Start_TP() {
  Init_MCU();

  InitializeTouchPanel();

  Delay_ms(1000);
  TFT_Fill_Screen(0);
  Calibrate();
  TFT_Fill_Screen(0);

  InitializeObjects();
  display_width = Screen3.Width;
  display_height = Screen3.Height;
  DrawScreen(&Screen3);
}