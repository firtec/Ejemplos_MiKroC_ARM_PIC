#include "progress_objects.h"
#include "progress_resources.h"

//--------------------- User code ---------------------//
bit button_status;

void Set_Defaults() {
  button_status = 1;
}
//----------------- End of User code ------------------//

// Event Handlers
void ButtonRound1Click() {
unsigned short i;
  button_status = !button_status;
  if (button_status == 0) {
    strcpy(ButtonRound1_Caption, "Loading...");
    DrawRoundButton(&ButtonRound1);
    for (i=3; i < 101; i++) {
      BoxRound1.Visible = 1;
      BoxRound1.Width = BoxRound1.Width + 2;
      DrawRoundBox(&BoxRound1);
      Label5.Font_Color = CL_BLACK;
      DrawLabel(&Label5);

      ByteToStr(i, Label5.Caption);
      strcat(Label5.Caption, " %");
      Label5.Font_Color = CL_YELLOW;

      DrawLabel(&Label5);
      Delay_ms(30);
    }
    Label5.Font_Color = CL_BLACK;
    DrawLabel(&Label5);
    Label5.Font_Color = CL_YELLOW;
    strcpy(Label5_Caption, "Loaded!");
    DrawLabel(&Label5);
    strcpy(ButtonRound1_Caption, "Reset");
    DrawRoundButton(&ButtonRound1);
  }

  if (button_status == 1) {
    Label5.Font_Color = CL_BLACK;
    DrawLabel(&Label5);
    BoxRound1.Width = 2;
    BoxRound1.Visible = 0;
    DrawBox(&Box1);
    DrawRoundBox(&BoxRound2);
    DrawRoundBox(&BoxRound1);
    strcpy(ButtonRound1_Caption, "Press to continue...");
    DrawRoundButton(&ButtonRound1);
  }
}
