/*****************************************************************************
*  Descripci�n  : Copia de bloques de memoria con DMA2
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
  
volatile unsigned char bandera = 0;
char src[]="Esto es la copia!";
char dst[]="Destino Original ";

void DMA_Config( void )
{
    RCC_AHB1ENR.DMA2EN=1;  // Reloj del DMA2 activado
    DMA2_S0CR.EN = 0;      // Stream 0 des-habilitado
    DMA2_LIFCR.CTCIF0 =1; // Borra la bandera TCIFx flag
    // Configuraciones varias, prioridad, direcci�n, etc
    DMA2_S0CR |= ( 1 << PINC ) | ( 1 << MINC ) | ( 1 << PL0 ) | ( 1 << PL1 ) |
                 ( 1 << DIR1 ) | ( 1 << TCIE );
    NVIC_IntEnable( IVT_INT_DMA2_Stream0 ); // Interrupci�n activa
}

void DMA_Copia_Memoria( void* Destino, void* Origen, unsigned int Bytes )
{
    if( DMA2_S0CR.EN == 1 ){  // Stream 0 des-habilitado??
    DMA2_S0CR.EN = 0; // Stream 0 des-habilitado
    while ( DMA2_S0CR.EN == 1 ); // Confirmar la acci�n
    }
    DMA2_S0PAR = (void*)Origen;   // Direcci�n de la fuente
    DMA2_S0M0AR = (void*)Destino; // Direcci�n des destino
    DMA2_S0NDTR = Bytes;     // N�mero de bytes transferidos
    DMA2_S0CR.EN = 1; // Stream_0 Habilitado
}

void main()
{
    unsigned int len;
    Lcd_Init();                        // Initialize LCD
    Lcd_Cmd(_LCD_CLEAR);               // Clear display
    Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
    Delay_ms( 100 );
    Lcd_Out(1,1,"Copia string con DMA");
    Lcd_Out(2,1,dst);
    DMA_Config();
    DMA_Copia_Memoria( dst, src, len );


    while( 1 )
    {
        if( bandera )
        {
        Lcd_Out(3,1,dst);
            bandera = 0;
        }
    }

}

void transferDone_ISR() iv IVT_INT_DMA2_Stream0 ics ICS_AUTO
{
    DMA2_LIFCR.CTCIF0 =1; // Borra la bandera TCIFx flag
    bandera = 1;
}


//******************* Fin de archivo - FIRTEC ARGENTINA ***********************