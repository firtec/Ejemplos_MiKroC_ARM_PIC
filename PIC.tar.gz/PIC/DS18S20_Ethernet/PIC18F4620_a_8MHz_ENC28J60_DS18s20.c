/*  Program modified for display temperature on mini web server
Accesories used are: MCU PIC18F2620;
                     Temperature sensor DS18s20;
                     ENC28j60;

 RST : RC0 (vert)
 CS  : RC1 (blanc)
 MISO : RC4 (rose)
 MOSI : RC5 (gris)
 SCK  : RC3 (jaune)

 * NOTES:
     - Since the ENC28J60 doesn't support auto-negotiation, full-duplex mode is
       not compatible with most switches/routers.  If a dedicated network is used
       where the duplex of the remote node can be manually configured, you may
       change this configuration.  Otherwise, half duplex should always be used.

Temperature sensor DS18s20
http://www.mikroe.com/products/view/280/ds1820-temperature-sensor/
Branched on port E pin 0
*/

//#include "MikroC.h"

#include "Lib_1Wire_DS18s20.h"

//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------

void Mesure()
{
 Reading_Temperature_DS18s20();
   //Delay_ms(250);
}

char uart_rd;
char  buffer[32];


sbit SPI_Ethernet_Rst at RC0_bit;
sbit SPI_Ethernet_CS at RC1_bit;

sbit SPI_Ethernet_Rst_Direction at TRISC0_bit;
sbit SPI_Ethernet_CS_Direction at TRISC1_bit;

#define SPI_Ethernet_HALFDUPLEX     0
#define SPI_Ethernet_FULLDUPLEX     1

/*
 * definition of user functions called by the ehternet library.
 * these functions are used for tcp and udp handling.
 * we do not need them in this example, but, nevertheless they must be defined,
 * as described in mikroC help.
 *
 */

const unsigned short TEMP_RESOLUTION = 12;
char *text = "000,0";

const unsigned char httpHeader[] = "HTTP/1.1 200 OK\nContent-type: " ;  // HTTP header
const unsigned char httpMimeTypeHTML[] = "text/html\n\n" ;              // HTML MIME type
const unsigned char httpMimeTypeScript[] = "text/plain\n\n" ;           // TEXT MIME type
unsigned char httpMethod[] = "GET /";                                   // supported http method

#define __IP_LOCAL__ "192.168.1.170"
#define __Temp_between_measurements__     "1"
#define __Temp_between_measurements_in_Second__  1
/*
 * web page, splited into 2 parts :
 * when coming short of ROM, fragmented data is handled more efficiently by linker
 *
 * this HTML page calls the boards to get its status, and builds itself with javascript
 */
const   char    *indexPage = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\
<meta http-equiv=\"refresh\" content=\"" __Temp_between_measurements__ ";url=http://" __IP_LOCAL__ "/\">\
<HTML><HEAD>\
<script language=\"javascript\" type=\"text/javascript\">init_Interactivity();</script>\
<title>Firtec Ethernet</title>\
</HEAD><BODY>\
<center>WEB Server para PIC18F4620 con ENC28J60 y DS18S20<p>\
<hr size=2 align=center width=60%>\
<center><a href=/>RECARGAR PAGINA</a></center>\
<script src=/s></script>\
<p><hr size=2>\
<center>TEMPERATURA: <h1><script>document.write(T_)</script>�C</h1></center>\
<p>\
Solicitud HTTP=<script>document.write(REQ)</script>\
<p><hr size=2><br>\
<script language=\"javascript\" type=\"text/javascript\">Interactivity();</script>\
</BODY></HTML>";
/***********************************
 * RAM variables
 */
 
/*
unsigned char   myMacAddr[6] = {0x00, 0x14, 0xA5, 0x76, 0x19, 0x3f} ; // MAC
unsigned char   myIpAddr[4]  = {192, 168,  1, 170};  // Direcci�n IP
unsigned char   gwIpAddr[4]  = {192, 168,  1, 1};    // Direcci�n del Router
unsigned char   ipMask[4]    = {255, 255, 255,  0};  // M�scara de RED
unsigned char   dnsIpAddr[4] = {192, 168,  1, 10};   // Dir. del servidor DNS
*/
 
 
unsigned char   myMacAddr[6] = {0x00, 0x14, 0xA5, 0x76, 0x19, 0x3f};   // my MAC address
unsigned char   gwIpAddr[4]  = {192, 168,  1, 1};    // Direcci�n del Router
unsigned char   myIpAddr[4] = {192, 168, 1, 170};       // my IP address
unsigned char   getRequest[15];// HTTP request buffer
unsigned char   dyna[31];      // Buffer para las respuestas HTTP
unsigned long   httpCounter = 0; // counter of HTTP requests
unsigned long   Sample = 0;
char txt_IP[4];

typedef struct
{
  unsigned canCloseTCP: 1;
  unsigned isBroadcast: 1;
} TEthPktFlags;

#define NB_SAMPLES    10
float temperature[NB_SAMPLES];
float time[NB_SAMPLES];
float x_min = 0.0, x_max = 0.0;
float y_min = 0.0, y_max = 0.0;
float Seconds;

/*******************************************
 * functions
 */

/*
 * put the constant string pointed to by s to the ENC transmit buffer
 */
#define putConstString  SPI_Ethernet_putConstString
/*
unsigned int    putConstString(const char *s)
        {
        unsigned int ctr = 0 ;

        while(*s)
                {
                SPI_Ethernet_putByte(*s++) ;
                ctr++ ;
                }
        return(ctr) ;
        }
*/
/*
 * put the string pointed to by s to the ENC transmit buffer
 */
#define putString  SPI_Ethernet_putString
/*
unsigned int    putString(char *s)
        {
        unsigned int ctr = 0 ;

        while(*s)
                {
                SPI_Ethernet_putByte(*s++) ;
                ctr++ ;
                }
        return(ctr) ;
        }
*/
/*
 * this function is called by the library
 * the user accesses to the HTTP request by successive calls to SPI_Ethernet_getByte()
 * the user puts data in the transmit buffer by successive calls to SPI_Ethernet_putByte()
 * the function must return the length in bytes of the HTTP reply, or 0 if nothing to transmit
 *
 * if you don't need to reply to HTTP requests,
 * just define this function with a return(0) as single statement
 *
 */
unsigned int    SPI_Ethernet_UserTCP(unsigned char *remoteHost, unsigned int remotePort,
                         unsigned int localPort, unsigned int reqLength, char *canClose)
        {
        unsigned int    len = 0 ;                               // my reply length
        unsigned int    i ;                                     // general purpose integer

        if(localPort != 80)                                     // I listen only to web request on port 80
                {
                return(0) ;
                }

        // get 10 first bytes only of the request, the rest does not matter here
        for(i = 0 ; i < 10 ; i++)
                {
                getRequest[i] = SPI_Ethernet_getByte() ;
                }
        getRequest[i] = 0 ;

        if(memcmp(getRequest, httpMethod, 5))                   // only GET method is supported here
                {
                return(0) ;
                }

        httpCounter++ ;                                         // one more request done

        if(getRequest[5] == 's')                                // if request path name starts with s, store dynamic data in transmit buffer
        {
                // the text string replied by this request can be interpreted as javascript statements
                // by browsers

                len = putConstString(httpHeader) ;              // HTTP header
                len += putConstString(httpMimeTypeScript) ;     // with text MIME type

                // add T� value to reply
                len += putConstString("T_=");
                sprintf(dyna,"%2.1f",temperature_DS18s20);
                len += putString(dyna);
                len += putConstString("; ");///100.0;");

                // add HTTP requests counter to reply
                IntToStr(httpCounter, dyna);                   // convert httpCounter value into string
                len += putConstString("var REQ=");
                len += putString(dyna);
                len += putConstString("; ");
         }

        if(len == 0)                                            // what do to by default
                {
                len =  putConstString(httpHeader) ;             // HTTP header
                len += putConstString(httpMimeTypeHTML) ;       // with HTML MIME type
                len += putConstString(indexPage) ;              // HTML page first part
                }

        return(len) ;                                           // return to the library with the number of bytes to transmit
        }

/*
 * this function is called by the library
 * the user accesses to the UDP request by successive calls to SPI_Ethernet_getByte()
 * the user puts data in the transmit buffer by successive calls to SPI_Ethernet_putByte()
 * the function must return the length in bytes of the UDP reply, or 0 if nothing to transmit
 *
 * if you don't need to reply to UDP requests,
 * just define this function with a return(0) as single statement
 *
 */

unsigned int    SPI_Ethernet_UserUDP(unsigned char *remoteHost, unsigned int remotePort,
                         unsigned int localPort, unsigned int reqLength, char *canClose)
{
 return 0 ;                      // back to the library with the length of the UDP reply
}


/*
 * main entry
 */

void main()
{
 unsigned int i;
 CMCON |=7;
 ADCON0= 0;
 ADCON1 = 0x0F ;                 // ADC convertors will be used
 ADCON2 = 0x40;
 PORTB = 0 ;
 TRISB = 0xff ;                  // set PORTB as input for buttons

 PORTA = 0;
 TRISA = 0x01;

 Sample = 0;

 for(i = 0 ; i < NB_SAMPLES ; i++)
 {
  time[i] = 0.0;
  temperature[i] = 0.0;
 }

 Reading_Temperature_DS18s20();
  Delay_ms(1000);                 // Wait Reading temp�rature
  Reading_Temperature_DS18s20();



        SPI1_Init();
        SPI_Ethernet_Init(myMacAddr, myIpAddr, SPI_Ethernet_FULLDUPLEX);



        while(1)
        {
         //--- Perform temperature reading
               // Reading_Temperature_DS18s20();
         Mesure();
         Sample++;



                /*
                 * add your stuff here if needed
                 * SPI_Ethernet_doPacket() must be called as often as possible
                 * otherwise packets could be lost
                 */
                 SPI_Ethernet_doPacket() ;   // process incoming Ethernet packets
         }
        }