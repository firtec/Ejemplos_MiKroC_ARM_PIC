/*****************************************************************************
*  Descripci�n  : Ejemplo de uso para el puerto UART.
*                 Este ejemplo utiliza UART2 -> Delay_us [PA2 TX|PA3 RX] .
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

 char caracter;   // Contenedor para el dato recibido
 //unsigned char x =0;
  //unsigned char rx[16];
 unsigned char array[16] = "";

void main(){
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off


    UART1_Init_Advanced( 9600,
                         _UART_8_BIT_DATA,
                         _UART_NOPARITY,
                         _UART_ONE_STOPBIT,
                         &_GPIO_MODULE_USART1_PA9_10 );


UART2_Init_Advanced(9600, _UART_8_BIT_DATA, _UART_NOPARITY,
                            _UART_ONE_STOPBIT, &_GPIO_MODULE_USART2_PA23);

  //UART2_Init(9600);                  // 9600 Baudios
  Delay_ms(100);
  Lcd_Out(1,5,"Ejemplo UART");      // Carteles iniciales
  //Lcd_Out(2,1,"Dato Recibido:  ");
  Lcd_Out(4,2,"www.firtec.com.ar");
  //UART2_Write_Text("Esperando Datos");
  //UART2_Write(13);
  //UART2_Write(10);

  while(1) {                         // Bucle infinito
      if (UART2_Data_Ready()!= 0){
        UART2_Read_Text(array,"\r\n",8);
        Delay_ms(20);
         UART1_Write(array[0] );
         Delay_ms(1);
         UART1_Write(array[1] );
         Delay_ms(1);
         UART1_Write(array[2] );
         Delay_ms(1);
         UART1_Write(array[3] );
         Delay_ms(1);
         UART1_Write(array[4] );
         Delay_ms(1);
         UART1_Write(array[5] );
         Delay_ms(1);
         UART1_Write(array[6] );
         Delay_ms(1);
         UART1_Write(array[7] );
         Delay_ms(1);
         UART1_Write(array[8] );
        /*Lcd_Chr(2,1,array[0] + 0x30);
        Lcd_Chr(2,2,array[1] + 0x30);
        Lcd_Chr(2,3,array[2] + 0x30);
        Lcd_Chr(2,4,array[3] + 0x30);
        Lcd_Chr(2,5,array[4] + 0x30);
        Lcd_Chr(2,6,array[5] + 0x30);
        Lcd_Chr(2,7,array[6] + 0x30);
         UART2_Write(array[7] + 0x30);*/
    }
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************