/****************************************************************************
**  Descripci�n  : Control de dos led mediante un socket UDP.
**                 Modulo WiFi ESP8266
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 40MHZ - (XTAL 10Mhz con PLLx4)
**  NOTA         : Los LED se conectan en PA0 (pin2) y PA1 (pin3).
*****************************************************************************/
// Pines asignados al LCD
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

 volatile unsigned char Data= '0', bandera =0;
 char txt[15];


/******************************************************************************
* Servicio de Interrupci�n del receptor UART.
******************************************************************************/
void ISR_UART() iv 0x0008 ics ICS_AUTO {
  if (PIR1.RCIF) {         // test the interrupt for uart rx
    Data = Uart1_Read() & 0xFF;   // Lee dato recibido

    if(Data == '4')
     {
        PORTA.B1 = 0;
        PORTA.B0 = 1;
       bandera = 1;
      }    
      if(Data == '5') 
      {
        PORTA.B1 = 1;
        PORTA.B0 = 0;
        bandera = 2;
      }
    PIR1.RCIF=0;           // Borra bandera de interrupci�n
    }
  }

/******************************************************************************
* Funci�n para el env�o de cadenas por el puerto UART.
******************************************************************************/
void Enviar_String(const char *s)
{
  while(*s)
  {
    UART1_Write(*s++);
  }
}
/****************************************************************
* Configuraci�n b�sica para crear un cliente UDP sobre una IP y
* puerto determinado.
* IMPORTANTE_1: los pines 25 se conecta a RX del ESP8266 y el
* pin 26 al TX .
*
* IMPORTANTE_2:
* Se supone que los datos de conexi�nes WiFi (SSI y PASS) ya
* fueron cargados antes ya que estos datos no se pierden si el
* modulo se apaga o resetea, pero si la configuraci�n del socket.
* Esta configuraci�n dispone el modo wifi para que todo lo enviado
* por la USART pase directamente al socket.
* (Transparent Transmission Mode)
*
*****************************************************************/
void Configurar_ESP8266(void){
        Enviar_String("AT+RST\r\n");  // Reset general del m�dulo.
        Delay_ms(2000);
        Enviar_String("AT\r\n");        // Comando de control
        Delay_ms(500);
        Enviar_String("AT+CIPSTART=");  // Configura el Socket UDP
        Enviar_String("\"");
        Enviar_String("UDP");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("\"");
        Enviar_String("192.168.1.13");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("30000\r\n");
        Delay_ms(500);
        Enviar_String("AT+CIPMODE=1\r\n"); // Activa el modo " TX transparente"
        Delay_ms(500);
        Enviar_String("AT+CIPSEND\r\n");  // Confirmo el modo
}

/**********************************************************
*   Esta funci�n ajusta los valores por defecto de la
*   pantalla LCD y coloca los carteles iniciales.
**********************************************************/
void Display_Init(){
  LCD_Init();
  LCD_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  Lcd_Out(1,1,"Socket & MiKroC");
}
/**********************************************************
*  Esta es la funci�n principal del programa.
*  Configura pines, comparadores, canales anal�gicos y se
*  llama al resto de las funciones.
**********************************************************/
void main() {
  char k = 0, t;
  CMCON |=7;
  ADCON1 = 0x0f;
  TRISA0_bit  = 0;
  TRISA1_bit  = 0;
  PORTA = 0;
  Display_Init();
  UART1_Init(9600);
  Delay_ms(200);
  INTCON.GIE = 1;
  INTCON.PEIE = 1;
  PIE1.RCIE = 1;
  Configurar_ESP8266();
  Lcd_Out(2,1,"LED:?");

  while (1) {
     UART1_Write(0);
     if (bandera == 2)
         Lcd_Out(2,5,"Naranja");
      if (bandera == 1)
         Lcd_Out(2,5,"Rojo    ");
    Delay_ms(200);
  }
}