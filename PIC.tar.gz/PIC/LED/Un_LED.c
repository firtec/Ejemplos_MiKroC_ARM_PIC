

#define led_si PORTB=0x01
#define led_no PORTB=0x00
void main() {
     TRISB=0;   //Todo el puerto B como salida
   while(1){
     led_no;
      delay_ms(50);
      led_si;
      delay_ms(50);
    }
}