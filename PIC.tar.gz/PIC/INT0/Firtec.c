

void interrupt(){          // Interrupt routine
  if(INT0F_bit == 1 ) {  // Checks Receive Interrupt Flag bit
    PORTC.B2 = ~PORTC.B2;
    INT0F_bit = 0;        // Clear Interrupt Flag
  }
}

void main() {
  TRISB0_bit  = 1;     // Set PORT B (only RB0) as input
  TRISC  = 0;           // Set PORT D as output
  PORTC.B2 = 0;
  
  INTEDG0_bit = 1;    // Set interrupt on rising edge
  INT0IF_bit  = 0;     // Clear INT0 flag
  INT0IE_bit  = 1;     // Enable INT0 interrupts
  GIE_bit     = 1;      // Enable GLOBAL interrupts

  while(1) {
      // Espera la interrupci�n
  }
}
