/*
 V  a comparar por pin 2
 V referencia por pin 5
 El estado de C1OUT se muestra en el display mostrando L o H.
*/
const unsigned char Digito[2] ={0x76,0x38};
void main(void){
  TRISB=0X00;
 TRISA.TRISA3=1;
 TRISA.TRISA0=1;
 TRISA.TRISA4=0;
 CMCON = 0b00000010;
  while(1){
    if(CMCON.C1OUT){
    PORTB=Digito[0];
   }
  else {
    PORTB=Digito[1];
   }
  }
}