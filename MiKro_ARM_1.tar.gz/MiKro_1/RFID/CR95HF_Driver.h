#ifndef _CR95HF_Driver_H
#define _CR95HF_Driver_H

#define    ECHO                   0x55
#define    IDN                    0x01
#define    ProtocolSelect         0x02
#define    WrReg                  0x09
#define    SendRecv               0x04

char EchoResponse(void);
void Leer_Comando(void);
void Escribe_Comando(unsigned short, unsigned short);
void Calibrar_CR95HF(void);
void Leer_CR95HF_ID(void);
void RF_Config(void);
void Protocolo_14443_A(void);
void Protocolo_18092(void);
void AutoFDet(void);
void Buscar_TagID(void);
void Buscar_NFCTag(void);

#endif
