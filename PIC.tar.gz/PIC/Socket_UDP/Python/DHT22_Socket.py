# -*- coding: utf-8 -*-
#!/usr/bin/env python
import socket
import sys
import errno
import time

from Tkinter import *
from tkMessageBox import showinfo

bandera = 0

class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)

#********** Función para conocer el IP del servidor **************************
def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 0))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP
#*****************************************************************************
#UDP_IP_Cliente ="192.168.1.10"     # ip del socket
UDP_PORT = 30000    # Puerto del socket en el Servidor
Dir_IP = get_ip()   # Obtiene la dirección del Servidor
time.sleep(0.02)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # Crea Socket UDP
sock.bind(("", UDP_PORT)) # Recibir de cualquier cliente
sock.setblocking(0)   # Socket NO Bloqueante

ventana = Tk()    # Crea la ventana
ventana.title('Sensor DHT22')  # Nombre de la ventana
ventana.config(bg="NavajoWhite2")     # Color de fondo
ventana.geometry("400x200")    # Tamaño de la ventana
ventana.resizable(0,0) # Evita que se pueda cambiar de tamaño la ventana


cuadro = Canvas(width=200, height= 200)
cuadro.pack(expand=NO, fill=BOTH)
#cuadro.place(x=102, y=200)
cuadro.config(bg="NavajoWhite2")
#cuadro.config(fg="black")
cuadro.create_rectangle(330, 160,85 , 75)


x = 0    # Variable del sistema
y = 0    # Variable del sistema

#************************ FUNCIÓN RECURSIVA **********************************
def update_label():
    try:
        data,addr = sock.recvfrom(50)
    except socket.error, e:
        err = e.args[0]
        if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
            time.sleep(0.01)
            #print 'No hay datos!!'
            ventana.after(2, update_label)
    else:
        #sock.sendto('0', addr)    # Envía dato Led control
        label_dato.config(text = data)    # Muestra el dato recibido
        #label_cliente.config(text = addr) # Muestra info del cliente
        ventana.after(2, update_label)


#********* Label´s que despliegan la iformación y rótulos del script *********

label_firtec = Label(ventana, text="www.firtec.com.ar", bg="NavajoWhite2", fg="black", font=("bold", 10))
label_firtec.place(x=282, y=173)
label_rotulo_IP = Label(ventana, text="Configuración del Servidor.", bg="NavajoWhite2", fg="black", font=("Helvetica", 12))
label_rotulo_IP.place(x=10, y=5)
label_Nombre_IP = Label(ventana, text="IP:", bg="NavajoWhite2", fg="blue", font=("Helvetica", 14))
label_Nombre_IP.place(x=30, y=30)

label_IP = Label(ventana, bg="NavajoWhite2", fg="blue", font=("Helvetica", 14))
label_IP.config(text = Dir_IP)
label_IP.place(x=58, y=30)

label_Nombre_Puerto = Label(ventana, text="Puerto:", bg="NavajoWhite2", fg="black", font=("Helvetica", 10))
label_Nombre_Puerto.place(x=180, y=35)

label_Puerto = Label(ventana, bg="NavajoWhite2", fg="black", font=("Helvetica", 10))
label_Puerto.config(text = UDP_PORT)
label_Puerto.place(x=225, y=35)

label_dato = Label(ventana, text="", bg="NavajoWhite2", fg="red", font=("Helvetica", 28))
label_dato.place(x=100, y=80)

label_temperatura = Label(ventana, text="Temperatura", bg="NavajoWhite2", fg="black", font=("Helvetica", 10))
label_temperatura.place(x=100, y=125)
label_humedad = Label(ventana, text="Humedad", bg="NavajoWhite2", fg="black", font=("Helvetica", 10))
label_humedad.place(x=228, y=125)

#Rotulo_cliente = Label(ventana, text="IP del Cliente y Puerto", bg="beige", fg="black", font=("Helvetica", 8))
#Rotulo_cliente.place(x=250, y=175)

#boton_0 =tton(ventana, text=' LED Naranja ', command=naranja)  # Boton del LED
#boton_0.pack()
#boton_0.place(x=130, y=150)    # Coordenasa del Boton

#boton_1 = Button(ventana, text='     LED Azul     ', command=azul)  # Boton del LED
#boton_1.pack()
#boton_1.place(x=32, y=150)    # Coordenasa del Boton




update_label()
ventana.mainloop( )
