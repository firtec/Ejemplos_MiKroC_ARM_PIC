/*****************************************************************************
*  Descripci�n  : Ejemplo de uso para mostrar datos enteros y datos
*                 del tipo float en una pantalla LCD .
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/

 void LcdFloat(unsigned char,unsigned char, float, unsigned char);
 
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

unsigned int numero = 2048;
  char texto[20] = "";

void main() {

    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    Lcd_Out(2, 1, "Float:" );              // Muestra cartel
    LcdFloat(2,7,((numero * 3.3)/4096),2); // Convierte y muestra dato float
    sprinti(texto,"Entero:%d",numero);     // Muestra dato entero
    Lcd_Out(1, 1, texto );
  while(1) {}
}

/******************************************************************************
*  Funci�n para convertir dato float en ASCII y mostrarlo en una coordenada
*  X - y determinada del LCD.
******************************************************************************/
void LcdFloat(unsigned char x,unsigned char y, float num, unsigned char dec){
unsigned char fila = 0;
unsigned char a = 0;
unsigned char nent = 0;
unsigned long ent = num;
float decimales = num;
float resultado = 0;
unsigned long rdec = 0;
unsigned char texto[10];
 
 fila = x;
 for(a=0;ent>0;a++){
   ent /= 10;
   nent++;
 }
 if(nent==0) nent=1;
 ent=num;
 resultado = decimales-ent;
 
 for(a=1;a<=dec;a++)
   resultado*=10;
 for(a=0;a<nent;a++){
   texto[a]=ent%10;
   ent/=10;
 }
 for(a=nent;a>0;a--)
   Lcd_Chr(fila,y++,texto[a-1]+48);
 Lcd_Chr_cp('.');
 y++;
 rdec=resultado;
 for(a=0;a<dec;a++){
   texto[a]=rdec%10;
   rdec/=10;
 }
 for(a=dec;a>0;a--)
 Lcd_Chr(fila,y++,texto[a-1]+48);
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************