/****************************************************************************
**  Descripci�n  : Lectura de dos canales anal�gicos (PIN2 y PIN3).
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 20MHZ
****************************************************************************/
 #include "Str_lcd.h" // Archivo con declaraci�nes

void Coversor() iv 0x008 ics ICS_AUTO {
 if (PIR1.ADIF) {
    PORTC.B2 = ~PORTC.B2;
    switch(canal){
       case 0:{
            M0 += ADC_Get_Sample(canal);
            muestras_0++;
                         if(muestras_0 == 5){
                             conv_0 = M0/5;
                             muestras_0 =0;
                             M0=0;
                             canal++;
                         }
        break;
      }

   case 1:{
        M1 += ADC_Get_Sample(canal);
        muestras_1++;
                if(muestras_1 == 5){
                     conv_1 = M1/5;
                     muestras_1 =0;
                     M1=0;
                     canal = 0;
               }
          break;
      }
   }
   
   PIR1.ADIF=0; // Borra bandera del conversor.
  }
}

void main() {
  TRISA = 0x03;          // RA0 y RA1 son entradas
  TRISC2_bit  = 0;       // Bit 2 del puerto C es salida
  PORTC.B2 = 0;          // LED inicia apagado
  ADCON1 = 0x0D;         // Dos canales anal�gicos AN0 y AN1
  ADCON2 = 0b10010100;   // Configura el reloj del conversor

  GIE_bit = 1;           // Habilitador global de interrupciones
  PEIE_bit = 1;          // Habilita interrupciones de perif�ricos
  PIE1.ADIE = 1;         // Interrupci�n del conversor activada
  Delay_us(20);          // Espera 20 microsegundos
  ADON_bit = 1;          // Conversor activado
  //ADC_Init();            // Configura el conversor

  Lcd_Init();                      // Configura el LCD
  Delay_ms(10);                    // Espera 10 milisegundos
  Lcd_Cmd(_LCD_CLEAR);             // Limpia la pantalla
  Lcd_Cmd(_LCD_CURSOR_OFF);        // Apaga el cursor
  Lcd_Out(1, 4, "VOLTIMETRO");     // Carteles iniciales en el LCD
  Lcd_Out(2,1, "A0: ");
  Lcd_Out(2,10, "A1: ");

   while(1){
    GO_DONE_bit =1;
       LcdFloat(2,4,((conv_0 * 5.0)/1024),2);   // Muestra el canal 0
       LcdFloat(2,13,((conv_1 * 5.0)/1024),2);  // Muestra el canal 1
   }
}