/****************************************************************************
**  Descripci�n  :  Manejo de un term�metro infrarrojo MLX90614
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 40MHZ - (XTAL 10Mhz con PLLx4)
**  NOTA         :
*****************************************************************************/
// Pines asignados al LCD
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

// Ir Termo click constants
const _IR_THERMO_ADDR = 0x5A;
const _AMB_TEMP      = 0x06;
const _OBJ_TEMP      = 0x07;

// Globals
float Temp;

/*****************************************************************************
* Funci�n para leer el sensor por I2C.
* Vectores de Lectura  0x06 Para temperatura ambiente
*                      0x07 Para la temperatura del objeto
* Retorna el valor de temperatura en grados Kelvin.
*****************************************************************************/
float Leer_Sensor(char Temp_Source){
  unsigned int Temp_var;

  I2C1_Start();                  // issue I2C start signal
  I2C1_Wr(_IR_THERMO_ADDR << 1); // send byte via I2C  (device address << 1)
  I2C1_Wr(Temp_Source);          // send byte (data address)
  I2C1_Repeated_Start();         // issue I2C signal repeated start
  I2C1_Wr(_IR_THERMO_ADDR << 1); // send byte (device address << 1)
  Temp_var = I2C1_Rd(0);         // Read the data (NO acknowledge)
  Temp_var = (I2C1_Rd(0) << 8) + Temp_var;
  I2C1_Stop();                   // issue I2C stop signal

  return Temp_var;
}
/*****************************************************************************
* Muestra los valores de temperatura tanto del objeto como el ambiente.
*****************************************************************************/
void Mostrar_Temperatura(char Temp_Source, float temperatura){
  char text[15];
  sprintf(text,"%2.1f", temperatura);

  if (Temp_Source == _AMB_TEMP)
    Lcd_Out(2, 2, text);
    Lcd_Chr(2,6,223);
    Lcd_Chr(2,7,0x43);
  if (Temp_Source == _OBJ_TEMP)
    Lcd_Out(2, 10, text);
    Lcd_Chr(2,14,223);
    Lcd_Chr(2,15,0x43);
}

void main() {
  CMCON |=7;
  ADCON1 = 0x0f;
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  Lcd_Out(1,1,"Sensor PIR");

  I2C1_Init(100000);             // Configura el puerto I2C
  Lcd_Out(2,1,"Iniciando......");
  Delay_ms(2000);

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1,1,"Ambiente ");
  Lcd_Out(1,9," Objeto");

  while (1){
    Temp = Leer_Sensor(_AMB_TEMP);         // Lee Temp. ambiente
    Temp = (Temp * 0.02) - 273.15;         // Convierte a grados Celsius
    Mostrar_Temperatura(_AMB_TEMP, Temp);  // Muestra los datos
    Temp = Leer_Sensor(_OBJ_TEMP);         // Lee la temperatura del objeto
    Temp = (Temp * 0.02) - 273.15;        //  Convierte a Celsius

    Mostrar_Temperatura(_OBJ_TEMP, Temp);  // Muestra los valores

    Delay_ms(500);                         // Espera
  }
}