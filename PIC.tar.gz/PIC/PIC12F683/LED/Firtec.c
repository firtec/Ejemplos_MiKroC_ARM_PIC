/****************************************************************************
**  Descripci�n  : Control de un bit en el puerto del PIC.
**  Target       : 8 PIN PIC12F683
**  Compiler     : MikroC para PIC v 7.1
**  OSCILADOR    : 8MHZ (Interno)
**  www.firtec.com.ar
*****************************************************************************/
sbit led at GP2_bit;  // Declara el bit a usar
void main() {
    TRISIO.B2 = 0; // Configura el sentido de transferencia del pin
    OSCCON = 0b01110101; // Oscilador interno en 8MHz
    ADCON0 = 0;          // Canales anal�gicos OFF
    ANSEL = 0;           // Todos los pines son digitales
    CMCON0 = 7;          // Comparadores OFF

    while (1){
       //led = 1;
       led = !led;
       Delay_ms(500);
       //led = 0;
       //Delay_ms(500);
    }
}