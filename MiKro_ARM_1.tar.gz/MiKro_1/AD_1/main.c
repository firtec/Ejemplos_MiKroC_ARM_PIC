/*****************************************************************************
*  Descripci�n  : Lectura de dos canales anal�gicos  (ADC1 pines PA5 y PA6)
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

 void LcdFloat(unsigned char,unsigned char, float, unsigned char);
 void Leer_Conversor(void);
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
  
  unsigned int M0=0, conversion =0;
  unsigned char muestras = 0;
  unsigned char canal = 5;
  //unsigned int dato_conv = 0;
  char texto[20] = "";
  
void main() {
    //RCC_APB1ENR.PWREN=1;   // Modo alta perfomance
    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    ADC_Set_Input_Channel(_ADC_CHANNEL_5|_ADC_CHANNEL_6);
    //set_ADC1_regular_number_of_conversions(1);
    //ADC_Set_Input_Channel(_ADC_CHANNEL_6);
    ADC1_Init();
    Lcd_Out(1, 1, "Conversor Analogico" );
    Lcd_Out(2, 1, "Voltios AD5:" );
    Lcd_Out(3, 1, "Voltios AD6:" );

  while(1) {
   Leer_Conversor();
  }
}
/******************************************************************************
*  Funci�n para la lectura de los dos canales anal�gicos.
*  Se toman 16 lecturas en cada pin y se promedian para obtener una medici�n
*  estable dispersando el error en la cantidad de muestras.
******************************************************************************/
 void Leer_Conversor(){
    do{
    M0 += ADC1_Get_Sample(canal);
    muestras++;
    }while(muestras <= 15);
 conversion = M0/16;
 if(canal == 5)
    LcdFloat(2,13,((conversion *3.3)/4096),2);
 if(canal == 6)
    LcdFloat(3,13,((conversion *3.3)/4096),2);
  M0 = 0;
 muestras =0;
 canal++;
 if(canal == 7)
    canal =0;
 }
 
/******************************************************************************
*  Funci�n para convertir dato float en ASCII y mostrarlo en una coordenada
*  X - y determinada del LCD.
******************************************************************************/
void LcdFloat(unsigned char x,unsigned char y, float num, unsigned char dec){
unsigned char fila = 0;
unsigned char a = 0;
unsigned char nent = 0;
unsigned long ent = num;
float decimales = num;
float resultado = 0;
unsigned long rdec = 0;
unsigned char texto[10];
 
 fila = x;
 for(a=0;ent>0;a++){
   ent /= 10;
   nent++;
 }
 if(nent==0) nent=1;
 ent=num;
 resultado = decimales-ent;
 
 for(a=1;a<=dec;a++)
   resultado*=10;
 for(a=0;a<nent;a++){
   texto[a]=ent%10;
   ent/=10;
 }
 for(a=nent;a>0;a--)
   Lcd_Chr(fila,y++,texto[a-1]+48);
 Lcd_Chr_cp('.');
 y++;
 rdec=resultado;
 for(a=0;a<dec;a++){
   texto[a]=rdec%10;
   rdec/=10;
 }
 for(a=dec;a>0;a--)
 Lcd_Chr(fila,y++,texto[a-1]+48);
 
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************