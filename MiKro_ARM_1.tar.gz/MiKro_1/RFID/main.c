/*****************************************************************************
*  Descripci�n  : Ejemplo para el protocolo SPI manejando un modulo RFID click
*                 fabricado por MiKroElectroniKa con el chip CR95HF .
*                 Este ejemplo utiliza SPI2 en pines PB13 PB14 PB15.
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/
#include "CR95HF_Driver.h"

 // Conexi�nes de los pines para el LCD ST7066 20x4.
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
// Conexi�nes de los pines de control para RFID Click
    sbit SSI_0 at GPIOE_ODR.B10;
    sbit SSI_1 at GPIOC_ODR.B1;
    sbit IRQ_IN at GPIOA_ODR.B1;
// Variables exportadas desde el Driver.
    extern unsigned short sdata[18];
    extern unsigned short rdata[18];
    extern unsigned short j, tmp;
    extern char CR95HF_ID[13];
    extern char ID[38];
    char ID_old[38];
    extern char bandera;
    extern unsigned char NFC_bandera;
    extern unsigned char TAG_bandera;
    
    extern sbit CS;

/*************************************************************
* Esta funci�n configura el puerto SPI2 y los pines usados
* en el proyecto.
**************************************************************/
void Config_Inicio(){
  // Configura los pines usados en el proyecto
  GPIO_Digital_Output(&GPIOE_ODR, _GPIO_PINMASK_10);
  GPIO_Digital_Output(&GPIOC_ODR, _GPIO_PINMASK_1);
  GPIO_Digital_Output(&GPIOA_ODR, _GPIO_PINMASK_1);
  GPIO_Digital_Output(&GPIOB_ODR, _GPIO_PINMASK_12);
 // Niveles l�gicos obligatorios para estos dos pines
  SSI_0 = 1;
  SSI_1 = 0;
  Delay_ms(1000);
 // Secuencia necesaria para iniciar el chip CR95HF
  IRQ_IN = 1;
  Delay_ms(1);
  IRQ_IN = 0;
  Delay_ms(1);
  IRQ_IN = 1;
  Delay_ms(5);
  // Configura el puerto SPI2
  SPI2_Init_Advanced(_SPI_FPCLK_DIV256, _SPI_MASTER
                      | _SPI_8_BIT | _SPI_CLK_IDLE_LOW 
                      | _SPI_FIRST_CLK_EDGE_TRANSITION 
                      | _SPI_MSB_FIRST | _SPI_SS_DISABLE 
                      | _SPI_SSM_ENABLE 
                      | _SPI_SSI_1, &_GPIO_MODULE_SPI2_PB13_14_15);
  Delay_ms(100);
 }

// ========================= PROGRAMA PRINCIPAL ==============================
void main(){
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  Delay_ms(500);
  Lcd_Out(1,3,"Protocolo RFID");      // Carteles iniciales
  Lcd_Out(4,2,"www.firtec.com.ar");
  Config_Inicio();

 while (!EchoResponse()) {   // Hay al menos un CR95HF?
   Lcd_Out(2,1,"Buscando RFID");
   //IRQ_IN = 1;
    delay_ms(1);
   // IRQ_IN = 0;
    //delay_ms(100);
  }
  Lcd_Out(2,1,"RF_ID:         ");
  Leer_CR95HF_ID();
  Lcd_Out(2,7,CR95HF_ID);
  //Lcd_Out(3,1,"Espere...");
  Calibrar_CR95HF();
  Lcd_Out(3,1,"TAG_ID:  ");
  RF_Config();
  AutoFDet();
  Protocolo_14443_A();
  ID[0]= '?';
  ID[1]= '?';

while(1){
if (!TAG_bandera)
      Buscar_NFCTag();  // Obtienes el NFC_ID

    if (!NFC_bandera)
      Buscar_TagID();  // Obtiene el Tag_ID

    if (ID[0] == 0){  // Si no hay TAG incrementa la bandera
      bandera++;
    }
    else {         // Si hay TAG borra la bandera
      bandera = 0;
      if (strcmp(ID_old, ID)){  // Compara los ID
      Lcd_Out(3,8,"             ");
        Lcd_Out(3,8,ID);
        strcpy(ID_old, ID);    // Actualiza con el nuevo ID
        Delay_ms(500);
      }
    }
    if(bandera > 5){
      ID_old[0]= 0;
      bandera = 0;
    }
    ID[0]= 0;
    for(j=0; j<18; j++){  // Limpia los buffer
      rdata[j] = 0;
      sdata[j] = 0;
    }
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************