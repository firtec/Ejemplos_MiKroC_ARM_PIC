sbit GLCD_RS  at LATB2_bit;
sbit GLCD_RW  at LATB3_bit;
sbit GLCD_EN  at LATB4_bit;
sbit GLCD_RST at LATB5_bit;
sbit GLCD_CS1 at LATB1_bit;
sbit GLCD_CS2 at LATB0_bit;

sbit GLCD_RS_Direction  at TRISB2_bit;
sbit GLCD_RW_Direction  at TRISB3_bit;
sbit GLCD_EN_Direction  at TRISB4_bit;
sbit GLCD_RST_Direction at TRISB5_bit;
sbit GLCD_CS1_Direction at TRISB1_bit;
sbit GLCD_CS2_Direction at TRISB0_bit;

char GLCD_DataPort at PORTD;

const unsigned short Arial20x33[];
//const unsigned short Verdana37x38[];
char text[6];
unsigned int adc_value;

void main() {
   ADCON1 = 0x07;
   TRISA  = 0xFF;

   Glcd_Init();
   Glcd_Fill(0);

   while(1) {
      adc_value = (ADC_Read(0) * 5000ul) >> 10;
      WordToStr(adc_value, text);
      
      // Draw text
      Glcd_Set_Font_Adv(&Arial20x33, 1, _GLCD_HORIZONTAL);
     //Glcd_Set_Font_Adv(&Verdana37x38, 1, _GLCD_HORIZONTAL);
      Glcd_Write_Text_Adv(text, 16, 20);
      
      //Delay_ms(10);
      
      // Erase text
      Glcd_Set_Font_Adv(&Arial20x33, 0, _GLCD_HORIZONTAL);
      //Glcd_Set_Font_Adv(&Verdana37x38, 1, _GLCD_HORIZONTAL);
      Glcd_Write_Text_Adv(text, 16, 20);
   }
}