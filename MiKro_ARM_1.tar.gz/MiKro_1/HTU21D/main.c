/*****************************************************************************
*  Descripci�n  : Ejemplo para el protocolo I2C. Manejo de un sensor HTU21D
*                 Este ejemplo utiliza I2C3 en pines PB8 y PB9.
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/
 void LcdFloat(unsigned char,unsigned char, float, unsigned char);
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
    
 #define HTU21D_ADDR                 (0x40)
 #define dato_temp                   (0x01)
 #define dato_hum                    (0x02)
 
void Sensor_Reset(){
char reg_command[1];
  reg_command[0] = 0xFE;
  I2C1_Start();
  I2C1_Write(HTU21D_ADDR,reg_command, 1, END_MODE_STOP);
  Delay_ms(15);
}
/******************************************************************************
*  Funci�n leer el sensor HTU21D.
*  Retorna el valor de la temperatura o la humedad.
******************************************************************************/
float Leer_sensor(unsigned char ajuste){
unsigned dato = 0;
char reg_dato[3];
float resultado;
  if(ajuste == dato_temp)
            reg_dato[0] = 0xE3;           // Lee valor de temperatura
  if(ajuste == dato_hum)
            reg_dato[0] = 0xE5;           // Lee valor de humedad
  I2C1_Start();
  I2C1_Write(HTU21D_ADDR, reg_dato, 1, END_MODE_RESTART);
  I2C1_Read (HTU21D_ADDR, reg_dato, 3, END_MODE_STOP);
  dato = ((unsigned short)reg_dato[0] << 8) | reg_dato[1] ;
  dato = dato & 0xFFFC;               // Limpia bit de status
  if(ajuste == dato_temp){            // Ajusta lectura de temperatura
  resultado = -46.85 + 175.72 * dato / 65536.0;
  return resultado;
  }
  if(ajuste == dato_hum){            // Ajusta lectura de humedad
  resultado = -6.0 + 125.0 * dato / 65536.0;
  return resultado;
  }
}
// =========================== PROGRAMA PRINCIPAL ==============================
void main(){
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  //I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  //I2C3_Init_Advanced(100000, &_GPIO_MODULE_I2C3_PA8_PC9);
  Delay_ms(500);
  Lcd_Out(1,4,"Sensor HTU21D");      // Carteles iniciales
  Lcd_Out(2,1,"Temperatura:  ");
  Lcd_Out(3,1,"Humedad:?? ");
  Lcd_Out(4,2,"www.firtec.com.ar");
  Sensor_Reset();
  while(1) {
           LcdFloat(2,13,Leer_Sensor(dato_temp),1);
           LcdFloat(3,9,Leer_Sensor(dato_hum),1);
           Delay_ms(100);
  }
}
/******************************************************************************
*  Funci�n para convertir dato float en ASCII y mostrarlo en una coordenada
*  X - y determinada del LCD.
******************************************************************************/
void LcdFloat(unsigned char x,unsigned char y, float num, unsigned char dec){
unsigned char fila = 0;
unsigned char a = 0;
unsigned char nent = 0;
unsigned long ent = num;
float decimales = num;
float resultado = 0;
unsigned long rdec = 0;
unsigned char texto[10];

 fila = x;
 for(a=0;ent>0;a++){
   ent /= 10;
   nent++;
 }
 if(nent==0) nent=1;
 ent=num;
 resultado = decimales-ent;

 for(a=1;a<=dec;a++)
   resultado*=10;
 for(a=0;a<nent;a++){
   texto[a]=ent%10;
   ent/=10;
 }
 for(a=nent;a>0;a--)
   Lcd_Chr(fila,y++,texto[a-1]+48);
 Lcd_Chr_cp('.');
 y++;
 rdec=resultado;
 for(a=0;a<dec;a++){
   texto[a]=rdec%10;
   rdec/=10;
 }
 for(a=dec;a>0;a--)
 Lcd_Chr(fila,y++,texto[a-1]+48);

}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************