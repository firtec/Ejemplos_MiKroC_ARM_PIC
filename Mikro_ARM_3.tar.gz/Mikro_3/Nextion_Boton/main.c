/*****************************************************************************
*  Descripci�n  : Recibiendo el estado de un bot�n en una pantalla Nextion.
*                 UART2 [PA2 TX a cable amarillo|PA3 RX a cable az�l].
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
#define led   GPIOD_ODR.B15
volatile unsigned char kbhit = 0;
volatile  unsigned char array[16] = "";
unsigned char bandera = 0;
unsigned char error, pagina, componente, eventopres, dato1, dato2, dato3;

 //0x65 0x00 0x01 0x00 0xFF 0xFF 0xFF Trama Nextion
 //0X65+Page ID+Component ID+TouchEvent+End
 void usart_RX() iv IVT_INT_USART2 ics ICS_AUTO
{
      if (UART2_Data_Ready()!= 0){
        UART2_Read_Text(array,"\r\n",8);
        kbhit =1;
   }

 }

void main(){
GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);
led = 0;
UART2_Init_Advanced(9600, _UART_8_BIT_DATA, _UART_NOPARITY,
                            _UART_ONE_STOPBIT, &_GPIO_MODULE_USART2_PA23);

  EnableInterrupts();
  UE_USART2_CR1_bit = 1;
  RE_USART2_CR1_bit = 1;
  RXNEIE_USART2_CR1_bit = 1;
  TXEIE_USART2_CR1_bit = 0;
  NVIC_IntEnable(IVT_INT_USART2);
  
  while(1) {
  if(kbhit ==1){
   // error = array[0];     // nombre del primer nibble del arreglo
    pagina = array[1];    //nombre de segundo nibble del arreglo
    componente = array[2];//nombre de tercer nibble del arreglo
   // eventopres = array[3];//nombre de cuarto nibble del arreglo
  //  dato1 = array[4];     //nombre de primer quinto nibble del arreglo
  //  dato2 = array[5];     //nombre de primer sexto nibble del arreglo
  //  dato3 = array[6];     //nombre de primer septimo nibble del  arreglo
    kbhit =0;
    //i = 0;

    if (pagina == 0 && componente == 1 && bandera == 0) {   // si tenemos un evento de la pagina 0 y el componente 1(el unico boton de esa pagina) y no ah sido activada la bandera
      led = 1;                    // enciende el led
      bandera = 1;                 // suma 1  a la bandera
      componente = 0;              // has 0 la variable componente
    }
   if (pagina == 0 && componente == 1 && bandera == 1) {   // si vuelves apresionar el boton en nextion y la bandera tiene un 1
      led = 0;                   // apaga el led
      bandera = 0;                           // has 0 la bandera
      }
     }
    }
  }