/****************************************************************************
**  Descripci�n  : Crea un directorio en la memoria SD, luego dos archivos
**                 y escribe un texto simple en cada archivo, finalmente
**                 cierra los archivos.
**                 La secuencia de funcionamiento es reportada mediante
**                 el puerto UART a 9600 baudios 8b S/P.
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 20MHZ
**  Verificado con memorias de 1Gb, 4Gb y 8Gb
*****************************************************************************/
#define CR 0x0D // carrige return
#define LF 0x0A // line feed
typedef unsigned short      uint8;
typedef   signed short      int8;
////////////////////////////////////////////////////////////////////////////////
//
//  modes of file operation:
//      - read   ( resets cursor to 0 )
//      - write  ( resets cursor to 0 )
//      - append ( leaves cursor as is )
//
////////////////////////////////////////////////////////////////////////////////
static const uint8
    FILE_READ       = 0x01,
    FILE_WRITE      = 0x02,
    FILE_APPEND     = 0x04;


// Mmc Library requirements
sbit Mmc_Chip_Select           at RC2_bit;
sbit Mmc_Chip_Select_Direction at TRISC2_bit;

// SPI initialization routines required by Mmc Library
void initSPI(void)
{
    //setup_spi(SPI_MASTER|SPI_L_TO_H|SPI_CLK_DIV_64);
    SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV64, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_LOW_2_HIGH);
}
void initFastSPI(void)
{
    //SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV4, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_LOW_2_HIGH);
    SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV4, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_LOW_2_HIGH);
}


int8   err;
//signed short err;
short fhandle[4];   // file handle variable should be signed (4 = max files can be open at the same time

void main() {
 ADCON1 = 0x0D;  // Pines digitales
 //ANSELC = 0;             // Configure AN pins as digital
 //SLRCON = 0;             // Set output slew rate on all ports at standard rate

 //  UART module initialization
  UART1_Init(9600);
  Delay_ms(100);

  //UART_Write(CR);
  //UART_Write_ConstText(line);
  UART_Write(CR);
  Delay_ms(100);

  //  SPI module initialization
    ///////////////////////////////////////
    initSPI();

  //  initialize storage device.
  //  optionally, we could format the device
  //  instead of just initializing it.
  ///////////////////////////////////////

  //Initialize
    err = FAT32_Init();
    // err = FAT32_format("dev0");
    if (err < 0)        //
    {
        UART_Write(CR);
       // UART_Write_Text(constToVar(uartbuf, "init failed"));
       UART_Write_Text("***** ERROR de Inicio *****");
        UART_Write(CR);  // carrige return
        UART_Write(LF);  // line feed

        while(err < 0)  //  ...retry each second
        {
            err = FAT32_Init();
            Delay_ms(1000);
        }
    }

   //  if all went well, reinitialize
    //  SPI with greater speed
    ///////////////////////////////////////
    initFastSPI();
    UART_Write(CR);
   // UART_Write_Text(constToVar(uartbuf, "init ok"));
   UART_Write_Text("***** Inicio OK *****");
    UART_Write(CR);  // carrige return
    UART_Write(LF);  // line feed

  //   Create a folder

err = 0;
if (err == FAT32_MakeDir("DIR_A"))  // Create a new folder: DIR_A
    {
        UART_Write(CR);
        UART_Write_Text( "Carpeta DIR_A creada!!");
        UART_Write(CR);  // carrige return
        UART_Write(LF);  // line feed

        err = FAT32_ChangeDir("DIR_A"); // Enter into DIR_A Folder

        fhandle[0]  = FAT32_Open("Prueba.txt", FILE_APPEND ); //open/create TEXT.TXT
        fhandle[1]  = FAT32_Open("Prueba_2.txt", FILE_APPEND ); //open/create TEXT2.TXT
          if (fhandle >= 0) {
             UART_Write_Text( "Archivos creados!!");
             UART_Write(CR);  // carrige return
             UART_Write(LF);  // line feed

             UART_Write_Text( "Escribiendo en los archivos...");
             UART_Write(CR);  // carrige return
             UART_Write(LF);  // line feed

             //Write to files
            // for (i = 0; i < 50; i++ ) {
             FAT32_Write(fhandle[0], "Esto es un texto escrito en Prueba.txt", 38);
             FAT32_Write(fhandle[1], "Esto es un texto escrito en Prueba_2.txt", 41);

             UART_Write_Text( "Texto escrito en archivos!!!!");
             UART_Write(CR);  // carrige return
             UART_Write(LF);  // line feed

           //Close all the files
             err = FAT32_Close(fhandle[0]); // Close  TEXT.TXT file
             err = FAT32_Close(fhandle[1]); // Close  TEXT2.TXT file

            if (err == 0) {         // if the files were previously opened and no error occured  ...}
               UART_Write_Text( "Archivos cerrados");
               UART_Write(CR);  // carrige return
               UART_Write(LF);  // line feed
             }

           }
           else {
           UART_Write(CR);
           UART_Write_Text("No se crearon archivos");
           UART_Write(CR);  // carrige return
           UART_Write(LF);  // line feed
    }

    }
    else {
    UART_Write(CR);
        UART_Write_Text("No se crearon carpetas");
        UART_Write(CR);  // carrige return
        UART_Write(LF);  // line feed
    }
  while (1)
  {
  ;   //loop
  }

}