/*****************************************************************************
Descripci�n:
 El ejemplo de c�digo para IWDG y la configuraci�n para �l es muy simple. 
 Un LED conectado a la PD15 permanece apagado hasta que se presiona un bot�n
 pulsador conectado a PA0. Esto indica la etapa de inicializaci�n.
 Una vez presionado y retenido, el LED comienza a parpadear, indicando 
 el funcionamiento normal. 
 Cuando se suelta el bot�n, el LED permanece encendido y luego se reinicia 
 luego de aproximadamente un segundo. Sabemos con seguridad que el STM32 fue 
 re-iniciado viendo que el LED est� apagado como lo fue durante el arranque.
 
 Target       : STM32F407VG
  ToolChain    : MiKroC para ARM V6.2.0
         www.firtec.com.ar
*****************************************************************************/
//NOTA: Consultar apuntes para el calculo de tiempo.

void setup();
void setup_GPIO();
void setup_IWDG();

void main()
{

     setup();
     while(1)
     {

             if(GPIOA_IDRbits.IDR0 != 0) // Pulsador presionado?
             {
                 GPIOD_ODR.B15 = 0;    // LED apagado
                 delay_ms(50);         // Espera
                 GPIOD_ODR.B15 = 1;    // LED encendido
                 delay_ms(50);         // Espera
                 IWDG_KR = 0xAAAA;     // Recarga IDWG
             }
     };
}


void setup()
{
     setup_GPIO();
     setup_IWDG();
     while(GPIOA_IDRbits.IDR0 != 1); // Espera a que se oprima el pulsador.
}

void setup_GPIO()
{
    GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);  // PD15 como salida
    GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);  // PA0 como entrada
    GPIOD_ODR.B15 = 0;

}

void setup_IWDG()
{
     IWDG_KR = 0x5555;    // Borra la protecci�n de los registros IWDG
     IWDG_PR = 0x1f;      // Set PR
     IWDG_RLR = 0xF4;     // Set RLR
     IWDG_KR = 0xAAAA;    // Recarga IWDG
     IWDG_KR = 0xCCCC;    // Inicia IWDG
}