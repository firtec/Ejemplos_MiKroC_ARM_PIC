 /******************************************************************
*  Descripci�n  : Uso de una interruci�n externa para PD10 y PD11.
*                 por flanco de bajada
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
********************************************************************/
// Consultar el manual de referencia de STM RM0090 para consulta de los
// registros usados en el ejemplo.

 #define led1    GPIOD_ODR.B15  // Pin salida para el led
 #define led2    GPIOD_ODR.B14  // Pin salida para el led
 
//************ Servicio de interrupcin para los pines PD10 y PD11 *************
 void ISR_D11() iv IVT_INT_EXTI15_10 ics ICS_AUTO {
  if( EXTI_PR.B10 != 0)    // Verifico que el pin 10 activ� la irq
      {
          led2 = ~ led2;
          EXTI_PR.B10 = 1;   // Clear PR10
      }
   if( EXTI_PR.B11 != 0)    // Verifico que el pin 11 activ� la irq
      {
          led1 = ~ led1;
          EXTI_PR.B11 = 1;   // Clear PR11
      }
}

void main() {
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15); // PD15 como salida
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_14); // PD14 como salida
  GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_10);   // PD10 como entrada
  GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_11);   // PD11 como entrada
  SYSCFGEN_bit = 1; // RCC APB2 reloj de perif�ricos activo
  SYSCFG_EXTICR3 = 0x00003300; // Mapa de pines IRQ para los pines PD10 y PD11
  EXTI_RTSR = 0x00000000;      // Set flanco de subida desactivado
  EXTI_FTSR = 0x00000C00;      // Flanco de bajada para PD10 y PD11
  EXTI_IMR |= 0x00000C00;      // Set mascara para PD10 y PD11
  NVIC_IntEnable(IVT_INT_EXTI15_10);   // Habilita las interrupciones externas
  led1 = 1;   // Ambos Led inician encendidos
  led2 = 1;
  
  while(1) {
      // Espera por la Interrupci�n
  }
}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************