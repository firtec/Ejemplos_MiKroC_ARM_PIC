/*****************************************************************************
*  Descripci�n  : Cambia el estado de un led colocado en PD15
*
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V 6.2.0
*         www.firtec.com.ar
*****************************************************************************/
#define led   GPIOD_ODR.B15

void main() {

  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);

  while(1) {
     led = ~ led;    // Toggle PD15 (Led Azul)
     Delay_ms(500);

  }
}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************