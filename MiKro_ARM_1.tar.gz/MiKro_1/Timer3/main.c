 /*******************************************************************************************
*  Descripci�n  : Uso de una interrupci�n por Timer_3.
*                 Enciende un LED cada un segundo.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
********************************************************************************************/
void Timer3_interrupt() iv IVT_INT_TIM3 {
  TIM3_SR.UIF = 0;    // Borra la bandera de ISR
  GPIOD_ODR.B15 = ~ GPIOD_ODR.B15;  // Cambia el estado del pin D15
}

void main() {

  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15); // PD15 como salida
  RCC_APB1ENR.TIM3EN = 1; // Reloj del modulo activado
  TIM3_CR1.CEN = 0;   // Desactivo el TIM3
  //TIM3_PSC = 1282;    // Prescaler para el TIM3
  TIM3_PSC = 1;
  //TIM3_ARR = 62499;
  //TIM3_ARR = 699;
  NVIC_IntEnable(IVT_INT_TIM3); // Interrupciones activas
  TIM3_DIER.UIE = 1; // Condiciones de arranque
  TIM3_CR1.CEN = 1;  // Activo el TIM3

  while(1); // Espera por la Interrupci�n
}
