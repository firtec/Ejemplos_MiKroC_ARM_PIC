/*****************************************************************************
Descripci�n:
 En este ejemplo de demostraci�n para el WWDG, us� un par de LEDs designados 
 LED WWDG y LED principal. El LED WWDG est� conectado a PD15 y el LED principal
 est� conectado a PD12. Tambi�n hay un bot�n conectado a PA0. Lo que ocurre en
 el c�digo es bastante simple. Todo el trabajo del WWDG es manejado por su ISR. 
 Cuando se inicia el c�digo, el LED principal se enciende y el LED WWDG se 
 mantiene apagado al mismo tiempo. Esto indica el inicio del c�digo. 
 Despu�s de esto el LED principal cambia cada 300ms mientras que el LED de 
 WWDG tambi�n cambia pero en una tarifa mucho m�s r�pida que el LED principal. 
 La conmutaci�n del LED de WWDG sugiere que ha alcanzado el conteo de despertar 
 temprano contando desde el valor inicial y el contador WWDG est� siendo 
 recargado. El LED principal cambia para mostrar que el funcionamiento normal 
 est� funcionando bien. Sin embargo, si se presiona el bot�n, el contador se 
 obliga a cero, provocando un restablecimiento de WWDG. El proceso se repite 
 una vez que se suelta el bot�n y todo comienza de nuevo.

 Target       : STM32F407VG
  ToolChain    : MiKroC para ARM V6.2.0
         www.firtec.com.ar
*****************************************************************************/
//NOTA: Consultar apuntes para el calculo de tiempo.

void setup();
void setup_GPIO();
void setup_WWDG();

void WWDG_ISR()
iv IVT_INT_WWDG ics ICS_AUTO     //WWDG early wakeup interrupt function
{

   unsigned char cnt = 0;        //Temporary variables for counter and window values
   unsigned char wdt = 0;

   wdt = (WWDG_CFR & 0x7F);      //Read window value
   cnt = (WWDG_CR & 0x7F);       //Read counter value

   if(cnt < wdt)                 //If counter is less than window value
   {
       WWDG_CR |= 0x7F;          //Reload the counter
       WWDG_SR = 0x00;           //Clear interrupt flag
       GPIOD_ODR.B15 = ~ GPIOD_ODR.B15;  //Toggle WWDG LED

   }
}



void main()
{
     setup();

     while(1)
     {

             GPIOD_ODR.B12 = ~ GPIOD_ODR.B12;     //Toggle main LED
             delay_ms(300);                 //Wait for 300ms
             if(GPIOA_IDRbits.IDR0 == 0)    //If button is pressed
             {
                 WWDG_CR = 0x80;            //Force the counter to zero
                 while(1);                  //Get stuck into an infinity loop
             }

     };

}

void setup()
{

     setup_GPIO();
     setup_WWDG();
}

void setup_GPIO()
{

     GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15 | _GPIO_PINMASK_12);
     GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);  // PA0 como entrada
     GPIOD_ODR.B15 = 0;
     GPIOD_ODR.B12 = 1;
     delay_ms(1000);                      //Wait for a second
}



void setup_WWDG()
{
     RCC_APB1ENRbits.WWDGEN = 1;          //Enable clock for WWDG module
     WWDG_CFR = 0x3DF;                    //Set el prescalador del reloj
     WWDG_SR = 0x00;                      //Clear interrupt flag
     WWDG_CR = 0xFF;                      //Turn on WWDG and load the counter
     NVIC_IntEnable(IVT_INT_WWDG);        //Enable NVIC for WWDG interrupt
     EnableInterrupts();

}