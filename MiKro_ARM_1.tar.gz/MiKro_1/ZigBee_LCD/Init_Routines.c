#include "registers.h"
#include "ReadWrite_Routines.h"
#include "Reset_Routines.h"
#include "Misc_Routines.h"

extern sfr sbit TFT_BLED;
extern short int ADDRESS_short_1[], ADDRESS_short_2[], ADDRESS_long_1[], ADDRESS_long_2[], PAN_ID_1[], PAN_ID_2[];
extern short int LQI, RSSI2, SEQ_NUMBER, lost_data;
extern int address_RX_FIFO, address_TX_normal_FIFO;

/*******************************************************************************
* Esta funci�n configura el puerto, pines y sistema en general.
*******************************************************************************/
void Initialize() {
  short int i = 0;
  // Inicia variables
  LQI = 0;
  RSSI2 = 0;
  SEQ_NUMBER = 0x23;
  lost_data = 0;
  address_RX_FIFO = 0x300;
  address_TX_normal_FIFO = 0;

  for (i = 0; i < 2; i++) {
    ADDRESS_short_1[i] = 1;
    ADDRESS_short_2[i] = 2;
    PAN_ID_1[i] = 3;
    PAN_ID_2[i] = 3;
  }

  for (i = 0; i < 8; i++) {
    ADDRESS_long_1[i] = 1;
    ADDRESS_long_2[i] = 2;
  }

  // Configura los pines usados en el modulo ZigBEE
  GPIO_Digital_Output(&GPIOE_BASE, _GPIO_PINMASK_5);
  GPIO_Digital_Output(&GPIOE_BASE, _GPIO_PINMASK_4);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);

  Delay_ms(5);

  // Configura el puerto SPI para ZigBEE
  SPI3_Init_Advanced(_SPI_FPCLK_DIV4, _SPI_MASTER  | _SPI_8_BIT |
                     _SPI_CLK_IDLE_LOW | _SPI_FIRST_CLK_EDGE_TRANSITION |
                     _SPI_MSB_FIRST | _SPI_SS_DISABLE | _SPI_SSM_ENABLE | _SPI_SSI_1,
                     &_GPIO_MODULE_SPI3_PB345);

  pin_reset();                              // Activa pin de reset
  software_reset();                         // Activa software reset
  RF_reset();                               // RF reset
  set_WAKE_from_pin();                      // Setea pin wake

  set_long_address(ADDRESS_long_2);         // Direccion larga
  set_short_address(ADDRESS_short_2);       // Direccin corta
  set_PAN_ID(PAN_ID_2);                     // Set PAN_ID

  init_ZIGBEE_nonbeacon();                  // Configura el modulo ZigBee
  nonbeacon_PAN_coordinator_device();
  set_TX_power(31);                         // Setea potencia del transmisor
  set_frame_format_filter(1);               // Config. el marco de trabajo
  set_reception_mode(1);                    // Modo normal

  pin_wake();                               // Pin de activaci�n
}