/****************************************************************************
**  Descripci�n  : Lectura del c�digo ROM de sensores DS18x20
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 20MHZ
**  NOTA         : Verificado con sensor DS18x20 conectado en el pin RA4.
( No olvidar el resistor de 4,7K en el pin 1-Wire)
*****************************************************************************/
// LCD module connections
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

unsigned temp;
char sernum;
char sernum_hex[8];
unsigned char i;
unsigned char tmp;


void main() {
  //CMCON |=7;
  ADCON1 = 0x0D;  // Pines digitales
  TRISA.B4 = 1;  // Configure RA4 como entrada (Pin 1-Wire)

  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  Lcd_Out(1,5,"ROM-CODE");
  do {
    Ow_Reset(&PORTA, 4);        // Reset del bus 1 Wire
    Ow_Write(&PORTA, 4, 0x33);  // Env�a comando Read_ROM
    Delay_us(120);

       tmp = 17;
       for(i = 0; i <= 7; i++)
          {
            tmp = tmp - 2;
            sernum = Ow_Read(&PORTA, 4);
            bytetohex(sernum, sernum_hex);
            Lcd_Out(2, tmp, sernum_hex);
          }
    Delay_ms(500);
  } while (1);
}
