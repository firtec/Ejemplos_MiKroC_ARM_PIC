/*****************************************************************************
*  Descripci�n  : Ejemplo para el protocolo I2C. Manejo de un sensor HDC1000
*                 Este ejemplo utiliza I2C1 en pines PB7 y PB8.
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
 void LcdFloat(unsigned char,unsigned char, float, unsigned char);
// Pines usados en la pantalla LCD
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
// Definici�nes  para el sensor HDC1000
#define HDC1000_I2C_ADDR        0x40                                                                                                                     //Jumper ADR0 = 0                                                                             //Jumper ADR1 = 0
#define TEMP_I2C_ADDR           0x00
#define DEVICEID_I2C_ADDR       0xFF
#define Tconstant               0.0025177    // Para resoluci�n de 14 bites
#define Hconstant               0.0015259    // Para resoluci�n de 14 bits
// Variables usadas en el proyecto
char tmp_data[12];
float temperature;
float humidity;
float dewpoint;
unsigned int device_id = 0;
unsigned int temp_value,humidity_value;
/******************************************************************************
*  Funci�n para leer el sensor HDC1000. Retorna el valor de la temperatura
*  o la humedad.
******************************************************************************/
void Leer_Sensor() {
  tmp_data[0] = TEMP_I2C_ADDR;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,1,END_MODE_RESTART);
  delay_ms(20);
  I2C1_Read(HDC1000_I2C_ADDR,tmp_data,4,END_MODE_STOP);
  temp_value = (tmp_data[0] << 8) + tmp_data[1];
  humidity_value = (tmp_data[2] << 8) + tmp_data[3];
  temperature = ((float)temp_value * Tconstant)-40;
  humidity = (float)humidity_value * Hconstant;
}
/******************************************************************************
*  Funci�n para configurar el sensor HDC1000 con valores sacados de la hoja de
*  datos del propio sensor.
******************************************************************************/
void Config_Sensor(){
  tmp_data[0] = 0x02;
  tmp_data[1] = 0x10;
  tmp_data[2] = 0x00;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,3,END_MODE_STOP);
  delay_ms(5);
}
/******************************************************************************
*  Funci�n para leer el ID delsensor HDC1000. El ID de estos sensores debe
*  ser igual a 0x1000.
******************************************************************************/
unsigned int Leer_SensorID() {
 unsigned int id_value;
  tmp_data[0] = DEVICEID_I2C_ADDR;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,1,END_MODE_RESTART);
  I2C1_Read(HDC1000_I2C_ADDR,tmp_data,2,END_MODE_STOP);
  id_value = (tmp_data[0] << 8) + tmp_data[1];
  return id_value;
}
/*********************** PROGRAMA PRINCIPAL *********************************/
void main(){
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  Delay_ms(500);
  Lcd_Out(1,4,"Sensor HDC1000");      // Carteles iniciales
  //device_id = Leer_SensorID();
  if(Leer_SensorID() != 0x1000){
  Lcd_Out(2,1,"ERROR de Sensor");
  }
        /*if(device_id != 0x1000){
               Lcd_Out(2,1,"ERROR de Sensor");
              while(1);
        }*/
  Config_Sensor();
  Lcd_Out(2,1,"Temperatura:  ");
  Lcd_Out(3,1,"Humedad:?? ");
  Lcd_Out(4,2,"www.firtec.com.ar");

  while(1) {
     Leer_Sensor();
     LcdFloat(2,13,temperature,1);
     LcdFloat(3,9,humidity,1);
     Delay_ms(100);
  }
}
/******************************************************************************
*  Funci�n para convertir dato float en ASCII y mostrarlo en una coordenada
*  X - y determinada del LCD.
******************************************************************************/
void LcdFloat(unsigned char x,unsigned char y, float num, unsigned char dec){
unsigned char fila = 0;
unsigned char a = 0;
unsigned char nent = 0;
unsigned long ent = num;
float decimales = num;
float resultado = 0;
unsigned long rdec = 0;
unsigned char texto[10];

 fila = x;
 for(a=0;ent>0;a++){
   ent /= 10;
   nent++;
 }
 if(nent==0) nent=1;
 ent=num;
 resultado = decimales-ent;

 for(a=1;a<=dec;a++)
   resultado*=10;
 for(a=0;a<nent;a++){
   texto[a]=ent%10;
   ent/=10;
 }
 for(a=nent;a>0;a--)
   Lcd_Chr(fila,y++,texto[a-1]+48);
 Lcd_Chr_cp('.');
 y++;
 rdec=resultado;
 for(a=0;a<dec;a++){
   texto[a]=rdec%10;
   rdec/=10;
 }
 for(a=dec;a>0;a--)
 Lcd_Chr(fila,y++,texto[a-1]+48);

}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************