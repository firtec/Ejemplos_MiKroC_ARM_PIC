//  DS18s20 sensor : (Temp resolution default is 9)

float temperature_DS18s20;

#define PORT_DS18s20   PORTE
#define PIN_DS18s20    0

void Reading_Temperature_DS18s20(void)
{
 unsigned int temp_;
 unsigned int temp_DS18s20;
 float T_DS18s20;
 
 //PORT_DS18s20 = 1;
 //TRIS_DS18s20 = 1;             // Set PORTx as input
 
   //--- perform temperature reading
    Ow_Reset(&PORT_DS18s20, PIN_DS18s20);                         // Onewire reset signal
    Ow_Write(&PORT_DS18s20, PIN_DS18s20, 0xCC);                   // Issue command SKIP_ROM
    Ow_Write(&PORT_DS18s20, PIN_DS18s20, 0x44);                   // Issue command CONVERT_TEMP
    //Delay_us(120);
    Delay_us(600);
    Ow_Reset(&PORT_DS18s20, PIN_DS18s20);
    Ow_Write(&PORT_DS18s20, PIN_DS18s20, 0xCC);                   // Issue command SKIP_ROM
    Ow_Write(&PORT_DS18s20, PIN_DS18s20, 0xBE);                   // Issue command READ_SCRATCHPAD

    temp_ = Ow_Read(&PORT_DS18s20, PIN_DS18s20);
    temp_DS18s20 = (Ow_Read(&PORT_DS18s20, PIN_DS18s20) << 8) + temp_;
    
  // check if temperature is negative
  if(temp_DS18s20 & 0x8000)
  {
    temp_DS18s20 = ~temp_DS18s20 + 1;
    T_DS18s20 = -((float)temp_DS18s20);
  }
  else
  {
   T_DS18s20 = (float)temp_DS18s20;
  }

  T_DS18s20 = 0.5 * T_DS18s20;
  temperature_DS18s20 = T_DS18s20;
}