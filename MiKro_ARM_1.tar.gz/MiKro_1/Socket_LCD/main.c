/***********************************************************************
*  Descripci�n  : Env�o de datos por  WiFi con el modulo ESP8266.
*                 Se controlan los LED's Azul y Naranja de la placa
*                 entrenadora Discovery con procesador STM32F407VG.
*
*  Target       : STM32F407VG
*  ToolChain    : MiKroC 5
*
*         www.firtec.com.ar
************************************************************************/
 void Configurar_ESP8266(void);
// Pines asignados el LCD
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

/******************************************************************************
* Funci�n para el env�o de cadenas por el puerto UART.
******************************************************************************/
void Enviar_String(const char *s)
{
  while(*s)
  {
    UART2_Write(*s++);
  }
}
/************************* PROGRAMA PRINCIPAL ********************************/
void main(){
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_13);
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  UART2_Init(9600);

  Lcd_Out(1,2,"Socket con MiKroC");      // Carteles iniciales
  Lcd_Out(2,2,"Configurando Wi-Fi");
  Configurar_ESP8266();                  // Configura el enlace WiFi
  Lcd_Out(2,1,"---Enlace Activo---");
  Lcd_Out(4,2,"www.firtec.com.ar");

  GPIOD_ODR.B15 = 1;            // Led Azul inicia encendido
  GPIOD_ODR.B13 = 1;            // Led Naranja inicia encendido
  while(1) {
  char caracter;
          Delay_ms(500);
          Enviar_String("0");   // Env�a caracter de control para el Socket
          caracter = UART2_Read();  // Recibe datos desde el Socket
          if(caracter == '4')       // Es el comando correcto?
          GPIOD_ODR.B15 = ~ GPIOD_ODR.B15;  // Cambia estado del led Azul
         if(caracter == '5')                // Es el comando correcto?
          GPIOD_ODR.B13 = ~ GPIOD_ODR.B13;  // Cambia estado del led Naranja
          caracter = 0;
  }
}
/****************************************************************
* Configuraci�n b�sica para crear un cliente UDP sobre una IP y
* puerto determinado.
*
* IMPORTANTE:
* Se supone que los datos de conexi�nes WiFi (SSI y PASS) ya
* fueron cargados antes ya que estos datos no se pierden si el
* modulo se apaga o resetea, pero si la configuraci�n del socket.
* Esta configuraci�n dispone el modo wifi para que todo lo enviado
* por la USART pase directamente al socket.
* (Transparent Transmission Mode)
*
*****************************************************************/
void Configurar_ESP8266(void){
        Enviar_String("AT+RST\r\n");  // Reset general del m�dulo.
        Delay_ms(2000);
        Enviar_String("AT\r\n");        // Comando de control
        Delay_ms(500);
        Enviar_String("AT+CIPSTART=");  // Configura el Socket UDP
        Enviar_String("\"");
        Enviar_String("UDP");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("\"");
        Enviar_String("192.168.1.12");
        Enviar_String("\"");
        Enviar_String(",");
        Enviar_String("30000\r\n");
        Delay_ms(500);
        Enviar_String("AT+CIPMODE=1\r\n"); // Activa el modo " TX transparente"
        Delay_ms(500);
        Enviar_String("AT+CIPSEND\r\n");  // Confirmo el modo
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************