

void Mostrar(void); // Funci�n que mostrar� los datos
void init_timers();

unsigned char contador=0,unidad=0,decena=0,centena=0,resto=0,bandera =0;
const unsigned char Digito[16] =
{0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,
 0x67,0x77,0x7C,0x39,0x5E,0x79,0x71};
#define tiempo 5
volatile unsigned char marca =0;

void ISR_Timer() iv 0x0008 ics ICS_AUTO {
  // Reset the timer count
  TMR0H=0xF8;
  TMR0L=0x30;
  PORTC.B2 = ~PORTC.B2;  // Cambia de estado pin 33
  marca++;
  Mostrar();
  INTCON.TMR0IF = 0;

}



void init_timers() {
  // Initialise Timer0 for a 1Khz interrupt
  // 8Mhz clock & want 1Khz interrupt
  // See http://www.enmcu.com/software/timer0calculatorandcodegeneration
  // for values.
  //
  INTCON.GIE=1;         //globle interrupt enable
  INTCON.PEIE=1;        //peripharel interrupt enable
  INTCON.TMR0IF = 0x0;  //Clear timer0 overflow interrupt flag
  INTCON.TMR0IE = 1;    //enable the timer0 by setting TRM0IE flag

  T0CON.T08BIT = 0;     // 16 Bit timer
  T0CON.T0CS = 0;       // Internal clock
  T0CON.PSA = 1;        // Set scaler to 1:4
  TMR0H = 0xF8;         // Initial count of 0xF830
  TMR0L = 0x30;
  T0CON.TMR0ON = 1;     // Turn Timer0 on.
}
   
void main()
{
 ADCON1 = 0X0F;         // Configura los pines del PORT A como I/O Digitales
 TRISA = 0x01; // RA0 is input
 TRISD = 0; // Puerto D outputs
 TRISB = 0;    // PORTB is output
 TRISC2_bit  = 0;           // Set bit2 de PTC
 PORTC.B2 = 0;

  init_timers();
 while(1)
   {
    if(PORTA.RA0!=1){        // Pulsador y bandera =0?
    contador++;                          // Incrementa el contador
    centena = contador / 100;                  // Se define la centena
    resto = contador % 100;                    // Recupera el resto de la div.
    decena = resto /10;                        // Se define la decena
    unidad = resto % 10;                      // El resto es la unidad
    // Evita que se cuente el mismo n�mero mas de una vez.
    while(!(PORTA.RA0));
   }

   }

 }
 
void Mostrar(){
 switch(marca){
    case 1:{
        PORTB=Digito[unidad];         // Escribe la unidad en el puerto B
        PORTD.RD2 = 1;            // Pone el pin 21
    break;
     }
    case 2:{
        PORTD.RD2 = 0;           // Pone a 0 el pin 21
        PORTB=Digito[decena];         // Escribe la decena en el puerto B
        PORTD.RD1 = 1;           // Pone a 1 el pin 20
    break;
     }
    case 3:{
        PORTD.RD1 = 0;         // Pone a 0 el pin 20
        PORTB=Digito[centena];         // Escribe la centena en el puerto B
        PORTD.RD0 = 1;           // Pone a 1 el pin 19
    break;
     }
    case 4:{
        PORTD.RD0 = 0;           // Pone a 0 el pin 19
        marca =0;
    break;
  }
 }
}