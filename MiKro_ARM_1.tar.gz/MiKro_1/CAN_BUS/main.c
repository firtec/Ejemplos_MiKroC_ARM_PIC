/*****************************************************************************
*  Descripci�n  :
*
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/

    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;

// Globals
float temp;
char temp_format;
unsigned char txt[12];
char RxTx_Data[8];unsigned
const long ID_1st = 12111, ID_2nd = 3; // node IDs
long Rx_ID;
unsigned long Can_Init_Flags;
unsigned char Can_Send_Flags, Can_Rcv_Flags; // can flags
unsigned char Rx_Data_Len;
char Msg_Rcvd;
//Can_Send_Flags = _CAN_TX_XTD_FRAME &_CAN_TX_NO_RTR_FRAME;

/*Place/Copy this part in declaration section*/
const unsigned int SJW = 1;
const unsigned int BRP = 4;
const unsigned int PHSEG1 = 6;
const unsigned int PHSEG2 = 6;
const unsigned int PROPSEG = 8;
const unsigned int CAN_CONFIG_FLAGS =
	_CAN_CONFIG_AUTOMATIC_RETRANSMISSION &
	_CAN_CONFIG_RX_FIFO_NOT_LOCKED_ON_OVERRUN &
	_CAN_CONFIG_TIME_TRIGGERED_MODE_DISABLED &
	_CAN_CONFIG_TX_FIFO_PRIORITY_BY_IDINTIFIER &
	_CAN_CONFIG_WAKE_UP;

 /*Place/Copy this part in init section*/


// =========================== PROGRAMA PRINCIPAL ==============================
void main(){
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15);
  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear display
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Cursor off
  
  Can_Send_Flags = _CAN_TX_XTD_FRAME &_CAN_TX_NO_RTR_FRAME;
  
  CAN1InitializeAdvanced(SJW, BRP, PHSEG1, PHSEG2, PROPSEG, 
                         CAN_CONFIG_FLAGS, &_GPIO_MODULE_CAN1_PD01);
  CAN1SetOperationMode(_CAN_OperatingMode_Initialization); // set CONFIGURATION mode
  CANSetFilterScale32(0, _CAN_FILTER_ENABLED & _CAN_FILTER_ID_MASK_MODE & _CAN_FILTER_XTD_MSG, ID_2nd, -1);

  CAN1SetOperationMode(_CAN_OperatingMode_Normal); // set NORMAL mode

  RxTx_Data[0] = 0; // set initial data to be sent
  CAN1Write(ID_1st, RxTx_Data, 1, Can_Send_Flags); // send initial message
  Delay_ms(500);
  Lcd_Out(1,4,"CAN Bus");      // Carteles iniciales
 // Lcd_Out(2,1,"Temperatura:  ");
  //Lcd_Out(3,1,"Humedad:?? ");
  Lcd_Out(4,2,"www.firtec.com.ar");

  while(1) {
     Msg_Rcvd = CAN1Read(0, &Rx_ID , RxTx_Data , &Rx_Data_Len, &Can_Rcv_Flags); // receive message
     if ((Rx_ID == ID_2nd) && Msg_Rcvd) { // if message received check id
    GPIOD_ODR.B15 = ~ GPIOD_ODR.B15; // id correct, output data at PORTD
    //sprintf(txt, "%2.2f", temp);
    RxTx_Data[0]++ ; // increment received data
    Delay_ms(100);
    CAN1Write(ID_1st, RxTx_Data, 1, Can_Send_Flags); // send incremented data back
}
      //sprintf(txt, "%2.2f", temp);
      // Lcd_Out(2,1,txt);
          // LcdFloat(2,13,Leer_Sensor(dato_temp),1);
          // LcdFloat(3,9,Leer_Sensor(dato_hum),1);
           Delay_ms(1000);
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************