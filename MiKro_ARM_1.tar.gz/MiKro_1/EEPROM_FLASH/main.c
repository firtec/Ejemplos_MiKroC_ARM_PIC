/*****************************************************************************
*  Descripci�n  : Ejemplo para emular memoria EEPROM en memoria FLASH.
*                 El dato se recupera mediante el uso de punteros.
*                 Se escribe en el sector 11 de FLASH. (128k)
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/

 void LcdFloat(unsigned char,unsigned char, float, unsigned char);
 
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;


  char texto[20] = "";
  unsigned char *ptr;
  unsigned long direccion =  0x080E0000; // Direcci�n inicial.
  unsigned char dato = 1; // Valor inicial del dato.
  
void main() {
    unsigned char status;
    unsigned char a =0;

    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    FLASH_Unlock();
    /*status = FLASH_EraseSector(_FLASH_SECTOR_11);
    if(status == 0){
     Lcd_Out(2, 1, "OK!!" );
    }*/
    
    // Escribe 6 bytes en memoria EEprom emulada.
   for (a=0; a<= 5; a++){
    status = FLASH_Write_Byte(direccion, dato);
    if(status != 0){
     Lcd_Out(2, 1, "ERROR" );
    }
    delay_ms(100);
    direccion++;
    dato++;
    }

    FLASH_Lock();
    delay_ms(10);
    ptr = (unsigned char*) 0x080E0000;  // Define el puntero
    
    for (a=0; a<= 5; a++){
    texto[a] = *ptr + 0x30;  // Salva contador en ASCII
    *ptr++; // Incrementa direcci�n del puntero
    }
     Lcd_Out(2, 1, texto ); // Muestra la cadena
  while(1) {}
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************