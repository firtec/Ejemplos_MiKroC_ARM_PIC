

unsigned char bandera =0;
void main() {
ADCON1 = 0X0F; 	// Configura los pines del PORT A como I/O Digitales
TRISA=0X01;		// Configura el pin 2 como entrada digital
TRISB=0X00;		// Todo el puerto B es puesto a 0

 PORTB =0;
    for(;;){    	// Bucle infinito
      if(PORTA.RA0!=1 && bandera== 0){ // Pulsador y bandera =0?
       PORTB.B0 = ~PORTB.B0;  // Cambia estado del LED
          bandera = 1;  // Evita que se cuente el mismo n�mero mas de una vez.
      }
      if(PORTA.RA0!=0)   // Espera que se libere el pulsador para contar solo
       bandera=0;
   }
 }
