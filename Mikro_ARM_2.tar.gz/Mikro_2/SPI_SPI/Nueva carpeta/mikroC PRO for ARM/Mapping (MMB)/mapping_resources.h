const code char Tahoma11x13_Regular[];
const code char world_map_jpg[22943];
