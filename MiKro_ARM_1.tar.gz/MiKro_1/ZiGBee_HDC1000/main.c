/*****************************************************************************
*  Descripci�n  : Ejemplo para el protocolo SPI manejando un modulo RFID click
*                 fabricado por MiKroElectroniKa con el chip CR95HF .
*                 Este ejemplo utiliza SPI3 en pines PB3 PB4 PB5.
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/
#include "resources.h"
#include "registers.h"
#include "ReadWrite_Routines.h"
#include "Reset_Routines.h"
#include "Misc_Routines.h"
#include "Init_Routines.h"
//#include "Init_Routines.c"
//#include "ReadWrite_Routines.c"
//#include "Reset_Routines.c"
//#include "Misc_Routines.c"

// BEE Click Board connections
sbit CS at GPIOE_ODR.B5;                // CS pin
sbit RST at GPIOE_ODR.B4;               // RST pin
sbit INT at GPIOD_ODR.B2;               // INT pin
sbit WAKE_ at GPIOC_ODR.B5;             // WAKE pin

// TFT module connections

// End TFT module connections

extern short int DATA_TX[];
char txt[15];

// Definici�nes  para el sensor HDC1000
#define HDC1000_I2C_ADDR        0x40                                                                                                                     //Jumper ADR0 = 0                                                                             //Jumper ADR1 = 0
#define TEMP_I2C_ADDR           0x00
#define DEVICEID_I2C_ADDR       0xFF
#define Tconstant               0.0025177    // Para resoluci�n de 14 bites
#define Hconstant               0.0015259    // Para resoluci�n de 14 bits
// Variables usadas en el proyecto
char tmp_data[12];
float temperature;
float humidity;
float dewpoint;
unsigned int device_id = 0;
unsigned int temp_value,humidity_value;
/******************************************************************************
*  Funci�n para leer el sensor HDC1000. Retorna el valor de la temperatura
*  o la humedad.
******************************************************************************/
void Leer_Sensor() {
  tmp_data[0] = TEMP_I2C_ADDR;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,1,END_MODE_RESTART);
  delay_ms(20);
  I2C1_Read(HDC1000_I2C_ADDR,tmp_data,4,END_MODE_STOP);
  temp_value = (tmp_data[0] << 8) + tmp_data[1];
  humidity_value = (tmp_data[2] << 8) + tmp_data[3];
  temperature = ((float)temp_value * Tconstant)-40;
  humidity = (float)humidity_value * Hconstant;
}
/******************************************************************************
*  Funci�n para configurar el sensor HDC1000 con valores sacados de la hoja de
*  datos del propio sensor.
******************************************************************************/
void Config_Sensor(){
  tmp_data[0] = 0x02;
  tmp_data[1] = 0x10;
  tmp_data[2] = 0x00;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,3,END_MODE_STOP);
  delay_ms(5);
}
/******************************************************************************
*  Funci�n para leer el ID delsensor HDC1000. El ID de estos sensores debe
*  ser igual a 0x1000.
******************************************************************************/
unsigned int Leer_SensorID() {
 unsigned int id_value;
  tmp_data[0] = DEVICEID_I2C_ADDR;
  I2C1_Start();
  I2C1_Write(0x40,tmp_data,1,END_MODE_RESTART);
  I2C1_Read(HDC1000_I2C_ADDR,tmp_data,2,END_MODE_STOP);
  id_value = (tmp_data[0] << 8) + tmp_data[1];
  return id_value;
}

void main() {
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_14);
  I2C1_Init_Advanced(100000, &_GPIO_MODULE_I2C1_PB87);
  Initialize(); 

  if(Leer_SensorID() != 0x1000){
  GPIOD_ODR.B14 = 1;
  }
  Config_Sensor();

  while(1) {
    Leer_Sensor();
    sprintf(txt, "%02.1f ", temperature);
    DATA_TX[0] = txt[0];
    DATA_TX[1] = txt[1];
    DATA_TX[2] = txt[2];
    DATA_TX[3] = txt[3];
    //DATA_TX[4] = txt[4];
    
    sprintf(txt, "%03.1f%% ", humidity);
    DATA_TX[4] = txt[0];
    DATA_TX[5] = txt[1];
    DATA_TX[6] = txt[2];
    DATA_TX[7] = txt[3];
    DATA_TX[8] = txt[4];
    DATA_TX[9] = txt[5];
    //DATA_TX[10] = txt[6];
    write_TX_normal_FIFO();
    delay_ms(500);
    GPIOD_ODR.B12 = ~ GPIOD_ODR.B12;
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************