 /*************************************************************
*  Descripci�n  : Uso de una interruci�n externa por PA0.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
***************************************************************/
// Consultar el manual de referencia de STM RM0090 para consulta de los
// registros usados en el ejemplo.

 #define led    GPIOD_ODR.B15  // Pin salida para el led
void PA1_ISR() iv IVT_INT_EXTI1 ics ICS_AUTO {
       EXTI_PR.B1 = 1;    // Borra la bandera de interrupci�n
    led = ~ led;      // Cambia estado del led.
}

  void ExtInt() iv IVT_INT_EXTI0 ics ICS_AUTO {
   EXTI_PR.B0 = 1;    // Borra la bandera de interrupci�n
    led = ~ led;      // Cambia estado del led.
}

void main() {
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_15); // PD15 como salida
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);   // PA0 como entrada
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_1);   // PA1 como entrada
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_15);   // PA1 como entrada

  SYSCFGEN_bit = 1; // RCC APB2 reloj de perif�ricos activo
  //SYSCFG_EXTICR1 = 0x00000000;       // Mapa de pines para PA0
  SYSCFG_EXTICR1 = 0x00000000;
  EXTI_RTSR = 0x00000000;            // Flanco de subida para PA0 desabilitado
 // EXTI_FTSR = 0x00000001;            // Flanco de bajado para PA0
  EXTI_FTSR = 0x00000002;
  EXTI_IMR |= 0x00000002;            // Set de la m�scara para PA0
  //EXTI_IMR |= 0x00000010;
  //NVIC_IntEnable(IVT_INT_EXTI0);     // Habilita interrupci�nes EXTI0
  NVIC_IntEnable(IVT_INT_EXTI1);

  led = 1;   // Led inicia encendido
  
  while(1) {
      // Espera por la Interrupci�n
  }
}
//******************* Fin de archivo - FIRTEC ARGENTINA ***********************