/*****************************************************************************
*  Descripci�n  : Sensor ultras�nico HY-SRF05 para medir distancias en cmts.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/

 void Leer_Conversor(void);
    sbit LCD_RS at GPIOE_ODR.B4;
    sbit LCD_EN at GPIOE_ODR.B6;
    sbit LCD_D4 at GPIOC_ODR.B12;
    sbit LCD_D5 at GPIOC_ODR.B13;
    sbit LCD_D6 at GPIOC_ODR.B14;
    sbit LCD_D7 at GPIOC_ODR.B15;
  volatile unsigned int contador =0;
  float distancia =0;
  char texto[20] = "";

void Timer7_interrupt() iv IVT_INT_TIM7 {
TIM7_SR.UIF = 0;
  contador++;
}

 void InitTimer7(){ // Timer7 (1us)
  RCC_APB1ENR.TIM7EN = 1;
  TIM7_CR1.CEN = 0;
  TIM7_PSC = 0;
  TIM7_ARR = 83;
  NVIC_IntEnable(IVT_INT_TIM7);
  TIM7_DIER.UIE = 1;
  TIM7_CR1.CEN = 1;

}


void main() {

    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);
    InitTimer7();

    GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_0);  // Disparo
    GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_1);   // Eco
    delay_ms(10);

    Lcd_Out(1, 1, "Sensor HY-SRF05" );

  while(1) {

  GPIOB_ODR.B0=1; // Inicia medici�n.
  delay_us(10);
  GPIOB_ODR.B0=0;// Termina el pulso.
  while(GPIOB_IDR.B1==0);// Espera inicia del pulso ECO.
  TIM7_CR1.CEN = 1;// Inicia el temporizador
  while(GPIOB_IDR.B1);// Espera el fin de Echo
  TIM7_CR1.CEN=0;// Detiene temporizador
  TIM7_CNT=0;// Restablece el contador del temporizador
  distancia =((long)contador*34.0/1000)/2; // Calcula la distancia
  //distancia =((long)contador*34/1000);
  //sprintf(texto,"Cmts:%03d", distancia);
  sprintf(texto,"Cmts:%2.1f   ", distancia);

   Lcd_Out(2,1, texto );
  contador =0; // sayac sifirlaniyor
  delay_ms(250);

 }
}



//******************* Fin de archivo - FIRTEC ARGENTINA ***********************