   // LCD module connections
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// End LCD module connections



 volatile unsigned char muestras_0 =0, muestras_1 =0;
 volatile unsigned int M0=0,M1=0;
 volatile unsigned int conv_0=0, conv_1=0;
 volatile float voltaje_0 =0, voltaje_1 =0;
 volatile unsigned char canal=0;  // Inicia en el canal 0 (PIN2)
   
   
 void LcdFloat(unsigned char,unsigned char, float, unsigned char);