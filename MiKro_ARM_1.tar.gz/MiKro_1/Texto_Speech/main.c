/*****************************************************************************
*  Descripci�n  : Programa ejemplo para el sintetizador de voz.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/
// NOTA: Activar Tools-> Options-> Output-> Case Sensitive
//----------------------------------------------------------------------------
  #include "text_to_speech.h"

sbit TTS_RST at GPIOE_ODR.B4;
sbit TTS_CS at GPIOE_ODR.B5;
sbit TTS_MUTE at GPIOC_ODR.B5;
sbit TTS_RDY at GPIOD_IDR.B2;
void msg_blk( uint16_t *req, uint16_t *err );
void fatal_err( uint16_t *err );
void system_init( void );
 char txt[12];
 
void msg_blk( uint16_t *req, uint16_t *err )
{

}

void fatal_err( uint16_t *err )
{
    GPIOD_ODR.B14 = 1;
    tts_init();
    tts_fatal_err_callback( fatal_err );
    
}

void system_init()
{
    GPIO_Digital_Output( &GPIOE_ODR, _GPIO_PINMASK_4 );
    GPIO_Digital_Output( &GPIOE_ODR, _GPIO_PINMASK_5 );
    GPIO_Digital_Output( &GPIOC_ODR, _GPIO_PINMASK_5 );
    GPIO_Digital_Input( &GPIOD_IDR, _GPIO_PINMASK_2 );
    Delay_ms( 200 );

    SPI3_Init_Advanced( _SPI_FPCLK_DIV128, _SPI_MASTER | _SPI_8_BIT |
                        _SPI_CLK_IDLE_HIGH | _SPI_SECOND_CLK_EDGE_TRANSITION |
                        _SPI_MSB_FIRST | _SPI_SS_DISABLE | _SPI_SSM_ENABLE |
                        _SPI_SSI_1, &_GPIO_MODULE_SPI3_PB345);
    Delay_ms( 200 );
}

void main(){
     float dato = 12.81;
     GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_14);
     GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_12);
     GPIOD_ODR.B14 = 0;
    system_init();
    tts_init();
    tts_msg_block_callback( msg_blk );
    tts_fatal_err_callback( fatal_err );
    tts_image_load( ( uint8_t* )TTS_INIT_DATA, sizeof( TTS_INIT_DATA ) );
    tts_image_exec();
    tts_interface_test();
    tts_power_default_config();
    tts_audio_default_config();
    tts_volume_set( 0 );
   tts_default_config();
   tts_config( 0x05, false, TTSV_LS, 0x0100 );
    GPIOD_ODR.B12 = 1;
  while(1) {
  Delay_ms(2000);
  //tts_speak("El dato ha cambiado nuevo valor     " );
   sprintf(txt, "Temperatura %2.1f", dato);
   tts_speak( txt );
   //tts_speak("visitenos en www.firtec.com.ar");

  
  
  }
}


//******************* Fin de archivo - FIRTEC ARGENTINA ***********************