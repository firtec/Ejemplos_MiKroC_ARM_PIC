#include "__Lib_FAT32.h"

//sbit Mmc_Chip_Select at GPIOD_ODR.B3;
sbit Mmc_Chip_Select           at GPIOD_ODR.B12;
sbit MMC_Card_Detect           at GPIOB_IDR.B15;
/*+-----------------------------+---------------+-------------+
          |  STM32 SDIO Pins            |     SD        | Pin      |
+-----------------------------+---------------+-------------+
        |      SDIO D2                |   D2          | 1        |
        |      SDIO D3                |   D3          | 2        |
        |      SDIO CMD               |   CMD         | 3        |
        |                             |   VCC         |    4 (3.3 V)|
        |      SDIO CK               |    CLK         | 5        |
        |                             |   GND         |    6 (0 V)  |
        |      SDIO D0                |   D0          | 7        |
        |      SDIO D1                |   D1          | 8        |
+-----------------------------+---------------+-------------+*/
unsigned char  Fat_Initialized_Flag;

void Init_SDIO()
{
    // Initialize SDIO
    SDIO_Reset();

    SDIO_Init(_SDIO_CFG_POWER_SAVE_DISABLE | _SDIO_CFG_4_WIDE_BUS_MODE | _SDIO_CFG_CLOCK_BYPASS_DISABLE
            | _SDIO_CFG_CLOCK_RISING_EDGE | _SDIO_CFG_HW_FLOW_DISABLE, 10, &_GPIO_MODULE_SDIO_D0_D3);


    Mmc_Set_Interface(_MMC_INTERFACE_SDIO);
}

char Init_FAT()
{
    char FAT_cnt = 0;

    if (Fat_Initialized_Flag == 0)
    {
        while ((FAT32_Init() != 0) && (FAT_cnt < 5))
            FAT_cnt ++;
        if (FAT_cnt < 5)
        {
            SDIO_Init(_SDIO_CFG_POWER_SAVE_DISABLE | _SDIO_CFG_4_WIDE_BUS_MODE | _SDIO_CFG_CLOCK_BYPASS_DISABLE
                    | _SDIO_CFG_CLOCK_RISING_EDGE | _SDIO_CFG_HW_FLOW_DISABLE, 1, &_GPIO_MODULE_SDIO_D0_D3);
            Fat_Initialized_Flag = 1;
        }
    }

    return FAT_cnt;
}


unsigned int a=0;

void main()
{
    short fat32_file;
    char i,cnt=0;
    char txt_sd[] ="SDIO library from Mikroelektronika ";

    GPIO_Config(&GPIOD_BASE,
            _GPIO_PINMASK_12 | _GPIO_PINMASK_13,
            _GPIO_CFG_MODE_OUTPUT | _GPIO_CFG_SPEED_MAX | _GPIO_CFG_OTYPE_PP);


    // Initialize SDIO
    Init_SDIO();
    cnt = Init_FAT();

    fat32_file = FAT32_Open("SDIO.txt", FILE_APPEND); //FILE_WRITE

    FAT32_Write(fat32_file, txt_sd, strlen(txt_sd));

    FAT32_Close(fat32_file);

    if(cnt < 5)
    {
        GPIOD_ODR.B13 = 0;       // FAT32 Init: Success
    }
    else
    {
         GPIOD_ODR.B13 = 1;       // FAT32 Init: Failed
    }

  while(1)
  {
       GPIOD_ODR.B12 = ~GPIOD_ODR.B12;
       Delay_ms(100);
  }
}
