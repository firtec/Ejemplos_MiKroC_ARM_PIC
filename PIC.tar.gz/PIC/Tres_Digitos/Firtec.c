


unsigned char contador=0,unidad=0,decena=0,centena=0,resto=0,bandera =0;
const unsigned char Digito[10]=
      {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x7,0x7F,0x67};

void main() {
   ADCON1 = 0X0F; 	// Configura los pines del PORT A como I/O Digitales
   TRISA=0X01;		// Configura el pin 2 como entrada digital
   TRISB=0X00;		// Todo el puerto B es puesto a 0
   TRISD=0X00;		// Configura el puerto D como salida

  for(;;){    	// Bucle infinito
    if(PORTA.RA0!=1 && bandera== 0){	// Pulsador y bandera =0?
    contador++;			 	// Incrementa el contador
    centena = contador / 100;  		// Se define la centena
    resto = contador % 100;    		// Recupera el resto de la div.
    decena = resto /10;        		// Se define la decena
    unidad = resto % 10;      		// El resto es la unidad
    bandera = 1;  // Evita que se cuente el mismo n�mero mas de una vez.
   }
  PORTB=Digito[unidad]; 	// Escribe la unidad en el puerto B
  PORTD.RD2 = 1;    	// Pone el pin 21
  delay_ms(6);       	// Espera 5mS
  PORTD.RD2 = 0;   	// Pone a 0 el pin 21
  PORTB=Digito[decena]; 	// Escribe la decena en el puerto B
  PORTD.RD1 = 1;   	// Pone a 1 el pin 20
  delay_ms(6); 		// Espera 5mS
  PORTD.RD1 = 0; 	        // Pone a 0 el pin 20
  PORTB=Digito[centena]; 	// Escribe la centena en el puerto B
  PORTD.RD0 = 1;   	// Pone a 1 el pin 19
  delay_ms(6);        	// Espera 5mS
  PORTD.RD0 = 0;   	// Pone a 0 el pin 19
  if(PORTA.RA0!=0)   	// Espera que se libere el pulsador para contar solo
    bandera=0;             	// un n�mero por vez.
  }
 }