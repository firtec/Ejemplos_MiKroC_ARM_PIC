/*****************************************************************************
*  Descripci�n  : Ejemplo para escribir y leer datos de una memoria SD por el
*                 puerto SDIO (La memoria debe estar formateada en FAT32).
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
#include "__Lib_FAT32.h"
void Init_SDIO(void);
char Init_FAT(void);

sbit Mmc_Chip_Select           at GPIOD_ODR.B12;
sbit MMC_Card_Detect           at GPIOB_IDR.B15;
/*** Pines de la memoria *************
NCD         PB15
DATO 0      PC8
DATO 1      PC9
DATO2       PC10
DATO3       PC11
CLK         PC12
CMD         PD2
**************************************/

unsigned char  Fat_Initialized_Flag;
signed long Ext_fhandle;
char Ext_res_initialized;

char ext[5]= ".csv";
static char ArchNombre[13];

unsigned char date = 20;
unsigned char  mes = 7;
unsigned char year = 17;

char txt_sd[] ="Este es el texto del archivo ";
//unsigned long currentSector = -1, res_file_size;

void Init_SDIO()
{
    SDIO_Reset();
   SDIO_Init(_SDIO_CFG_POWER_SAVE_DISABLE | _SDIO_CFG_1_WIDE_BUS_MODE |
              _SDIO_CFG_CLOCK_BYPASS_DISABLE | _SDIO_CFG_CLOCK_RISING_EDGE |
              _SDIO_CFG_HW_FLOW_DISABLE, 125, &_GPIO_MODULE_SDIO_D0_D3);
              
// Set pull-ups en los pines SDIO
    GPIOD_PUPDRbits.PUPDR2 = 1;
    GPIOC_PUPDRbits.PUPDR8 = 1;
    GPIOC_PUPDRbits.PUPDR9 = 1;
    GPIOC_PUPDRbits.PUPDR10 = 1;
    GPIOC_PUPDRbits.PUPDR11 = 1;
    GPIOB_PUPDRbits.PUPDR15 = 1;
    Mmc_Set_Interface(_MMC_INTERFACE_SDIO);
}

char Init_FAT()
{
     char FAT_cnt = 0;

    if (Fat_Initialized_Flag == 0)
    {
        while ((FAT32_Init() != 0) && (FAT_cnt < 5))
            FAT_cnt ++;
        if (FAT_cnt < 5)
        {
        SDIO_Init(_SDIO_CFG_POWER_SAVE_DISABLE | _SDIO_CFG_1_WIDE_BUS_MODE | _SDIO_CFG_CLOCK_BYPASS_DISABLE
                    | _SDIO_CFG_CLOCK_RISING_EDGE | _SDIO_CFG_HW_FLOW_DISABLE, 1, &_GPIO_MODULE_SDIO_D0_D3);
           

                      
            Fat_Initialized_Flag = 1;
        }
    }

    return FAT_cnt;
}

void main()
{
    unsigned long fat32_file;
    char i,cnt=0;
    GPIO_Config(&GPIOD_BASE,
            _GPIO_PINMASK_12 | _GPIO_PINMASK_13 | _GPIO_PINMASK_15,
            _GPIO_CFG_MODE_OUTPUT | _GPIO_CFG_SPEED_MAX | 
            _GPIO_CFG_OTYPE_PP);

    Init_SDIO();
    cnt = Init_FAT();
    sprintf(ArchNombre,"%02d_%02d_%02d", date,mes,year);
    strcat(ArchNombre,ext);
    fat32_file = FAT32_Open(ArchNombre, FILE_APPEND);
    
    //fat32_file = FAT32_Open("Prueba.txt", FILE_APPEND);  //FILE_WRITE);
    
    FAT32_Write(fat32_file, txt_sd, strlen(txt_sd));

    FAT32_Close(fat32_file);

    if(cnt < 5)
    {
        GPIOD_ODR.B13 = 0;       // FAT32 Iniciada OK!!!
    }
    else
    {
         GPIOD_ODR.B13 = 1;       // FAT32 Inicio fallido!!!
    }

  while(1)
  {
       GPIOD_ODR.B12 = ~ GPIOD_ODR.B12;
       Delay_ms(100);
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************