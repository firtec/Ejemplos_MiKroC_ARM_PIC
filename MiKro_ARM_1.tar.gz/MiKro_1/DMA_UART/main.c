/*****************************************************************************
*  Descripci�n  : Recibe datos por UART2 (Pines PD5 y PD6). El control del
*                 flujo de datos lo maneja el DMA1 (String 5 Canal 4)
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V6.2.0
*         www.firtec.com.ar
*****************************************************************************/
volatile unsigned char rxBuffer[64];
volatile unsigned char txBuffer[64];
volatile unsigned char bandera =0;

/******************************************************************************
*     Funci�n para el env�o de cadenas por el puerto UART.
******************************************************************************/
void Enviar_String(const char *s)
{
  while(*s)
  {
    UART2_Write(*s++);
  }
}
/******************************************************************************
*      ISR o servicio de interrupci�n del DMA1 Stream_5
******************************************************************************/
void DMA1_USART2_RX() iv IVT_INT_DMA1_Stream5 ics ICS_AUTO
{
GPIOD_ODR.B15 = ~ GPIOD_ODR.B15; // Led Azul cambia estado
bandera =1;
DMA1_HIFCR.CTCIF5=1; // Borrar bandera de ISR
//DMA1_S5CR.EN=1;    // Habilitar Stream nuevamente
}
/******************************************************************************
* Funci�n para configurar el DMA1 por Canal4 y Stream5.
******************************************************************************/
void Configurar_DMA(){
RCC_AHB1ENR.DMA1EN=1;  // Reloj del DMA1 activado
if( DMA1_S5CR.EN == 1 ){
DMA1_S5CR.EN = 0; // Stream 5 des-habilitado
while ( DMA1_S5CR.EN == 1 ); // Confirmar la acci�n
}
DMA1_HIFCR.CTCIF5=1; // Los registros de estado son borrados
DMA1_S5PAR = (unsigned long)&USART2_DR; // Origen de los datos
DMA1_S5M0AR = (unsigned long)&rxBuffer; // Destino de los datos
DMA1_S5NDTR = 1;  // N�mero de datos a procesar
DMA1_S5FCR.DMDIS=0; // Modo directo

DMA1_S5CR.CHSEL2=1;  // Selecciona el canal DMA 4 para  USART2
DMA1_S5CR.CHSEL1=0;
DMA1_S5CR.CHSEL0=0;
DMA1_S5CR.PL1=1;     // Configura alta prioridad
DMA1_S5CR.PL0=1;     // para el del Stream_5
DMA1_S5CR.MSIZE1=0;  // Datos para memoria
DMA1_S5CR.MSIZE0=0;  // de 8 bits (Destino)
DMA1_S5CR.PSIZE1=0;  // Datos desde el perif�rico
DMA1_S5CR.PSIZE0=0;  // de 8 bits (Origen)
DMA1_S5CR.MINC = 1;  // Incremento de memoria destino
DMA1_S5CR.PINC = 0;  // Incremento de perif�rico origen
DMA1_S5CR.CIRC = 1;  // Modo circular
DMA1_S5CR.DIR1=0;    // Direcci�n perif�rico > memoria
DMA1_S5CR.DIR0=0;
DMA1_S5CR.PFCTRL=0;  // Control de flujo por DMA
DMA1_S5CR.TCIE=1;   // Interrupci�n de transferencia completa activo
DMA1_S5CR.EN=1;     // Inicio del Stream 5 en DMA1
USART2_CR3.DMAR=1;  // Receptor del UART2 se vincula al DMA
NVIC_IntEnable(IVT_INT_DMA1_Stream5); // Habilita interrupci�n DMA1_Stream5
}
/******************************************************************************
*                    Funci�n principal del programa
******************************************************************************/
void main()
{
 unsigned char i;
 // Configura los pines de los LED's
 GPIO_Config(&GPIOD_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_13 
                          | _GPIO_PINMASK_14 | _GPIO_PINMASK_15 , 
                          _GPIO_CFG_DIGITAL_OUTPUT);
 // Configura la UART2
 UART2_Init_Advanced(115200, _UART_8_BIT_DATA, _UART_NOPARITY,
                           _UART_ONE_STOPBIT, &_GPIO_MODULE_USART2_PD56);
Configurar_DMA();  // Configura el DMA y lo vincula a la UART2
UART2_Write_Text("Esperando Datos");
UART2_Write(13);
UART2_Write(10);
GPIOD_ODR.B14 = 1;  // Led Rojo encendido

while (1) {
      if (bandera ==1){
      bandera =0;
      Enviar_String(rxBuffer);
      }
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************