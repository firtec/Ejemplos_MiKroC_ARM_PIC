/****************************************************************************
**  Descripci�n  : Lectura del valor de temperatura con un sensor 1-Wire.
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 20MHZ
**  NOTA         : Verificado con sensor DS18B20 conectado en el pin RA4.
( No olvidar el resistor de 4,7K en el pin 1-Wire)
*****************************************************************************/
// LCD module connections
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

// Set TEMP_RESOLUTION to the corresponding resolution of used DS18x20 sensor:
// 18S20: 9 (default setting; can be 9,10,11,or 12)
// 18B20: 12
unsigned short TEMP_RESOLUTION = 12;
unsigned temp;
char *text = "000.0";
int i;
int colona;

void Read_Temperature()
{
// Perform temperature reading
Ow_Reset(&PORTA, 4); // Onewire reset signal
Ow_Write(&PORTA, 4, 0xCC); // Issue command SKIP_ROM
Ow_Write(&PORTA, 4, 0x44); // Issue command CONVERT_T
Delay_us(120);
Ow_Reset(&PORTA, 4);
Ow_Write(&PORTA, 4, 0xCC); // Issue command SKIP_ROM
Ow_Write(&PORTA, 4, 0xBE); // Issue command READ_SCRATCHPAD
temp = Ow_Read(&PORTA, 4);
temp = (Ow_Read(&PORTA, 4) << 8) + temp;
}

void Display_Temperature()
{
     unsigned short RES_SHIFT = TEMP_RESOLUTION - 8;
     char temp_whole;
     unsigned int temp2write;
     unsigned int temp_fraction;

    temp2write = temp;
    text[0] = '+';
    // Check if temperature is negative
    if (temp2write & 0x8000)
    {
       text[0] = '-';
       temp2write = ~temp2write + 1;
    }
    // Extract temp_whole
    temp_whole = temp2write >> RES_SHIFT ;
    // Convert temp_whole to characters
    if (temp_whole/100)
    text[0] = temp_whole/100 + 48;
    text[1] = (temp_whole/10)%10 + 48; // Extract tens digit
    text[2] = temp_whole%10 + 48; // Extract ones digit
    text[3] = '.';
    // Extract temp_fraction and convert it to unsigned int
    temp_fraction = temp2write << (4-RES_SHIFT);
    temp_fraction &= 0x000F;
    temp_fraction *= 625;
    // Convert temp_fraction to characters
    text[4] = temp_fraction/1000 + 48; // Extract thousands digit
    // Print temperature on LCD
    Lcd_Out(2,8, text);
    // Print degree character and'C' for Celsius
    Lcd_Chr_CP(0xDF); // 223 ASCII for degree symbol on my LCD
    Lcd_Chr_CP('C');
  }

void main()
{
     CMCON |=7;
     ADCON1 = 0x0D;
     TRISA.B4 = 1; // Configure RA4 pin as input
     Lcd_Init(); // Initialize LCD
     Lcd_Cmd(_LCD_CLEAR); // Clear LCD
     Lcd_Cmd(_LCD_CURSOR_OFF); // Turn cursor off
     Lcd_Out(1,2,"Sensor DS18B20");
     Lcd_Out(2,3,"Temp:");

   while(1)
   {
     Read_Temperature();
     Display_Temperature();
     Delay_ms(100);
    }
}
