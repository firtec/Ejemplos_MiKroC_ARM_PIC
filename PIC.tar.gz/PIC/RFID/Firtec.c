/****************************************************************************
**  Descripci�n  : Detecci�n de TAG�s mediante RFID con chip CR95HF
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 40MHZ - (XTAL 10Mhz con PLLx4)
*****************************************************************************
 * NOTA: Puede suceder que sea necesario re-iniciar la placa RFID cuando el
 *       PIC se resetea, el hardware de la placa RFID y el microcontrolador
 *       deben iniciar juntos. Para un uso comercial puede ser buena idea
 *       controlar la alimentaci�n de la placa RFID a traves de un
 *       transistor comandado por un pin del PIC para que cada vez que
 *       que inicie energize tambi�n la etapa RF.
 ****************************************************************************/
// Coamando para el chip CR95HF
#define    IDN                    0x01
#define    ProtocolSelect         0x02
#define    SendRecv               0x04
#define    Idle                   0x07
#define    RdReg                  0x08
#define    WrReg                  0x09
#define    BaudRate               0x0A
#define    ECHO                   0x55

// Pines asignados a la placa RFID
sbit SSI_1  at LATA.B1;
sbit SSI_0  at LATA.B0;
sbit IRQ_IN at LATC.B0; // pin INT1
sbit CSet   at LATE.B0;

sbit SSI_1_Direction  at TRISA.B1;
sbit SSI_0_Direction  at TRISA.B0;
sbit IRQ_IN_Direction at TRISC.B0;
sbit CSet_Direction   at TRISE.B0;

// Pines asignados al LCD
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

// Variables globales del sistema
unsigned short sdata[18];
unsigned short rdata[18];
unsigned short res = 0, dataNum = 0;
unsigned short j = 0, tmp = 0;
char ID[10] = {0};
char txt_hex[3];

/***************************************************************
* Esta funci�n escribe comandos en el CR95HF mediante SPI.
****************************************************************/
void writeCmd(unsigned short cmd, unsigned short dataLen){
  unsigned short i = 0;

  CSet = 0;
  SPI1_Write(0x00);  // Send cmd to CR95HF
  SPI1_Write(cmd);
  SPI1_Write(dataLen);
  while (dataLen == 0){
    CSet = 1;
    break;
  }
  for(i=0; i<dataLen; i++){
    SPI1_Write(sdata[i]);
  }
  CSet = 1;
}

/**********************************************************
*     Esta funci�n lee el chip CR95HF mediante SPI.
**********************************************************/
void readCmd(){
  unsigned short i = 0;

  while(1){
    CSet = 0;
    SPI1_Write(0x03);
    res = SPI1_Read(0);
    CSet = 1;

    if((res & 0x08) >> 3){
      CSet = 0;
      SPI1_Write(0x02);
      res = SPI1_Read(0);
      dataNum = SPI1_Read(0);
      for(i=0; i<dataNum; i++)
        rdata[i] = SPI1_Read(0);
      CSet = 1;
      break;
    }
    CSet = 1;
    Delay_ms(10);
  }
}

/**********************************************************
*     Esta funci�n calibra el chip CR95HF.
**********************************************************/
void Calibration() {
  //TFT_Write_Text("Calibrating CR95HF...", 55, 100);
  sdata[0] = 0x03;
  sdata[1] = 0xA1;
  sdata[2] = 0x00;
  sdata[3] = 0xF8;
  sdata[4] = 0x01;
  sdata[5] = 0x18;
  sdata[6] = 0x00;
  sdata[7] = 0x20;
  sdata[8] = 0x60;
  sdata[9] = 0x60;
  sdata[10] = 0x00;
  sdata[11] = 0x00;
  sdata[12] = 0x3F;
  sdata[13] = 0x01;
  writeCmd(Idle, 0x0E);
  readCmd();

  sdata[11] = 0xFC;
  writeCmd(Idle, 0x0E);
  readCmd();

  sdata[11] = 0x7C;
  writeCmd(Idle, 0x0E);
  readCmd();

  sdata[11] = 0x3C;
  writeCmd(Idle, 0x0E);
  readCmd();

  sdata[11] = 0x5C;
  writeCmd(Idle, 0x0E);
  readCmd();

  sdata[11] = 0x6C;
  writeCmd(Idle, 0x0E);
  readCmd();

  sdata[11] = 0x74;
  writeCmd(Idle, 0x0E);
  readCmd();

  sdata[11] = 0x70;
  writeCmd(Idle, 0x0E);
  readCmd();
}
/**********************************************************
*     Esta funci�n selecciona el protocolo seg�n el tipo
*     de tag.
**********************************************************/
void Select_ISO_IEC_14443_A_Protocol() {
  sdata[0] = 0x02;
  sdata[1] = 0x00;
  writeCmd(ProtocolSelect, 2);
  readCmd();

  //  Limpia los buffers
  for(j=0; j<18; j++ ){
    rdata[j] = 0;
    sdata[j] = 0;
  }
}
/**********************************************************
*     Esta funci�n configura ganancia RF.
**********************************************************/
void IndexMod_Gain() {
  sdata[0] = 0x09;
  sdata[1] = 0x04;
  sdata[2] = 0x68;
  sdata[3] = 0x01;
  sdata[4] = 0x01;
  sdata[5] = 0x50;
  writeCmd(WrReg, 6);
  readCmd();
}
/**********************************************************
*     Esta funci�n condigura autodetecci�n
**********************************************************/
void AutoFDet() {
  sdata[0] = 0x09;
  sdata[1] = 0x04;
  sdata[2] = 0x0A;
  sdata[3] = 0x01;
  sdata[4] = 0x02;
  sdata[5] = 0xA1;
  writeCmd(WrReg, 6);
  readCmd();
}
/**********************************************************
*          Esta funci�n lee el TAG
**********************************************************/
char GetNFCTag() {
  sdata[0] = 0x26;
  sdata[1] = 0x07;
  writeCmd(SendRecv , 2);
  readCmd();

  sdata[0] = 0x93;
  sdata[1] = 0x20;
  sdata[2] = 0x08;
  writeCmd(SendRecv , 3);
  readCmd();

  if(res == 0x80) {
    for( j = 1; j < dataNum - 3; j++) {
      ByteToHex(rdata[j], txt_hex);
      strcat(ID, txt_hex);
      LATD.B0 = 1;
    }
    ID[10] = 0;
    return 1;
  }
  else
  {
    LATD.B0 = 0;
    return 0;
  }
}
/**********************************************************
*    Esta funci�n configura el Hardware.
**********************************************************/
void Hard_Config(){

  CMCON |=7;
  ADCON1 = 0x0f;
  CSet_Direction = 0;
  IRQ_IN_Direction = 0;
  SSI_0_Direction  = 0;
  SSI_1_Direction  = 0;
  IRQ_IN = 1;
  CSet = 1;

  SSI_1 = 0;
  SSI_0 = 1;
   Delay_ms(200);

  SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV64, _SPI_DATA_SAMPLE_MIDDLE,
                     _SPI_CLK_IDLE_LOW,_SPI_LOW_2_HIGH);

  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  Lcd_Out(1,1,"Ejemplo con RFID");

}
/**********************************************************
*     Esta funci�n env�a el comando ECHO para
*     verificar la presencia del chip CR95HF.
**********************************************************/
char EchoResponse() {
  CSet = 0;
    SPI1_Write(0x00);  // Se enviar� un comando a CR95HF
    SPI1_Write(ECHO);  // Comando ECHO
  CSet = 1;
  while(1){
    CSet = 0;
      SPI1_Write(0x03);
      tmp = SPI1_Read(1);
    CSet = 1;

    if((tmp & 0x08) >> 3){
      CSet = 0;
      SPI1_Write(0x02);
      tmp = SPI1_Read(1);
      CSet = 1;
      if(tmp == ECHO){
        return 1;
      }
      return 0;
    }
  }
}
//*************************** FUNCI�N PRINCIPAL *******************************
void main() {
  Hard_Config();              // Configura RFID, SPI, LCD
  while (!EchoResponse()) {   // Esperar hasta detectar chip CR95HF
    IRQ_IN = 0;
    Delay_ms(10);
    IRQ_IN = 1;
    Delay_ms(10);
  }
  Lcd_Out(2, 1, "Calibrando......"); // CR95HF detectado!!!

  Calibration();   // Configura RFID
  IndexMod_Gain(); // Configura RFID
  AutoFDet();      // Configura RFID
  Select_ISO_IEC_14443_A_Protocol();  // Selecciona protocolo
  Lcd_Out(2, 1, "TAG/ID:???       ");

  while(1){
    if(GetNFCTag()){          // Buscartag ID
      Lcd_Out(2,8, &ID);      // Mostrarlo en LCD

      // Limpia los buffers
      for(j=0; j<10; j++){
        ID[j] = 0;
      }
      Delay_ms(500);
    }
  }
}