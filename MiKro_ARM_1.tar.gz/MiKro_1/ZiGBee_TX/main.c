/*****************************************************************************
*  Descripci�n  : Ejemplo para el protocolo SPI manejando un modulo RFID click
*                 fabricado por MiKroElectroniKa con el chip CR95HF .
*                 Este ejemplo utiliza SPI2 en pines PB13 PB14 PB15.
*                 Los valores se muestran en una pantalla LCD 20x4.
*  Target       : STM32F407VG
*  ToolChain    : MiKroC para ARM V5.0
*         www.firtec.com.ar
*****************************************************************************/
#include "resources.h"
#include "registers.h"
#include "ReadWrite_Routines.h"
#include "Reset_Routines.h"
#include "Misc_Routines.h"
#include "Init_Routines.h"
//#include "Init_Routines.c"
//#include "ReadWrite_Routines.c"
//#include "Reset_Routines.c"
//#include "Misc_Routines.c"

// BEE Click Board connections
sbit CS at GPIOE_ODR.B5;                // CS pin
sbit RST at GPIOE_ODR.B4;               // RST pin
sbit INT at GPIOD_ODR.B2;               // INT pin
sbit WAKE_ at GPIOC_ODR.B5;             // WAKE pin

// TFT module connections

// End TFT module connections

extern short int DATA_TX[];
char txt[4];


void main() {
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_12);
  Initialize();                      // Initialize MCU and Bee click board

  while(1) {                         // Infinite loop
    write_TX_normal_FIFO();          // Transmiting
    //ByteToStr(DATA_TX[0],&txt);      // Convert byte to string
    delay_ms(1000);
    GPIOD_ODR.B12 = ~ GPIOD_ODR.B12;

    DATA_TX[0]++;                    // Incremeting value
  }
}

//******************* Fin de archivo - FIRTEC ARGENTINA ***********************