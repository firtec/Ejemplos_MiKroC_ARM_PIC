/* ***************************************************************************
**  Descripci�n  : Env�a caracteres por la UART que son mostrados en un
**                 LCD 16x2. El caracter es re-transmitido como un ECO.
**                 Se decodifica la tecla de retroceso para borrar los
**                 caracteres en la pantalla LCD de manera remota.
**                 El receptor funciona atendiendo una interrupci�n.
**  Target       : 40PIN PIC18F4620
**  Compiler     : MikroC para PIC v 7.1
**  XTAL         : 20MHZ
**  UART         : 9600 baudios 8 bit S/paridad
** ***************************************************************************/
// LCD module connections
sbit LCD_RS at LATE1_bit;
sbit LCD_EN at LATE2_bit;
sbit LCD_D4 at LATD4_bit;
sbit LCD_D5 at LATD5_bit;
sbit LCD_D6 at LATD6_bit;
sbit LCD_D7 at LATD7_bit;

sbit LCD_RS_Direction at TRISE1_bit;
sbit LCD_EN_Direction at TRISE2_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// End LCD module connections

  unsigned char base =1;
//unsigned char txt[15];

//const short n = 20;
 //char rxchar, i = 0, flag = 0; // Variable for storing the data from UART and array counter
 ////unsigned char rxarray[n];   // array to store the received charaters
 volatile char Data, Kbhit=0;

void ISR_UART() iv 0x0008 ics ICS_AUTO {
  if (PIR1.RCIF) {         // test the interrupt for uart rx
    Data = Uart1_Read();   // Lee dato recibido
    Kbhit=1;               // Indica que se ha recibido un dato
    PIR1.RCIF=0;           // Borra bandera de interrupci�n
    }
  }

void main() {
  Lcd_Init();
  Delay_ms(500);
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  UART1_Init(9600); // Initialize UART module at 9600bps
  Delay_ms(100); // Wait for UART module to stabilize
  
  INTCON.GIE = 1;
  INTCON.PEIE = 1;
  PIE1.RCIE = 1;
  Delay_ms(1000);
  Lcd_Out(1, 1, "UART");
  //Lcd_Chr(2,10,223);                  // char code for degree

   while(1){
   if(Kbhit !=0){  // Indica que hay nueos datos recibidos
      Kbhit = 0;                 // Borra la marca de ISR
      if(Data!=0x00){ // El dato es distinto de 0?
          if(Data==0x08 & base > 0){ // Backspace & base son verdaderos?
                if(base >1 )
                    base--;
                    Lcd_Chr(2,base,' ');
           }
   else{
      Lcd_Chr(2,base,Data);
      UART1_Write(Data);
      base++;
     }
    }
  }
 }
}